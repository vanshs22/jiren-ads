#!/usr/bin/env python3
"""
Proxy health checker + simple blacklist for Jiren Ads Bot.

Usage (standalone):
  python proxy_health.py                 # check PROXY_LIST / config.PROXIES
  python proxy_health.py --json          # machine-readable summary

The bot/manager can also import:
  from proxy_health import get_healthy_proxies, mark_bad, proxy_stats

A proxy is considered bad after CONSECUTIVE_FAILS failures within FAIL_WINDOW_SEC.
Blacklist is stored in Mongo collection `proxy_blacklist` when MONGO_URI is set,
otherwise in-memory only.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import socket
import sys
import time
from datetime import datetime, timedelta
from typing import List, Optional, Tuple
from urllib.parse import urlparse

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

CONSECUTIVE_FAILS = int(os.getenv('PROXY_FAIL_THRESHOLD', '3'))
FAIL_WINDOW_SEC = int(os.getenv('PROXY_FAIL_WINDOW', '600'))
CHECK_TIMEOUT = float(os.getenv('PROXY_CHECK_TIMEOUT', '8'))
# TCP connect target used as a cheap liveness probe (no full HTTP needed)
PROBE_HOST = os.getenv('PROXY_PROBE_HOST', '1.1.1.1')
PROBE_PORT = int(os.getenv('PROXY_PROBE_PORT', '443'))

# In-memory fallback
_mem_fails = {}   # key -> list[timestamps]
_mem_black = {}   # key -> until_ts


def _parse_proxy_line(line: str) -> Optional[dict]:
    """Accept host:port, host:port:user:pass, or socks5://user:pass@host:port."""
    line = (line or '').strip()
    if not line or line.startswith('#'):
        return None
    if '://' in line:
        u = urlparse(line)
        return {
            'scheme': u.scheme or 'socks5',
            'host': u.hostname,
            'port': u.port or 1080,
            'user': u.username,
            'password': u.password,
            'raw': line,
            'key': f"{u.hostname}:{u.port or 1080}",
        }
    parts = line.split(':')
    if len(parts) == 2:
        host, port = parts
        user = password = None
    elif len(parts) >= 4:
        host, port, user, password = parts[0], parts[1], parts[2], ':'.join(parts[3:])
    else:
        return None
    try:
        port = int(port)
    except ValueError:
        return None
    return {
        'scheme': 'socks5',
        'host': host,
        'port': port,
        'user': user,
        'password': password,
        'raw': line,
        'key': f'{host}:{port}',
    }


def load_proxy_list() -> List[dict]:
    out = []
    raw = os.getenv('PROXY_LIST', '').strip()
    if raw:
        for line in re.split(r'[\n;]+', raw):
            p = _parse_proxy_line(line)
            if p:
                out.append(p)
    try:
        from config import PROXIES as CFG
        for item in (CFG or []):
            if isinstance(item, str):
                p = _parse_proxy_line(item)
            elif isinstance(item, dict):
                p = item
                p.setdefault('key', f"{p.get('host')}:{p.get('port')}")
            else:
                continue
            if p:
                out.append(p)
    except Exception:
        pass
    # dedupe by key
    seen = set()
    deduped = []
    for p in out:
        if p['key'] in seen:
            continue
        seen.add(p['key'])
        deduped.append(p)
    return deduped


def _mongo():
    uri = os.getenv('MONGO_URI', '').strip()
    if not uri:
        return None
    try:
        from pymongo import MongoClient
        import certifi
        kwargs = dict(serverSelectionTimeoutMS=5000)
        if uri.startswith('mongodb+srv://') or 'tls=true' in uri.lower():
            kwargs['tlsCAFile'] = certifi.where()
        client = MongoClient(uri, **kwargs)
        db = client[os.getenv('MONGO_DB_NAME', 'gokuads_db')]
        return db['proxy_blacklist']
    except Exception as e:
        print(f"[proxy_health] Mongo unavailable: {e}", file=sys.stderr)
        return None


def mark_bad(key: str, reason: str = 'connect_fail'):
    now = time.time()
    fails = _mem_fails.setdefault(key, [])
    fails.append(now)
    # prune old
    cutoff = now - FAIL_WINDOW_SEC
    _mem_fails[key] = [t for t in fails if t >= cutoff]
    if len(_mem_fails[key]) >= CONSECUTIVE_FAILS:
        until = now + FAIL_WINDOW_SEC
        _mem_black[key] = until
        col = _mongo()
        if col is not None:
            col.update_one(
                {'_id': key},
                {'$set': {
                    'until': datetime.utcfromtimestamp(until),
                    'reason': reason,
                    'fails': len(_mem_fails[key]),
                    'updated_at': datetime.utcnow(),
                }},
                upsert=True,
            )


def mark_ok(key: str):
    _mem_fails.pop(key, None)
    _mem_black.pop(key, None)
    col = _mongo()
    if col is not None:
        col.delete_one({'_id': key})


def is_blacklisted(key: str) -> bool:
    now = time.time()
    until = _mem_black.get(key)
    if until and until > now:
        return True
    col = _mongo()
    if col is not None:
        doc = col.find_one({'_id': key})
        if doc and doc.get('until') and doc['until'].timestamp() > now:
            _mem_black[key] = doc['until'].timestamp()
            return True
        if doc:
            col.delete_one({'_id': key})
    return False


def check_one(proxy: dict) -> Tuple[bool, str]:
    """Cheap TCP connect through the proxy is complex without a SOCKS lib;
    we probe that the proxy port itself accepts TCP as a basic liveness check.
    For full checks, set PROXY_FULL_CHECK=1 and use python-socks (optional)."""
    host, port = proxy.get('host'), proxy.get('port')
    if not host or not port:
        return False, 'invalid'
    if is_blacklisted(proxy['key']):
        return False, 'blacklisted'
    try:
        sock = socket.create_connection((host, int(port)), timeout=CHECK_TIMEOUT)
        sock.close()
        mark_ok(proxy['key'])
        return True, 'ok'
    except Exception as e:
        mark_bad(proxy['key'], str(e)[:80])
        return False, str(e)[:80]


def get_healthy_proxies() -> List[dict]:
    healthy = []
    for p in load_proxy_list():
        ok, _ = check_one(p)
        if ok:
            healthy.append(p)
    return healthy


def proxy_stats() -> dict:
    all_p = load_proxy_list()
    healthy = []
    bad = []
    for p in all_p:
        ok, reason = check_one(p)
        (healthy if ok else bad).append({'key': p['key'], 'reason': reason})
    return {
        'total': len(all_p),
        'healthy': len(healthy),
        'bad': len(bad),
        'bad_list': bad,
        'checked_at': datetime.utcnow().isoformat() + 'Z',
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--json', action='store_true')
    args = ap.parse_args()
    stats = proxy_stats()
    if args.json:
        print(json.dumps(stats, indent=2))
    else:
        print(f"Proxies: {stats['healthy']}/{stats['total']} healthy")
        for b in stats['bad_list']:
            print(f"  BAD  {b['key']}  ({b['reason']})")
    sys.exit(0 if stats['healthy'] or stats['total'] == 0 else 1)


if __name__ == '__main__':
    main()
