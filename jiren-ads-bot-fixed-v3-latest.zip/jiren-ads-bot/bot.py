import os
import asyncio
import sys
import psutil
import random
import string
import re
import hashlib
import concurrent.futures
from datetime import datetime, timedelta

# Force live terminal / journal / docker logs. Without this, print() is block-
# buffered when stdout is not a TTY (systemd, docker compose, pipes) and the
# terminal appears frozen with "no logs updating".
os.environ.setdefault('PYTHONUNBUFFERED', '1')
try:
    sys.stdout.reconfigure(line_buffering=True, write_through=True)  # py3.7+
except Exception:
    pass
try:
    sys.stderr.reconfigure(line_buffering=True, write_through=True)
except Exception:
    pass
# Wrap print so every log line flushes immediately (works even if -u was missed)
import builtins as _builtins
_orig_print = _builtins.print
def _print_flush(*args, **kwargs):
    kwargs.setdefault('flush', True)
    return _orig_print(*args, **kwargs)
_builtins.print = _print_flush
from telethon import TelegramClient, Button, events
from telethon.sessions import StringSession
from telethon.tl.functions.account import UpdateProfileRequest
from telethon.errors import (
    SessionPasswordNeededError,
    FloodWaitError,
    PhoneNumberInvalidError,
    PhoneCodeInvalidError,
    PhoneCodeExpiredError,
    PasswordHashInvalidError,
    ChannelPrivateError,
    ChatWriteForbiddenError,
    UserBannedInChannelError,
    MessageNotModifiedError,
    UserNotParticipantError,
    PeerFloodError,
    SlowModeWaitError,
)
# Optional auth-death errors (names vary by Telethon version)
try:
    from telethon.errors import AuthKeyUnregisteredError
except Exception:
    AuthKeyUnregisteredError = type('AuthKeyUnregisteredError', (Exception,), {})
try:
    from telethon.errors import UserDeactivatedBanError
except Exception:
    try:
        from telethon.errors import UserDeactivatedError as UserDeactivatedBanError
    except Exception:
        UserDeactivatedBanError = type('UserDeactivatedBanError', (Exception,), {})
try:
    from telethon.errors import SessionRevokedError
except Exception:
    SessionRevokedError = type('SessionRevokedError', (Exception,), {})
try:
    from telethon.errors import AuthKeyDuplicatedError
except Exception:
    AuthKeyDuplicatedError = type('AuthKeyDuplicatedError', (Exception,), {})

_AUTH_DEAD_ERRORS = (
    AuthKeyUnregisteredError,
    UserDeactivatedBanError,
    SessionRevokedError,
    AuthKeyDuplicatedError,
)
from telethon.tl.functions.bots import SetBotCommandsRequest
from telethon.tl.functions.channels import GetParticipantRequest, LeaveChannelRequest
from telethon.tl.functions.messages import ForwardMessagesRequest, DeleteChatUserRequest
from telethon.tl.types import Channel, Chat, User, InputPeerChannel, InputPeerChat, BotCommand, BotCommandScopeDefault
from cryptography.fernet import Fernet
from pymongo import MongoClient
import certifi
import time
import requests
import qrcode
import random

# Load environment variables from a local .env file if present (production secrets).
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

from config import BOT_CONFIG, FREE_TIER, PREMIUM_TIER, MESSAGES, TOPICS, INTERVAL_PRESETS, FORCE_JOIN, PLANS, PLAN_SCOUT, PLAN_IMAGES, UPI_PAYMENT, PROXIES as CONFIG_PROXIES

try:
    from rate_limit import allow_user as _rate_allow_user
except Exception:
    def _rate_allow_user(*a, **k):
        return True
try:
    from audit import write_audit as _write_audit
except Exception:
    def _write_audit(*a, **k):
        pass
try:
    from forwarding_svc import (
        set_draining as _set_draining,
        is_draining as _is_draining,
        touch_activity as _touch_activity,
        clear_activity as _clear_activity,
        is_activity_stale as _is_activity_stale,
        status_label_for_account as _status_label_for_account,
        ACTIVITY_STALE_SEC as _ACTIVITY_STALE_SEC,
    )
except Exception:
    def _set_draining(v=True):
        pass
    def _is_draining():
        return False
    def _touch_activity(aid):
        pass
    def _clear_activity(aid):
        pass
    def _is_activity_stale(aid, now=None):
        return False
    def _status_label_for_account(acc):
        if acc and acc.get('auth_invalid'):
            return ('⚠️', 'Session dead')
        if acc and acc.get('is_forwarding'):
            return ('✅', 'Active')
        return ('❌', 'Inactive')
    _ACTIVITY_STALE_SEC = 600.0
try:
    from admin_audit import write_impersonation_audit as _write_impersonation_audit
except Exception:
    def _write_impersonation_audit(*a, **k):
        pass
try:
    from sick_accounts import record_flood as _sick_record, is_sick as _sick_remaining, clear as _sick_clear
except Exception:
    def _sick_record(aid):
        return False
    def _sick_remaining(aid):
        return 0.0
    def _sick_clear(aid):
        pass
try:
    from health_server import start_health_server
except Exception:
    start_health_server = None
try:
    from cleanup_jobs import run_cleanup
except Exception:
    def run_cleanup(*a, **k):
        return {}

# Proxies list (round-robin)
PROXIES = CONFIG_PROXIES
import python_socks

CONFIG = BOT_CONFIG

# Default quiet hours for new users and users without a setting.
DEFAULT_QUIET_HOURS = {
    'enabled': True,
    'start': '01:00',
    'end': '07:00',
    'label': '01:00-07:00 IST',
}

# Helper function to get username from user ID
async def get_username_from_id(client, user_id: int):
    """Fetch username from Telegram using user ID"""
    try:
        user = await client.get_entity(user_id)
        return user.username  # None if no username
    except Exception:
        return None

async def resolve_target_user_id(raw: str, client):
    value = (raw or "").strip()
    if not value:
        return None
    if value.isdigit():
        return int(value)
    username = value[1:] if value.startswith('@') else value
    if not username:
        return None
    user_doc = await db_call(
        users_col.find_one,
        {'username': {'$regex': f'^{re.escape(username)}$', '$options': 'i'}},
    )
    if user_doc and user_doc.get('user_id'):
        return int(user_doc['user_id'])
    try:
        entity = await client.get_entity(username)
        target_id = int(entity.id)
        if getattr(entity, 'username', None):
            await db_call(lambda: uupdate(
                {'user_id': target_id},
                {'$set': {'username': entity.username}},
                upsert=True,
            ))
        else:
            await db_call(get_user, target_id)
        return target_id
    except Exception:
        return None

def check_config():
    required = ['api_id', 'api_hash', 'bot_token', 'owner_id', 'mongo_uri']
    missing = []
    for key in required:
        val = CONFIG.get(key)
        if not val or val == '' or val == 0:
            missing.append(key.upper())
    return missing

missing_config = check_config()
if missing_config:
    print("\n" + "="*50)
    print("CONFIGURATION ERROR")
    print("="*50)
    print(f"Missing required secrets: {', '.join(missing_config)}")
    print("\nPlease add these secrets in the Secrets tab:")
    print("- TELEGRAM_API_ID")
    print("- TELEGRAM_API_HASH")
    print("- BOT_TOKEN")
    print("- OWNER_ID")
    print("- MONGO_URI")
    print("="*50)
    exit(1)

# ENCRYPTION_KEY must be stable across restarts or existing sessions become
# unreadable. Prefer env var; fall back to encryption.key file only.
# In production (BOT_ROLE set / Docker) refuse to auto-generate a new key.
_env_key = os.getenv('ENCRYPTION_KEY', '').strip()
_prod_like = bool(os.getenv('BOT_ROLE') or os.getenv('NODE_ID') or os.path.exists('/.dockerenv'))
if _env_key:
    key = _env_key
elif os.path.exists('encryption.key'):
    with open('encryption.key', 'r') as f:
        key = f.read().strip()
    if not key:
        raise SystemExit("[FATAL] encryption.key is empty. Set ENCRYPTION_KEY.")
elif _prod_like:
    raise SystemExit(
        "[FATAL] ENCRYPTION_KEY is required in production. "
        "Generate once: python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
    )
else:
    # Dev-only convenience
    key = Fernet.generate_key().decode()
    with open('encryption.key', 'w') as f:
        f.write(key)
    print("[WARN] Generated new ENCRYPTION_KEY and saved to encryption.key — back it up!")
cipher_suite = Fernet(key.encode())

# Role is needed before MongoClient + UI session files (manager spawns many processes).
_EARLY_BOT_ROLE = os.getenv('BOT_ROLE', 'all').strip().lower()  # all | bot | worker
_IS_WORKER_ONLY = _EARLY_BOT_ROLE == 'worker'
_IS_UI_PROCESS = _EARLY_BOT_ROLE in ('all', 'bot')

allow_invalid_tls = os.getenv('MONGO_TLS_INSECURE', '').strip().lower() in ('1', 'true', 'yes')
_mongo_uri = CONFIG['mongo_uri']
# Per-process pool. Manager runs UI + N workers → total conns ≈ sum(pools).
# Defaults scale down for split roles so Atlas/self-hosted limits are not blown
# (which freezes db_call and makes /start hang while quick callback answers still look OK).
if os.getenv('MONGO_MAX_POOL'):
    _mongo_max_pool = int(os.getenv('MONGO_MAX_POOL'))
elif _IS_WORKER_ONLY:
    _mongo_max_pool = 25
elif _EARLY_BOT_ROLE == 'bot':
    _mongo_max_pool = 40
else:
    _mongo_max_pool = 100
if os.getenv('MONGO_MIN_POOL'):
    _mongo_min_pool = int(os.getenv('MONGO_MIN_POOL'))
elif _IS_WORKER_ONLY:
    _mongo_min_pool = 1
elif _EARLY_BOT_ROLE == 'bot':
    _mongo_min_pool = 2
else:
    _mongo_min_pool = 5
_mongo_kwargs = dict(
    # ---- Connection pool / timeout tuning (scales to many concurrent accounts) ----
    # The bot uses a synchronous driver shared by many forwarding tasks. A bounded,
    # reused pool prevents connection storms and the timeouts stop a slow Atlas
    # response from hanging the whole event loop indefinitely.
    # NOTE: this is PER PROCESS. With the manager running N workers, total Mongo
    # connections ≈ sum of each process maxPoolSize — keep modest.
    maxPoolSize=_mongo_max_pool,
    minPoolSize=_mongo_min_pool,
    maxIdleTimeMS=60000,
    serverSelectionTimeoutMS=int(os.getenv('MONGO_SERVER_SELECTION_MS', '8000')),
    connectTimeoutMS=int(os.getenv('MONGO_CONNECT_MS', '8000')),
    socketTimeoutMS=int(os.getenv('MONGO_SOCKET_MS', '20000')),
    retryWrites=True,
    retryReads=True,
    appname=f"jirenadbot-{_EARLY_BOT_ROLE}",
)
# Only enable TLS for Atlas (srv) or when explicitly requested. Self-hosted/local
# Mongo (mongodb://...) connects WITHOUT TLS — pymongo errors if TLS options are
# passed while TLS is disabled, so only add them when actually needed.
if _mongo_uri.startswith('mongodb+srv://') or 'tls=true' in _mongo_uri.lower() or 'ssl=true' in _mongo_uri.lower():
    _mongo_kwargs['tlsCAFile'] = certifi.where()
    _mongo_kwargs['tlsAllowInvalidCertificates'] = allow_invalid_tls
mongo_client = MongoClient(_mongo_uri, **_mongo_kwargs)
db = mongo_client[CONFIG['db_name']]

users_col = db['users']
accounts_col = db['accounts']
account_topics_col = db['account_topics']
account_settings_col = db['account_settings']
account_stats_col = db['account_stats']
account_auto_groups_col = db['account_auto_groups']
account_failed_groups_col = db['account_failed_groups']
account_flood_waits_col = db['account_flood_waits']
logger_tokens_col = db['logger_tokens']
admins_col = db['admins']
admin_audit_col = db['admin_audit']
settings_col = db['bot_settings']
worker_health_col = db['worker_health']
click_links_col = db['click_links']
discovered_groups_col = db['discovered_groups']
toxic_groups_col = db['toxic_groups']

# ---- Global, admin-controlled settings (e.g. the per-group send frequency) ----
# Frequency is a GLOBAL policy: default 3 sends/hour per group. Only admins can
# change it (1..HARD_MAX_TARGET_PER_HOUR) via /freq, /frequency, or the admin
# Frequency button. Users cannot change it.
HARD_MAX_TARGET_PER_HOUR = int(os.getenv('HARD_MAX_TARGET_PER_HOUR', '10'))
DEFAULT_TARGET_PER_HOUR = int(os.getenv('DEFAULT_TARGET_PER_HOUR', '2'))
_global_settings_cache = {}  # key -> (expires_monotonic, value)


def get_global_setting(key, default):
    import time as _t
    now = _t.monotonic()
    hit = _global_settings_cache.get(key)
    if hit and hit[0] > now:
        return hit[1]
    val = default
    try:
        doc = settings_col.find_one({'_id': 'global'})
        if doc and key in doc:
            val = doc[key]
    except Exception:
        pass
    _global_settings_cache[key] = (now + 30, val)
    return val


def set_global_setting(key, value):
    settings_col.update_one({'_id': 'global'}, {'$set': {key: value}}, upsert=True)
    _global_settings_cache.pop(key, None)
    # Also drop any timed cache entries that might still hold this key
    try:
        for k in list(_global_settings_cache.keys()):
            if k == key:
                _global_settings_cache.pop(k, None)
    except Exception:
        pass


def get_effective_target_per_hour():
    """Global per-group send frequency, clamped to [1, HARD_MAX_TARGET_PER_HOUR]."""
    try:
        v = int(get_global_setting('target_per_hour', DEFAULT_TARGET_PER_HOUR))
    except Exception:
        v = DEFAULT_TARGET_PER_HOUR
    return max(1, min(HARD_MAX_TARGET_PER_HOUR, v))


def get_user_freq_per_hour(user):
    """MAX cycles per hour for this user, or None if capping is off.

    This is a ceiling only — never a target to "push toward":
    - If cycle work + cycle_interval naturally yield 1 cycle/hour and freq=3,
      the account stays at ~1/hour (freq does nothing).
    - If they would start a 4th cycle within an hour with freq=3, wait until a slot frees.

    - user.freq_disabled True  -> None (only cycle interval applies)
    - user.freq_per_hour set   -> that max (clamped)
    - else                     -> global target_per_hour as the default max
    """
    try:
        if (user or {}).get('freq_disabled'):
            return None
        v = (user or {}).get('freq_per_hour')
        if v is not None:
            v = int(v)
            if v >= 1:
                return min(HARD_MAX_TARGET_PER_HOUR, v)
            return None  # 0 / negative treated as off
    except Exception:
        pass
    return get_effective_target_per_hour()


def get_user_target_per_hour(user):
    """Back-compat alias used by older call sites. Returns cycles/hour or global default.
    Prefer get_user_freq_per_hour (which can return None when disabled)."""
    v = get_user_freq_per_hour(user)
    if v is None:
        return get_effective_target_per_hour()
    return v


def get_cycle_interval_sec(user, tier_settings=None):
    """Minimum gap AFTER a cycle finishes before the next may start (seconds).
    Never reduced by frequency logic. Slow/Medium/Fast only set message delay —
    cycle gap comes from 10/20/30 min + Custom cycle buttons only.

    Priority:
      1) user.cycle_interval_sec (10/20/30/custom cycle buttons)
      2) custom_interval.round_delay (legacy custom form, if set)
      3) default 600s (10 min)
    Frequency may only LENGTHEN the wait, never shorten below this gap.
    """
    try:
        v = (user or {}).get('cycle_interval_sec')
        if v is not None:
            v = int(v)
            if v >= 60:
                return v
    except Exception:
        pass
    try:
        if (user or {}).get('custom_interval'):
            rd = int((user.get('custom_interval') or {}).get('round_delay') or 0)
            if rd >= 60:
                return rd
    except Exception:
        pass
    return 600


# Per-account timestamps of cycle STARTS (for hourly frequency cap). In-memory only.
_cycle_start_times = {}  # account_id -> list[float unix ts]


def _record_cycle_start(account_id):
    import time as _t
    now = _t.time()
    aid = str(account_id)
    lst = [t for t in _cycle_start_times.get(aid, []) if now - t < 3600.0]
    lst.append(now)
    _cycle_start_times[aid] = lst
    return lst


def _seconds_until_freq_slot(account_id, freq):
    """If freq cap is active and this account already ran `freq` cycles in the
    last hour, return seconds to wait until a slot frees. Else 0."""
    if not freq or freq < 1:
        return 0
    import time as _t
    now = _t.time()
    aid = str(account_id)
    lst = [t for t in _cycle_start_times.get(aid, []) if now - t < 3600.0]
    _cycle_start_times[aid] = lst
    if len(lst) < freq:
        return 0
    oldest = min(lst)
    return max(1.0, oldest + 3600.0 - now)

# Tiny TTL cache for admin panel stats (reduces repeated count_documents)
_ADMIN_PANEL_STATS_CACHE = {'ts': 0.0, 'data': None}
_ADMIN_PANEL_STATS_TTL = 8.0  # seconds


def live_logs_enabled():
    """Live per-send logging. LIVE_SEND_LOGS=0 is HARD OFF.
    Admin toggle is read with a 2s cache so the NEXT group send (not next cycle)
    can pick up ON/OFF even on worker processes."""
    env_on = os.getenv('LIVE_SEND_LOGS', '0').strip().lower() in ('1', 'true', 'yes', 'on')
    if not env_on:
        return False
    import time as _t
    now = _t.monotonic()
    hit = _global_settings_cache.get('live_send_logs')
    if hit and hit[0] > now:
        return bool(hit[1])
    val = True
    try:
        doc = settings_col.find_one({'_id': 'global'}, {'live_send_logs': 1})
        if doc is not None and 'live_send_logs' in doc:
            val = bool(doc['live_send_logs'])
    except Exception:
        pass
    _global_settings_cache['live_send_logs'] = (now + 2.0, val)
    return bool(val)

def ensure_indexes():
    """Create MongoDB indexes (idempotent)."""
    try:
        users_col.create_index('user_id', unique=True)
        users_col.create_index('username')

        accounts_col.create_index('owner_id')
        # Admin "all users" view sorts by created_at desc; account lists sort by
        # added_at within an owner. Without these, both were COLLSCAN + in-mem sort.
        users_col.create_index('created_at')
        accounts_col.create_index([('owner_id', 1), ('added_at', 1)])
        accounts_col.create_index([('owner_id', 1), ('is_forwarding', 1)])
        # The reconciler/manager query is_forwarding directly every cycle. Without a
        # leading-is_forwarding index these were COLLECTION SCANS at scale. This
        # compound index also covers the reconciler's {_id, owner_id} projection.
        accounts_col.create_index([('is_forwarding', 1), ('owner_id', 1)])
        accounts_col.create_index('auth_invalid')
        accounts_col.create_index('last_groups_refresh_at')

        account_topics_col.create_index([('account_id', 1), ('topic', 1)])
        account_auto_groups_col.create_index([('account_id', 1), ('group_id', 1)])
        account_failed_groups_col.create_index([('account_id', 1), ('group_key', 1)])
        account_flood_waits_col.create_index([('account_id', 1), ('group_key', 1)])
        account_flood_waits_col.create_index('wait_until')

        account_settings_col.create_index('account_id', unique=True)
        account_stats_col.create_index('account_id', unique=True)

        logger_tokens_col.create_index('token', unique=True)
        logger_tokens_col.create_index('account_id')

        admins_col.create_index('user_id', unique=True)
        click_links_col.create_index('code', unique=True)
        click_links_col.create_index('user_id')
        # n8n group-discovery pipeline writes here; the finder reads by niche.
        discovered_groups_col.create_index('username')
        discovered_groups_col.create_index('niche')
        discovered_groups_col.create_index([('niche', 1), ('username', 1)])
        # Toxic-group auto-pruning: strikes per (account, group); pruned lookup.
        toxic_groups_col.create_index([('account_id', 1), ('group_key', 1)], unique=True)
        toxic_groups_col.create_index([('account_id', 1), ('pruned', 1)])
    except Exception as e:
        print(f"[DB] Index creation failed: {e}")

def ensure_user_defaults():
    """Backfill defaults for existing users (quiet hours, smart_rotation ON)."""
    try:
        users_col.update_many(
            {'smart_rotation': {'$exists': False}},
            {'$set': {'smart_rotation': True}},
        )
    except Exception as e:
        print(f"[DB] smart_rotation default update failed: {e}")
    try:
        users_col.update_many(
            {'quiet_hours': {'$exists': False}},
            {'$set': {'quiet_hours': DEFAULT_QUIET_HOURS}}
        )
    except Exception as e:
        print(f"[DB] Default user settings update failed: {e}")

# --- Session directory setup ---
# Always store Telethon sqlite session files inside ./session/
SESSION_DIR = 'session'
os.makedirs(SESSION_DIR, exist_ok=True)

# Worker processes never start the UI bots, but TelegramClient() still opens the
# SQLite session on construct — concurrent workers locking session/main_bot.session
# makes the UI hang on NewMessage (/start) while CallbackQuery may still answer.
# (_EARLY_BOT_ROLE / _IS_WORKER_ONLY set above, before MongoClient.)

# Migrate any legacy session files from project root into ./session/
# (e.g. main_bot.session, logger_bot.session, and their -journal files)
# Skip on pure workers — they must not touch UI session files at all.
if not _IS_WORKER_ONLY:
    for _name in ('main_bot', 'logger_bot', 'notification_bot'):
        for _suffix in ('.session', '.session-journal'):
            _src = f"{_name}{_suffix}"
            _dst = os.path.join(SESSION_DIR, _src)
            try:
                if os.path.exists(_src) and not os.path.exists(_dst):
                    os.replace(_src, _dst)
            except Exception:
                # Non-fatal; bot can still run
                pass

# Point Telethon at the session base path (Telethon adds .session)
_BOT_CLIENT_KW = dict(
    connection_retries=None,   # keep retrying connection forever
    retry_delay=5,
    auto_reconnect=True,       # survive transient network drops without dying
    request_retries=5,
    flood_sleep_threshold=60,
)

if _IS_WORKER_ONLY:
    # In-memory sessions: workers never call .start() on these clients, but
    # constructing them must not open/lock the UI process's SQLite files.
    from telethon.sessions import MemorySession
    main_bot = TelegramClient(MemorySession(), CONFIG['api_id'], CONFIG['api_hash'], **_BOT_CLIENT_KW)
    logger_bot = TelegramClient(MemorySession(), CONFIG['api_id'], CONFIG['api_hash'], **_BOT_CLIENT_KW)
    notification_bot = TelegramClient(MemorySession(), CONFIG['api_id'], CONFIG['api_hash'], **_BOT_CLIENT_KW)
    print(f"[INIT] BOT_ROLE=worker — UI bot clients use MemorySession (no session/ lock)")
else:
    main_bot = TelegramClient(os.path.join(SESSION_DIR, 'main_bot'), CONFIG['api_id'], CONFIG['api_hash'], **_BOT_CLIENT_KW)
    logger_bot = TelegramClient(os.path.join(SESSION_DIR, 'logger_bot'), CONFIG['api_id'], CONFIG['api_hash'], **_BOT_CLIENT_KW)
    notification_bot = TelegramClient(os.path.join(SESSION_DIR, 'notification_bot'), CONFIG['api_id'], CONFIG['api_hash'], **_BOT_CLIENT_KW)

# ===================== Global Text Styling =====================
# Telegram doesn't allow changing the app UI font, but we can stylize outgoing
# text using Unicode "small caps-ish" letters and make HTML messages bold.
# This is applied to all outgoing captions/messages and inline button labels.

# Small-caps-ish mapping (not all letters exist in Unicode; fallback keeps original)
_SMALLCAPS_MAP = {
    'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ', 'h': 'ʜ',
    'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ', 'o': 'ᴏ', 'p': 'ᴘ',
    'q': 'ꞯ', 'r': 'ʀ', 's': 'ꜱ', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x',
    'y': 'ʏ', 'z': 'ᴢ',
}
_SMALLCAPS_REVERSE_MAP = {v: k for k, v in _SMALLCAPS_MAP.items()}


def _to_smallcaps_char(ch: str) -> str:
    # Only stylize latin letters; keep everything else (emojis, punctuation, RTL, etc.)
    lower = ch.lower()
    if lower in _SMALLCAPS_MAP and ch.isalpha():
        return _SMALLCAPS_MAP[lower]
    return ch


def _from_smallcaps_char(ch: str) -> str:
    """Reverse mapping so HTML tag names aren't corrupted if already stylized."""
    if ch in _SMALLCAPS_REVERSE_MAP:
        return _SMALLCAPS_REVERSE_MAP[ch]
    return ch


def _normalize_html_tag(tag_text: str) -> str:
    """Normalize a single <...> tag by converting any small-caps letters back to ASCII."""
    return ''.join(_from_smallcaps_char(c) for c in tag_text)


def _stylize_plain(text: str) -> str:
    if not text:
        return text
    return ''.join(_to_smallcaps_char(c) for c in str(text))


def _stylize_html(html: str) -> str:
    """Stylize text while preserving HTML tags/entities and leaving <code>/<pre> blocks untouched.

    - Converts plain text to small-caps-ish Unicode
    - Normalizes tag names if they were previously stylized
    - Wraps the final output in <b>...</b> to give a consistent bold look
    """
    if not html:
        return html

    s = str(html)
    out = []

    in_entity = False
    in_code = False

    i = 0
    while i < len(s):
        ch = s[i]

        # Capture full HTML tag and normalize it
        if ch == '<':
            j = s.find('>', i + 1)
            if j == -1:
                out.append(_to_smallcaps_char(ch) if not in_code else ch)
                i += 1
                continue

            tag = s[i:j + 1]
            norm_tag = _normalize_html_tag(tag)

            lower = norm_tag.lower()
            if lower.startswith('<code') or lower.startswith('<pre'):
                in_code = True
            elif lower.startswith('</code') or lower.startswith('</pre'):
                in_code = False

            out.append(norm_tag)
            i = j + 1
            continue

        # Track HTML entities (&amp; etc.) so we don't corrupt them
        if ch == '&':
            in_entity = True
            out.append(ch)
            i += 1
            continue

        if in_entity:
            out.append(ch)
            if ch == ';':
                in_entity = False
            i += 1
            continue

        out.append(_to_smallcaps_char(ch) if not in_code else ch)
        i += 1

    styled = ''.join(out)

    # Make everything bold consistently (Telegram HTML). Safe even if nested.
    return f"<b>{styled}</b>"


def _stylize_buttons(buttons):
    """Recursively rebuild Telethon Button structures with stylized labels."""
    if not buttons:
        return buttons

    def rebuild(btn):
        # Telethon buttons are lightweight objects created by telethon.Button
        try:
            txt = getattr(btn, 'text', None)
            data = getattr(btn, 'data', None)
            url = getattr(btn, 'url', None)

            if url is not None:
                return Button.url(_stylize_plain(txt), url)
            if data is not None:
                return Button.inline(_stylize_plain(txt), data)
        except Exception:
            return btn
        return btn

    try:
        # buttons can be a list[list[Button]] or list[Button]
        if isinstance(buttons, list):
            rebuilt = []
            for row in buttons:
                if isinstance(row, list):
                    rebuilt.append([rebuild(b) for b in row])
                else:
                    rebuilt.append(rebuild(row))
            return rebuilt
    except Exception:
        return buttons

    return buttons


def _patch_client_text_methods(client: TelegramClient):
    """Patch send_message/send_file/edit_message to stylize outgoing text/captions + button labels."""
    orig_send_message = client.send_message
    orig_send_file = client.send_file
    orig_edit_message = client.edit_message

    async def send_message_wrapped(*args, **kwargs):
        # Telethon signature: send_message(entity, message=None, ...)
        # Check for _no_style flag to bypass font transformation
        no_style = kwargs.pop('_no_style', False) or os.getenv('DISABLE_TEXT_STYLE', '0').strip().lower() in ('1', 'true', 'yes', 'on')
        
        if not no_style:
            if len(args) >= 2 and isinstance(args[1], str) and 'message' not in kwargs:
                parse_mode = kwargs.get('parse_mode')
                args = list(args)
                args[1] = _stylize_html(args[1]) if str(parse_mode).lower() == 'html' else _stylize_plain(args[1])
            elif isinstance(kwargs.get('message'), str):
                parse_mode = kwargs.get('parse_mode')
                kwargs['message'] = _stylize_html(kwargs['message']) if str(parse_mode).lower() == 'html' else _stylize_plain(kwargs['message'])

            if 'buttons' in kwargs:
                kwargs['buttons'] = _stylize_buttons(kwargs['buttons'])

        return await orig_send_message(*args, **kwargs)

    async def send_file_wrapped(*args, **kwargs):
        # send_file(entity, file, caption=..., ...)
        if isinstance(kwargs.get('caption'), str):
            parse_mode = kwargs.get('parse_mode')
            kwargs['caption'] = _stylize_html(kwargs['caption']) if str(parse_mode).lower() == 'html' else _stylize_plain(kwargs['caption'])

        if 'buttons' in kwargs:
            kwargs['buttons'] = _stylize_buttons(kwargs['buttons'])

        return await orig_send_file(*args, **kwargs)

    async def edit_message_wrapped(*args, **kwargs):
        # edit_message(entity, message, text=..., ...)
        parse_mode = kwargs.get('parse_mode')

        # Handle positional text argument (common when calling client.edit_message(entity, msg_id, text, ...))
        if len(args) >= 3 and isinstance(args[2], str) and 'text' not in kwargs:
            args = list(args)
            args[2] = _stylize_html(args[2]) if str(parse_mode).lower() == 'html' else _stylize_plain(args[2])

        # Handle keyword text
        if isinstance(kwargs.get('text'), str):
            kwargs['text'] = _stylize_html(kwargs['text']) if str(parse_mode).lower() == 'html' else _stylize_plain(kwargs['text'])

        if 'buttons' in kwargs:
            kwargs['buttons'] = _stylize_buttons(kwargs['buttons'])

        return await orig_edit_message(*args, **kwargs)

    client.send_message = send_message_wrapped
    client.send_file = send_file_wrapped
    client.edit_message = edit_message_wrapped


# Apply patch to both bots
_patch_client_text_methods(main_bot)
_patch_client_text_methods(logger_bot)

user_states = {}
forwarding_tasks = {}

_impersonate = {}
# target_user_id -> (admin_id, expires_at)
_logmode_mirrors = {}

def acting_uid(real_uid):
    try:
        rid = int(real_uid)
    except Exception:
        return real_uid
    return int(_impersonate.get(rid, rid))

def is_impersonating(real_uid) -> bool:
    try:
        rid = int(real_uid)
    except Exception:
        return False
    return rid in _impersonate and int(_impersonate[rid]) != rid

def _put_flow_state(real_uid, apply_uid, state: dict):
    """Store UI text-input state so the person typing (real_uid) always owns it.
    apply_uid is the user whose settings change (target under impersonation)."""
    st = dict(state or {})
    st['apply_to'] = int(apply_uid)
    user_states[int(real_uid)] = st
    # Also keep under apply_uid for any legacy readers
    if int(apply_uid) != int(real_uid):
        user_states[int(apply_uid)] = st

def _flow_target(state, default_uid):
    try:
        if isinstance(state, dict) and state.get('apply_to') is not None:
            return int(state['apply_to'])
    except Exception:
        pass
    return int(default_uid)


auto_reply_clients = {}
last_replied = {}
_BG_TASKS = set()   # strong refs for long-lived background tasks (prevent GC)


def _spawn_bg(coro):
    """Create a fire-and-forget task with a STRONG reference so the event loop
    can't garbage-collect it mid-run (asyncio keeps only a weak ref to bare tasks)."""
    t = asyncio.create_task(coro)
    _BG_TASKS.add(t)
    t.add_done_callback(_BG_TASKS.discard)
    return t

# Auto group-join cancellation flags (uid -> bool)
auto_join_cancel = {}

# Per-user forwarding loop (so all accounts send in parallel, then round delay once)
user_forwarding_tasks = {}  # user_id -> asyncio.Task

# Payment tracking (gateway.py integration)
# (Removed) gateway payment tracking (manual UPI now)

ACCOUNTS_PER_PAGE = 7

# (Removed) External payment gateway integration
# ===================== Manual UPI Payment Helpers =====================

# In-memory pending payments
# pending_upi_payments[request_id] = {
#   'user_id': int, 'username': str|None, 'plan_key': str, 'plan_name': str,
#   'price': int, 'created_at': datetime, 'status': 'awaiting_screenshot'|'submitted'
# }
pending_upi_payments = {}

# Map admin message -> request_id so approve/reject can find it
admin_payment_message_map = {}


def _new_payment_request_id(uid: int, plan_key: str) -> str:
    # short unique id for callbacks
    return f"p{uid}_{plan_key}_{int(datetime.now().timestamp())}{random.randint(100,999)}"


def _upi_payment_caption(plan: dict, plan_key: str) -> str:
    upi_id = UPI_PAYMENT.get('upi_id', '')
    payee = UPI_PAYMENT.get('payee_name', '')
    return (
        f"<b>🧾 Manual UPI Payment</b>\n\n"
        f"<b>Plan:</b> {plan.get('name', plan_key).title()}\n"
        f"<b>Price:</b> {plan.get('price_display', plan.get('price', ''))}\n\n"
        f"<b>UPI ID:</b> <code>{_h(upi_id)}</code>\n"
        f"<b>Name:</b> {_h(payee)}\n\n"
        f"<blockquote>Scan the QR and pay. Then tap <b>Payment Done</b> and send payment screenshot.</blockquote>"
    )
# ===================== Force Join (Config-based: Channel + Group) =====================

def _forcejoin_usernames():
    # Channel-only force join
    ch = (FORCE_JOIN.get('channel_username') or '').strip().lstrip('@')
    return ch, ''

async def _is_member_of(username: str, user_id: int) -> bool:
    if not username:
        return True
    try:
        entity = await main_bot.get_entity(username)
        await main_bot(GetParticipantRequest(entity, user_id))
        return True
    except (UserNotParticipantError, ChannelPrivateError, ValueError):
        return False
    except Exception:
        # Fail-open to avoid locking everyone out if Telegram errors
        return True

async def is_user_passed_forcejoin(user_id: int) -> bool:
    if await db_call(is_admin, user_id):
        return True
    if not FORCE_JOIN.get('enabled', False):
        return True

    channel_username, group_username = _forcejoin_usernames()
    # If misconfigured (missing usernames), don't block
    if not channel_username and not group_username:
        return True

    ok_channel = await _is_member_of(channel_username, user_id)
    return ok_channel

def forcejoin_keyboard():
    channel_username, _ = _forcejoin_usernames()
    buttons = []
    if channel_username:
        buttons.append([Button.url("Join Channel", f"https://t.me/{channel_username}")])
    buttons.append([Button.inline("Verify", b"force_verify")])
    return buttons

async def send_forcejoin_prompt(event, edit=False):
    msg = FORCE_JOIN.get('message') or "**Access Locked**\n\nPlease join required chats and verify."
    img = (FORCE_JOIN.get('image_url') or '').strip()

    if edit:
        # can't edit media easily; edit text only
        await event.edit(msg, buttons=forcejoin_keyboard())
        return

    if img:
        await event.respond(file=img, message=msg, buttons=forcejoin_keyboard())
    else:
        await event.respond(msg, buttons=forcejoin_keyboard())

async def enforce_forcejoin_or_prompt(event, edit=False) -> bool:
    uid = event.sender_id
    if await is_user_passed_forcejoin(uid):
        return True
    await send_forcejoin_prompt(event, edit=edit)
    return False

# ===================== Lightweight TTL caches (performance) =====================
# This bot uses a *synchronous* Mongo driver on a single asyncio event loop, so
# every DB read blocks ALL tasks (command handling + every account's forwarding
# loop). As the number of active users grows, the cumulative blocking time is
# what makes the bot "lag" and delays balloon.
#
# These short-lived caches collapse the bursts of repeated identical reads that
# happen in hot paths (the forwarding loop reads the same user/account doc many
# times per round; send_log + is_admin run on every single message). TTLs are
# deliberately tiny so interactive correctness is effectively unchanged, while
# the per-second DB pressure drops dramatically.
import threading as _threading

_cache_lock = _threading.Lock()
_user_cache = {}        # user_id(int)      -> (expires_monotonic, user_doc)
_admin_cache = {}       # user_id(int)      -> (expires_monotonic, bool)
_logs_chat_cache = {}   # account_id(str)   -> (expires_monotonic, chat_id)

_USER_CACHE_TTL = float(os.getenv('USER_CACHE_TTL', '15'))
_ADMIN_CACHE_TTL = float(os.getenv('ADMIN_CACHE_TTL', '60'))
_LOGS_CACHE_TTL = float(os.getenv('LOGS_CACHE_TTL', '30'))
_ACCOUNTS_CACHE_TTL = float(os.getenv('ACCOUNTS_CACHE_TTL', '10'))

# Optional Redis (REDIS_URL) with in-process fallback — speeds repeated UI reads
class HotCache:
    """Tiny key/value layer. Redis if REDIS_URL is set and reachable, else memory."""
    def __init__(self):
        self._mem = {}
        self._r = None
        url = (os.getenv('REDIS_URL') or '').strip()
        if url:
            try:
                import redis as _redis
                self._r = _redis.from_url(url, socket_connect_timeout=0.4, socket_timeout=0.4, decode_responses=True)
                self._r.ping()
                print(f"[CACHE] Redis connected")
            except Exception as e:
                print(f"[CACHE] Redis unavailable ({e}); using memory only")
                self._r = None

    def get(self, key: str):
        if self._r is not None:
            try:
                v = self._r.get(key)
                if v is not None:
                    import json as _json
                    return _json.loads(v)
            except Exception:
                pass
        item = self._mem.get(key)
        if not item:
            return None
        exp, val = item
        if exp and time.monotonic() > exp:
            self._mem.pop(key, None)
            return None
        return val

    def set(self, key: str, value, ttl: float = 30.0):
        if self._r is not None:
            try:
                import json as _json
                self._r.setex(key, max(1, int(ttl)), _json.dumps(value, default=str))
            except Exception:
                pass
        self._mem[key] = (time.monotonic() + float(ttl), value)

    def delete(self, key: str):
        self._mem.pop(key, None)
        if self._r is not None:
            try:
                self._r.delete(key)
            except Exception:
                pass

HOT = HotCache()

_accounts_cache = {}  # owner_id(int) -> (expires_monotonic, list[acc])


def invalidate_user_cache(user_id=None):
    with _cache_lock:
        if user_id is None:
            _user_cache.clear()
            _accounts_cache.clear()
        else:
            _user_cache.pop(int(user_id), None)
            _accounts_cache.pop(int(user_id), None)


def invalidate_accounts_cache(owner_id=None):
    with _cache_lock:
        if owner_id is None:
            _accounts_cache.clear()
        else:
            _accounts_cache.pop(int(owner_id), None)


def invalidate_admin_cache(user_id=None):
    with _cache_lock:
        if user_id is None:
            _admin_cache.clear()
        else:
            _admin_cache.pop(int(user_id), None)


def invalidate_logs_cache():
    with _cache_lock:
        _logs_chat_cache.clear()


async def cache_sweeper():
    """Periodically purge EXPIRED TTL-cache entries. Without this, the caches only
    overwrite on access, so keys for one-time users/accounts linger forever ->
    slow unbounded memory growth over weeks."""
    interval = int(os.getenv('CACHE_SWEEP_INTERVAL', '300'))
    while True:
        try:
            await asyncio.sleep(interval)
            now = time.monotonic()
            with _cache_lock:
                for cache in (_user_cache, _admin_cache, _logs_chat_cache, _accounts_cache):
                    for k in [k for k, v in cache.items() if v[0] <= now]:
                        cache.pop(k, None)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[CACHE] sweep error: {e}")


STATE_TTL = int(os.getenv('STATE_TTL', '1800'))              # drop abandoned UI/login flows after this (s)
UPI_PENDING_TTL = int(os.getenv('UPI_PENDING_TTL', '7200'))  # drop unsubmitted UPI requests after this (s)


async def user_states_reaper():
    """Drop abandoned UI-flow states so their live Telethon login clients don't
    leak (memory + open connections). Each state is lazily time-stamped; states
    idle longer than STATE_TTL are removed and any client they hold is
    disconnected. Also expires stale pending_upi_payments. Progressing a flow
    replaces the state dict (fresh stamp), so only truly idle flows are reaped.
    Does NOT touch otp_forwarding_active (intentionally long-lived)."""
    interval = int(os.getenv('STATE_SWEEP_INTERVAL', '300'))
    while True:
        try:
            await asyncio.sleep(interval)
            now = time.monotonic()
            for _uid in list(user_states.keys()):
                st = user_states.get(_uid)
                if not isinstance(st, dict):
                    continue
                ts = st.get('_reap_ts')
                if ts is None:
                    st['_reap_ts'] = now          # first sighting -> start its idle clock
                    continue
                if now - ts >= STATE_TTL:
                    cl = st.get('client')
                    if cl is not None:
                        try:
                            await cl.disconnect()
                        except Exception:
                            pass
                    user_states.pop(_uid, None)
            # Expire stale UPI payment requests (they carry a created_at datetime).
            try:
                cutoff = datetime.now() - timedelta(seconds=UPI_PENDING_TTL)
                for _rid in list(pending_upi_payments.keys()):
                    _p = pending_upi_payments.get(_rid) or {}
                    _ca = _p.get('created_at')
                    if isinstance(_ca, datetime) and _ca < cutoff:
                        pending_upi_payments.pop(_rid, None)
            except Exception:
                pass
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[REAPER] error: {e}")


def uupdate(flt, update, *args, **kwargs):
    """users_col.update_one wrapper that auto-invalidates the user cache. ALL user
    writes go through this so cached get_user() reads are never stale after a write
    (toggles/settings reflect immediately)."""
    res = users_col.update_one(flt, update, *args, **kwargs)
    try:
        uid = flt.get('user_id') if isinstance(flt, dict) else None
        if uid is not None:
            invalidate_user_cache(uid)
            try:
                invalidate_dash_text(uid)
            except Exception:
                pass
    except Exception:
        pass
    return res


# Thread pool for pymongo. Per process — workers do not need the UI's large pool.
_DB_POOL_DEFAULT = '32' if _IS_WORKER_ONLY else ('64' if _EARLY_BOT_ROLE == 'bot' else '128')
_DB_EXECUTOR = concurrent.futures.ThreadPoolExecutor(
    max_workers=int(os.getenv('DB_THREAD_POOL', _DB_POOL_DEFAULT)),
    thread_name_prefix='db',
)


async def db_call(func, *args, **kwargs):
    """Run blocking pymongo on a dedicated pool so the event loop never freezes.
    ALWAYS use this from async UI handlers and forwarding loops."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(_DB_EXECUTOR, lambda: func(*args, **kwargs))


def is_admin(user_id):
    # Owner is always admin
    try:
        uid = int(user_id)
    except Exception:
        return False
    if uid == int(CONFIG['owner_id']):
        return True
    now = time.monotonic()
    with _cache_lock:
        hit = _admin_cache.get(uid)
        if hit and hit[0] > now:
            return hit[1]
    try:
        result = admins_col.find_one({'user_id': uid}) is not None
    except Exception as e:
        print(f"[ERROR] is_admin check failed for {user_id}: {e}")
        return False
    with _cache_lock:
        _admin_cache[uid] = (now + _ADMIN_CACHE_TTL, result)
    return result

def get_user(user_id):
    uid = int(user_id)
    now = time.monotonic()
    # Cache hit: UI renders call get_user several times per tap; caching collapses
    # those to one DB read per USER_CACHE_TTL. Writes go through uupdate() which
    # invalidates this cache, so reads are never stale after a write.
    with _cache_lock:
        hit = _user_cache.get(uid)
        if hit and hit[0] > now:
            return dict(hit[1])
    user = users_col.find_one({'user_id': uid})
    if not user:
        quiet_default = DEFAULT_QUIET_HOURS.copy()
        user = {
            'user_id': uid,
            'tier': 'free',
            'max_accounts': FREE_TIER['max_accounts'],
            'approved': False,
            'autoreply_enabled': False,
            'interval_preset': 'fast',
            'forwarding_mode': 'auto',
            'ads_mode': 'saved',
            'smart_rotation': True,
            'toxic_prune': False,
            'quiet_hours': quiet_default,
            'created_at': datetime.now(),
            '_is_new_user': True
        }
        users_col.insert_one(user)
    elif not user.get('quiet_hours'):
        quiet_default = DEFAULT_QUIET_HOURS.copy()
        uupdate({'user_id': uid}, {'$set': {'quiet_hours': quiet_default}})
        user['quiet_hours'] = quiet_default
    with _cache_lock:
        _user_cache[uid] = (now + _USER_CACHE_TTL, user)
    return dict(user)

def get_user_cached(user_id):
    """Short-TTL cached read of get_user for hot paths (forwarding loop + derived
    permission helpers). Returns a shallow copy so callers can't pollute the
    cache. Deliberately NOT used for ban-checks / new-user flows, which stay on
    the uncached get_user()."""
    uid = int(user_id)
    now = time.monotonic()
    with _cache_lock:
        hit = _user_cache.get(uid)
        if hit and hit[0] > now:
            return dict(hit[1])
    user = get_user(uid)
    with _cache_lock:
        _user_cache[uid] = (now + _USER_CACHE_TTL, user)
    return dict(user)

def is_premium(user_id):
    """Premium check with expiry enforcement (auto-downgrade when expired)."""
    if is_admin(user_id):
        return True
    user = get_user_cached(user_id)
    if not user or user.get('tier') != 'premium':
        return False

    expires_at = user.get('premium_expires_at') or user.get('premium_expiry') or user.get('plan_expiry')
    if expires_at:
        try:
            if expires_at < datetime.now():
                remove_user_premium(user_id)
                return False
        except Exception:
            # If comparison fails, fail-open (keep premium) to avoid breaking users
            return True

    return True

def has_per_account_config_access(user_id):
    """Check if user can access per-account config (Pro/Elite only).
    Pro=3, Elite=4, Starter=2 -> threshold >=3 keeps Pro/Elite in, Starter out."""
    if is_admin(user_id):
        return True
    return get_user_max_accounts(user_id) >= 3

def get_user_tier_settings(user_id):
    if is_premium(user_id):
        return PREMIUM_TIER.copy()
    return FREE_TIER.copy()

def get_user_auto_group_limit(user_id):
    """Plan-specific cap for auto groups per account."""
    if is_admin(user_id):
        return None  # unlimited
    user = get_user_cached(user_id)
    if not is_premium(user_id):
        return FREE_TIER.get('max_auto_groups', 0)
    plan_key = normalize_plan_key(user.get('plan') or user.get('plan_name'))
    if plan_key in PLANS:
        return PLANS[plan_key].get('max_auto_groups')
    return PREMIUM_TIER.get('max_auto_groups')

def _groups_per_round_for_user(user):
    """Per-round group cap (rotation window) from the user's plan. 0 = unlimited.
    PURE function on the already-loaded `user` doc -> adds NO DB call in the hot
    forwarding loop (uses in-memory config + the round's user document)."""
    try:
        if is_admin(user.get('user_id')):
            return 0   # admins: no per-round group cap (unlimited)
        plan_key = normalize_plan_key(user.get('plan') or user.get('plan_name'))
        if plan_key in PLANS:
            return int(PLANS[plan_key].get('max_groups_per_round', 0) or 0)
    except Exception:
        pass
    return 0   # unknown / legacy / admin (no plan set) -> uncapped

def get_user_max_accounts(user_id):
    if is_admin(user_id):
        return 999  # Admins get unlimited accounts
    user = get_user_cached(user_id)
    return get_plan_max_accounts(user)

def normalize_plan_key(value: str) -> str:
    key = (value or "").strip().lower()
    if not key:
        return ""
    name_map = {
        # new display names
        'starter': 'grow',
        'pro': 'prime',
        'elite': 'dominion',
        # legacy display names (existing users' stored plan_name) -> still resolve
        'kai': 'grow',
        'super': 'prime',
        'ultra': 'dominion',
    }
    if key in name_map:
        return name_map[key]
    if key == 'domi':
        return 'dominion'
    if key in ('grow', 'prime', 'dominion'):
        return key
    return ""

def get_plan_label(plan_key: str) -> str:
    key = normalize_plan_key(plan_key)
    return {
        'grow': 'Starter',
        'prime': 'Pro',
        'dominion': 'Elite',
    }.get(key, plan_key.capitalize() if plan_key else "No Plan")

def _plan_key_for_user(user_id) -> str:
    try:
        if is_admin(user_id):
            return 'dominion'
        user = get_user(user_id)
        if not user or user.get('tier') != 'premium':
            return ''
        return normalize_plan_key(user.get('plan') or user.get('plan_name') or '') or ''
    except Exception:
        return ''


def can_use_private_autoreply(user_id) -> bool:
    """Pro + Elite only (not Starter). Admins always."""
    try:
        uid = int(user_id)
    except Exception:
        return False
    if is_admin(uid):
        return True
    plan = _plan_key_for_user(uid)
    if plan in PLANS and PLANS[plan].get('auto_reply_enabled'):
        return True
    try:
        if get_user(uid).get('private_autoreply_allowed'):
            return True
    except Exception:
        pass
    return False


def get_max_keyword_replies(user_id) -> int:
    """0 Starter, 2 Pro, 50 Elite, admin 50."""
    try:
        uid = int(user_id)
    except Exception:
        return 0
    if is_admin(uid):
        return 50
    plan = _plan_key_for_user(uid)
    if plan in PLANS:
        try:
            return max(0, int(PLANS[plan].get('max_keyword_replies', 0) or 0))
        except Exception:
            return 0
    try:
        if get_user(uid).get('private_autoreply_allowed'):
            return 2
    except Exception:
        pass
    return 0


def can_use_group_autoreply(user_id) -> bool:
    """Elite only (or admin / group_autoreply_allowed grant)."""
    try:
        uid = int(user_id)
    except Exception:
        return False
    if is_admin(uid):
        return True
    user = get_user(uid)
    if user.get('group_autoreply_allowed'):
        return True
    if not is_premium(uid):
        return False
    plan = normalize_plan_key(user.get('plan') or user.get('plan_name') or '')
    if plan in PLANS and PLANS[plan].get('group_autoreply_enabled'):
        return True
    return plan == 'dominion'


def get_display_plan_name(user: dict) -> str:
    plan_name = (user.get('plan_name') or "").strip()
    if plan_name:
        normalized = plan_name.lower()
        name_map = {
            'grow': 'Starter',
            'prime': 'Pro',
            'dominion': 'Elite',
            # map any stored value (new OR legacy) to the current display name
            'starter': 'Starter',
            'pro': 'Pro',
            'elite': 'Elite',
            'kai': 'Starter',
            'super': 'Pro',
            'ultra': 'Elite',
        }
        return name_map.get(normalized, plan_name)
    plan_key = normalize_plan_key(user.get('plan'))
    return {
        'grow': 'Starter',
        'prime': 'Pro',
        'dominion': 'Elite',
    }.get(plan_key, "No Plan")

def get_plan_max_accounts(user: dict) -> int:
    # Admin-granted EXTRA slots on top of the plan cap (set via /addaccount).
    # Read from the already-loaded user doc -> no extra DB call in hot paths.
    try:
        bonus = max(0, int((user or {}).get('bonus_accounts', 0) or 0))
    except Exception:
        bonus = 0
    if not user or user.get('tier') != 'premium':
        return FREE_TIER['max_accounts'] + bonus
    plan_key = normalize_plan_key(user.get('plan') or user.get('plan_name'))
    if plan_key in PLANS:
        return PLANS[plan_key]['max_accounts'] + bonus
    old_max = user.get('max_accounts', PREMIUM_TIER['max_accounts'])
    if old_max >= 15:
        return PLANS['dominion']['max_accounts'] + bonus
    if old_max >= 7:
        return PLANS['prime']['max_accounts'] + bonus
    if old_max >= 3:
        return PLANS['grow']['max_accounts'] + bonus
    return PLANS['grow']['max_accounts'] + bonus

def is_approved(user_id):
    if is_admin(user_id):
        return True
    user = get_user_cached(user_id)
    return user.get('approved', False)

def approve_user(user_id):
    uupdate(
        {'user_id': int(user_id)},
        {'$set': {'approved': True, 'approved_at': datetime.now()}},
        upsert=True
    )
    invalidate_user_cache(user_id)

def set_user_premium(user_id, max_accounts, plan_name='premium'):
    """Grant premium with 30-day expiry (monthly subscription)."""
    expires_at = datetime.now() + timedelta(days=30)
    
    # Determine plan key (grow, prime, dominion) from plan_name
    plan_key = normalize_plan_key(plan_name) or 'grow'
    plan_label = get_plan_label(plan_key)
    
    uupdate(
        {'user_id': int(user_id)},
        {'$set': {
            'tier': 'premium',
            'plan': plan_key,  # Store plan key (grow/prime/dominion) for profile display
            'max_accounts': max_accounts,
            'plan_name': plan_label,  # Store actual plan name (Starter/Pro/Elite)
            'premium_granted_at': datetime.now(),
            'premium_expires_at': expires_at,
            'plan_expiry': expires_at,  # Add this for profile display
            'approved': True
        }},
        upsert=True
    )
    invalidate_user_cache(user_id)

def remove_user_premium(user_id):
    """Downgrade user to free and clear premium-related fields."""
    uupdate(
        {'user_id': int(user_id)},
        {'$set': {
            'tier': 'free',
            'plan': 'scout',
            'plan_name': 'No Plan',
            'max_accounts': FREE_TIER['max_accounts'],
            'premium_expires_at': None,
            'premium_expiry': None,
            'plan_expiry': None,
        }}
    )
    invalidate_user_cache(user_id)

def get_all_users():
    return list(users_col.find({}))

def get_premium_users():
    return list(users_col.find({'tier': 'premium'}))


def _load_account_session(account_id):
    """Load decrypted Telethon session string for one account from Mongo.
    List queries omit session for speed — always use this for connect/refresh."""
    if account_id is None:
        return None
    try:
        from bson import ObjectId
    except Exception:
        ObjectId = None
    acc = None
    candidates = []
    # string _id
    candidates.append({'_id': str(account_id)})
    if ObjectId is not None:
        try:
            candidates.append({'_id': ObjectId(str(account_id))})
        except Exception:
            pass
    for q in candidates:
        try:
            acc = accounts_col.find_one(
                q,
                {'session': 1, 'session_string': 1, 'string_session': 1, 'phone': 1},
            )
            if acc:
                break
        except Exception:
            continue
    if not acc:
        return None
    raw = acc.get('session') or acc.get('session_string') or acc.get('string_session')
    if not raw:
        return None
    try:
        if isinstance(raw, bytes):
            raw = raw.decode('utf-8', errors='ignore')
        raw = str(raw).strip()
        if not raw:
            return None
        try:
            return cipher_suite.decrypt(raw.encode()).decode()
        except Exception:
            # already plain session string
            return raw
    except Exception as e:
        print(f"[SESSION] load failed for {account_id}: {e}")
        return None


def get_user_accounts(user_id):
    """Cached account list per owner. Call invalidate_accounts_cache after mutations.
    Projection omits session_string so UI list loads stay light (sessions loaded
    only when a worker connects the client)."""
    uid = int(user_id)
    now = time.monotonic()
    with _cache_lock:
        hit = _accounts_cache.get(uid)
        if hit and hit[0] > now:
            return list(hit[1])
    # Exclude encrypted session blob from list queries (can be large)
    _proj = {
        'session_string': 0,
        'session': 0,
        'string_session': 0,
    }
    accs = list(accounts_col.find({'owner_id': uid}, _proj).sort('added_at', 1))
    with _cache_lock:
        _accounts_cache[uid] = (now + _ACCOUNTS_CACHE_TTL, accs)
    return list(accs)

async def start_broadcast_for_user(target_id: int) -> int:
    accounts = await db_call(get_user_accounts, target_id)
    if not accounts:
        if _fwd_verbose():
            if _fwd_verbose():
                print(f"[ADS DEBUG] start_broadcast: user {target_id} has 0 accounts")
        return 0
    user = await db_call(get_user, target_id)
    # Default matches get_user() creation path ('auto' = Groups Only)
    fwd_mode = user.get('forwarding_mode') or 'auto'
    started = 0
    for acc in accounts:
        acc_id = str(acc['_id'])
        is_fwd = acc.get('is_forwarding', False)
        if _fwd_verbose():
            print(f"[ADS DEBUG] Account {acc_id}: is_forwarding={is_fwd}, fwd_mode={fwd_mode}, "
              f"auth_invalid={acc.get('auth_invalid')}, health_paused={acc.get('health_paused')}")

        def _prep(_acc=acc, _mode=fwd_mode, _already=is_fwd):
            has_groups = False
            topic_count = 0
            auto_count = 0
            if _mode in ('topics', 'both'):
                topic_count = account_topics_col.count_documents(
                    {'account_id': {'$in': _account_id_variants(_acc['_id'])}})
                has_groups = topic_count > 0
            if _mode in ('auto', 'both'):
                auto_count = account_auto_groups_col.count_documents(
                    {'account_id': {'$in': _account_id_variants(_acc['_id'])}})
                if not has_groups:
                    has_groups = auto_count > 0
            # Always force is_forwarding=True so Stop→Start within a second works.
            accounts_col.update_one(
                {'_id': _acc['_id']},
                {'$set': {'is_forwarding': True},
                 '$unset': {'health_paused': '', 'health_paused_at': '', 'auth_invalid': ''}},
            )
            try:
                invalidate_accounts_cache(_acc.get('owner_id') or target_id)
            except Exception:
                pass
            return has_groups, topic_count, auto_count

        has_groups, topic_count, auto_count = await db_call(_prep)
        if _fwd_verbose():
            print(f"[ADS DEBUG] Account {acc_id}: has_groups={has_groups} "
              f"(topics={topic_count}, auto_groups={auto_count}, mode={fwd_mode})")
        if not has_groups:
            if _fwd_verbose():
                print(f"[ADS DEBUG] Account {acc_id}: WARNING no groups for mode={fwd_mode} — "
                  f"loop will idle until groups are added")

        # Always ensure a local supervisor is running when we own the account.
        # Previously "already forwarding" was skipped entirely, which left
        # is_forwarding=True with a dead task and zero sends.
        owns = _owns_account(acc['_id'])
        task_ok = ensure_account_running(target_id, acc['_id'])
        existing = forwarding_tasks.get(acc['_id'])
        running = bool(existing and not existing.done())
        if _fwd_verbose():
            print(f"[ADS DEBUG] Account {acc_id}: owns={owns} ensure={task_ok} task_running={running}")
        if task_ok or running:
            status_msg = " (WARNING: No groups configured!)" if not has_groups else ""
            already_note = " (was already is_forwarding — re-ensured task)" if is_fwd else ""
            if _fwd_verbose():
                print(f"[ADS] Started/ensured forwarding task for account {acc['_id']}{status_msg}{already_note}")
        elif not owns:
            if _fwd_verbose():
                print(f"[ADS] Account {acc_id} owned by another worker/node — reconciler will pick it up")
        started += 1
    if started:
        if _fwd_verbose():
            print(f"[ADS] Started/ensured {started} accounts for user {target_id}")
    return started

async def stop_broadcast_for_user(target_id: int, *, by_admin: bool = False) -> int:
    """Stop all of a user's broadcasts quickly.

    Order matters for instant Stop→Start:
      1) Flip is_forwarding=False in ONE update (desired state)
      2) Cancel local tasks immediately
      3) Logger notify in background (never blocks the UI)
    """
    accounts = await db_call(get_user_accounts, target_id)
    ids = [acc['_id'] for acc in accounts if acc.get('is_forwarding')]
    if not ids:
        return 0

    await db_call(
        accounts_col.update_many,
        {'_id': {'$in': ids}},
        {'$set': {'is_forwarding': False}},
    )
    try:
        invalidate_accounts_cache(target_id)
    except Exception:
        pass

    for acc_id in ids:
        ensure_account_stopped(acc_id)

    stopped = len(ids)

    async def _notify():
        try:
            user_doc = await db_call(get_user_cached, target_id)
            logs_chat_id = (user_doc or {}).get('logs_chat_id')
            if logs_chat_id and CONFIG.get('logger_bot_token'):
                reason = "by admin" if by_admin else "by user"
                log_msg = (
                    "<b>Broadcast Stopped</b>\n\n"
                    f"<b>Accounts Stopped:</b> <code>{stopped}</code>\n\n"
                    f"<i>Broadcasts stopped {reason}.</i>"
                )
                await _tg_send_http(CONFIG['logger_bot_token'], int(logs_chat_id), log_msg)
        except Exception as e:
            if _fwd_verbose():
                print(f"[LOG ERROR] Failed to send stop log to user {target_id}: {e}")
    try:
        _spawn_bg(_notify())
    except Exception:
        pass
    return stopped


async def stop_all_broadcasts() -> int:
    stopped = 0
    accs = await db_call(lambda: list(accounts_col.find({'is_forwarding': True}, {'_id': 1})))
    for acc in accs:
        await db_call(accounts_col.update_one, {'_id': acc['_id']}, {'$set': {'is_forwarding': False}})
        if acc['_id'] in forwarding_tasks:
            forwarding_tasks[acc['_id']].cancel()
            del forwarding_tasks[acc['_id']]
        stopped += 1
    if stopped:
        if _fwd_verbose():
            print(f"[ADS] Stopped {stopped} accounts (global)")
    return stopped

def get_account_by_id(account_id):
    from bson.objectid import ObjectId
    try:
        return accounts_col.find_one({'_id': ObjectId(account_id)})
    except:
        return None

def get_account_by_index(user_id, index):
    accounts = get_user_accounts(user_id)
    if 0 < index <= len(accounts):
        return accounts[index - 1]
    return None

def get_account_settings(account_id):
    settings = account_settings_col.find_one({'account_id': account_id})
    if not settings:
        settings = {
            'account_id': account_id,
            # group_delay deprecated (no longer used)
            'msg_delay': FREE_TIER['msg_delay'],
            'round_delay': FREE_TIER['round_delay'],
            'logs_chat_id': None,
        }
        account_settings_col.insert_one(settings)
    return settings

def update_account_settings(account_id, updates):
    account_settings_col.update_one(
        {'account_id': account_id},
        {'$set': updates},
        upsert=True
    )

def get_account_stats(account_id):
    stats = account_stats_col.find_one({'account_id': account_id})
    if not stats:
        stats = {'account_id': account_id, 'total_sent': 0, 'total_failed': 0, 'last_forward': None}
        account_stats_col.insert_one(stats)
    return stats

def update_account_stats(account_id, sent=0, failed=0):
    account_stats_col.update_one(
        {'account_id': account_id},
        {'$inc': {'total_sent': sent, 'total_failed': failed}, '$set': {'last_forward': datetime.now()}},
        upsert=True
    )

# ---- Batched, single-query helpers (replace N+1 per-account loops in renders) ----
def any_account_has_autoreply(accounts):
    ids = [str(acc['_id']) for acc in accounts]
    if not ids:
        return False
    return account_settings_col.count_documents(
        {'account_id': {'$in': ids}, 'auto_reply': {'$nin': [None, '']}}
    ) > 0

def bulk_topic_counts(accounts, topics):
    """One aggregation -> {topic: count} across all the user's accounts."""
    ids = [acc['_id'] for acc in accounts]
    if not ids:
        return {}
    agg = account_topics_col.aggregate([
        {'$match': {'account_id': {'$in': ids}, 'topic': {'$in': list(topics)}}},
        {'$group': {'_id': '$topic', 'n': {'$sum': 1}}},
    ])
    return {d['_id']: d['n'] for d in agg}

def bulk_auto_group_count(accounts):
    ids = [str(acc['_id']) for acc in accounts]
    if not ids:
        return 0
    return account_auto_groups_col.count_documents({'account_id': {'$in': ids}})

def bulk_total_sent(accounts):
    ids = [str(acc['_id']) for acc in accounts]
    if not ids:
        return 0
    return sum(s.get('total_sent', 0) for s in
               account_stats_col.find({'account_id': {'$in': ids}}, {'total_sent': 1}))

def is_group_failed(account_id, group_key):
    failed = account_failed_groups_col.find_one({'account_id': account_id, 'group_key': group_key})
    return failed is not None

def mark_group_failed(account_id, group_key, error):
    account_failed_groups_col.update_one(
        {'account_id': account_id, 'group_key': group_key},
        {'$set': {'error': str(error)[:200], 'failed_at': datetime.now()}},
        upsert=True
    )

def clear_failed_groups(account_id):
    account_failed_groups_col.delete_many({'account_id': account_id})

# ---- Toxic-group detection & auto-pruning -------------------------------
# Strike thresholds per classified reason (config constants are defined lower in
# the file, so resolve them lazily at call time).
def _toxic_threshold(reason):
    return {
        'admin_only': TOXIC_ADMIN_ONLY_STRIKES,
        'banned': TOXIC_BAN_STRIKES,
        'slowmode': TOXIC_SLOWMODE_STRIKES,
    }.get(reason, 3)
_TOXIC_REASON_LABELS = {
    'admin_only': 'admin-only (posting blocked)',
    'banned': 'account is banned there',
    'slowmode': 'heavy slow-mode',
}

def _toxic_prune_enabled(user_id: int) -> bool:
    """Per-user toggle for dropping toxic groups (default ON)."""
    try:
        return bool(get_user_cached(int(user_id)).get('toxic_prune', TOXIC_PRUNE_DEFAULT))
    except Exception:
        return TOXIC_PRUNE_DEFAULT

def record_toxic_strike(account_id, group_key, group_title, reason):
    """Add a toxic strike for (account, group). Returns True if the group JUST
    crossed its prune threshold (caller should stop sending to it). Sync -> db_call."""
    acc_id_str = str(account_id)
    threshold = _toxic_threshold(reason)
    toxic_groups_col.update_one(
        {'account_id': acc_id_str, 'group_key': group_key},
        {'$inc': {'strikes': 1},
         '$set': {'reason': reason, 'group_title': (group_title or '')[:80],
                  'last_seen': datetime.now()},
         '$setOnInsert': {'first_seen': datetime.now()}},
        upsert=True)
    doc = toxic_groups_col.find_one(
        {'account_id': acc_id_str, 'group_key': group_key}, {'strikes': 1, 'pruned': 1})
    strikes = (doc or {}).get('strikes', 1)
    if strikes >= threshold and not (doc or {}).get('pruned'):
        toxic_groups_col.update_one(
            {'account_id': acc_id_str, 'group_key': group_key},
            {'$set': {'pruned': True, 'pruned_at': datetime.now()}})
        return True
    return False

def load_pruned_group_keys(account_id):
    """Set of group_keys this account should skip (toxic, already pruned). Sync."""
    return {d.get('group_key') for d in toxic_groups_col.find(
        {'account_id': str(account_id), 'pruned': True}, {'group_key': 1})}

def clear_toxic_groups(account_id):
    toxic_groups_col.delete_many({'account_id': str(account_id)})

def get_flood_wait(account_id, group_key):
    doc = account_flood_waits_col.find_one({'account_id': account_id, 'group_key': group_key})
    if doc:
        wait_until = doc.get('wait_until')
        if wait_until and wait_until > datetime.now():
            remaining = (wait_until - datetime.now()).total_seconds()
            return int(remaining)
        else:
            account_flood_waits_col.delete_one({'account_id': account_id, 'group_key': group_key})
    return 0

def set_flood_wait(account_id, group_key, group_name, seconds):
    wait_until = datetime.now() + timedelta(seconds=seconds)
    account_flood_waits_col.update_one(
        {'account_id': account_id, 'group_key': group_key},
        {'$set': {
            'group_name': group_name,
            'wait_seconds': seconds,
            'wait_until': wait_until,
            'created_at': datetime.now()
        }},
        upsert=True
    )

def clear_flood_waits(account_id):
    account_flood_waits_col.delete_many({'account_id': account_id})

def get_active_flood_waits(account_id):
    now = datetime.now()
    return account_flood_waits_col.count_documents({
        'account_id': account_id,
        'wait_until': {'$gt': now}
    })

def generate_token(length=16):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

# ---- Click tracking (opt-in; shown only via the dashboard Results button) ----
# The actual redirect + click counting runs SIDE-BY-SIDE in n8n
# (see n8n/click-tracker.workflow.json). The bot just creates tracked links and
# reads the counts n8n writes into click_links.
N8N_TRACK_BASE = os.getenv('N8N_TRACK_BASE', '').strip()  # e.g. https://your-n8n/webhook/r
# Niche group-finder crawler: after name-search, read top seeds' recent messages
# for more group links and resolve them (finds many more groups per niche).
FIND_CRAWL_SEEDS = int(os.getenv('FIND_CRAWL_SEEDS', '3'))     # how many seed groups to crawl
FIND_CRAWL_MSGS = int(os.getenv('FIND_CRAWL_MSGS', '60'))      # recent messages to scan per seed
FIND_CRAWL_RESOLVE = int(os.getenv('FIND_CRAWL_RESOLVE', '40'))  # max candidate links to resolve (flood-safety)
FIND_DB_RESOLVE = int(os.getenv('FIND_DB_RESOLVE', '30'))  # max n8n-discovered usernames to resolve per search

def create_tracked_link(user_id, target_url):
    code = generate_token(8)
    click_links_col.insert_one({
        'code': code, 'user_id': int(user_id), 'target_url': target_url,
        'clicks': 0, 'created_at': datetime.now(),
    })
    if N8N_TRACK_BASE:
        sep = '&' if '?' in N8N_TRACK_BASE else '?'
        return f"{N8N_TRACK_BASE}{sep}c={code}", code
    return None, code

def get_user_click_stats(user_id):
    docs = list(click_links_col.find({'user_id': int(user_id)}, {'target_url': 1, 'clicks': 1}))
    total = sum(d.get('clicks', 0) for d in docs)
    return total, docs

proxy_index = 0

def get_next_proxy():
    global proxy_index
    if not PROXIES:
        return None
    proxy = PROXIES[proxy_index % len(PROXIES)]
    proxy_index += 1
    
    proxy_type = python_socks.ProxyType.SOCKS5
    if proxy['type'].lower() == 'socks4':
        proxy_type = python_socks.ProxyType.SOCKS4
    elif proxy['type'].lower() == 'http':
        proxy_type = python_socks.ProxyType.HTTP
    
    return (proxy_type, proxy['host'], proxy['port'], True, proxy.get('username'), proxy.get('password'))

def get_proxy_candidates():
    if not PROXIES:
        return [None]
    return [get_next_proxy() for _ in range(len(PROXIES))]

# ===================== Scaling: proxies, sharding, client factory =====================
# Runtime proxy pool = config PROXIES + anything from the PROXY_LIST env var.
# Format per entry (line- or ';'-separated):  type:host:port[:user:pass]
#   type in {socks5, socks4, http}. Proxies are assigned STICKILY per account so
#   an account always egresses from the same IP (Telegram dislikes IP hopping).

def _load_runtime_proxies():
    proxies = list(PROXIES) if PROXIES else []
    raw = os.getenv('PROXY_LIST', '').strip()
    if raw:
        for line in re.split(r'[\n;]+', raw):
            line = line.strip()
            if not line:
                continue
            parts = line.split(':')
            if len(parts) < 3:
                print(f"[PROXY] Ignoring malformed proxy entry: {line}")
                continue
            entry = {'type': parts[0].strip().lower(), 'host': parts[1].strip(), 'port': int(parts[2].strip())}
            if len(parts) >= 5:
                entry['username'] = parts[3].strip()
                entry['password'] = parts[4].strip()
            proxies.append(entry)
    return proxies

RUNTIME_PROXIES = _load_runtime_proxies()


def _proxy_tuple(entry):
    ptype = python_socks.ProxyType.SOCKS5
    t = str(entry.get('type', 'socks5')).lower()
    if t == 'socks4':
        ptype = python_socks.ProxyType.SOCKS4
    elif t == 'http':
        ptype = python_socks.ProxyType.HTTP
    return (ptype, entry['host'], int(entry['port']), True, entry.get('username'), entry.get('password'))


def _stable_hash(value):
    return int(hashlib.md5(str(value).encode()).hexdigest(), 16)


def _proxy_for_account(account_id):
    """Pick a sticky proxy for an account (same account -> same proxy)."""
    if not RUNTIME_PROXIES:
        return None
    idx = _stable_hash(account_id) % len(RUNTIME_PROXIES)
    try:
        return _proxy_tuple(RUNTIME_PROXIES[idx])
    except Exception as e:
        print(f"[PROXY] Failed to build proxy for {account_id}: {e}")
        return None


# Shared resilience settings for every Telethon client we open.
_CLIENT_RESILIENCE_KW = dict(
    connection_retries=None,
    retry_delay=5,
    auto_reconnect=True,
    request_retries=5,
    flood_sleep_threshold=60,
    timeout=int(os.getenv('TG_TIMEOUT', '30')),
    sequential_updates=True,
)


def make_account_client(session, account_id=None, receive_updates=True):
    """Telethon client for a user account (sticky proxy if any).

    receive_updates=False skips the update stream (less RAM). Use for refresh /
    one-shot jobs. Use True when auto-reply must see incoming messages.
    Forwards/sends work the same either way — speed and gaps unchanged.
    """
    proxy = _proxy_for_account(account_id) if account_id is not None else None
    kw = dict(
        connection_retries=None,
        retry_delay=5,
        auto_reconnect=True,
        request_retries=5,
        flood_sleep_threshold=60,
        timeout=int(os.getenv('TG_TIMEOUT', '30')),
        sequential_updates=True,
        receive_updates=bool(receive_updates),
    )
    return TelegramClient(
        StringSession(session), CONFIG['api_id'], CONFIG['api_hash'],
        proxy=proxy,
        **kw,
    )


# ---- Node + worker sharding (horizontal scaling across machines AND processes) ----
# Two levels of deterministic, coordination-free sharding:
#   1. NODE level  -> splits the whole fleet across VPS machines (NODE_COUNT).
#   2. WORKER level -> splits a node's slice across its local processes (WORKER_COUNT).
# To add a VPS: bump NODE_COUNT on every machine and give the new box a fresh
# NODE_ID. Accounts rebalance automatically because ownership is a pure hash of
# the account id -> no registry, no leader election, no cross-node chatter.
NODE_ID = int(os.getenv('NODE_ID', '0'))
NODE_COUNT = max(1, int(os.getenv('NODE_COUNT', '1')))
WORKER_COUNT = max(1, int(os.getenv('WORKER_COUNT', '1')))
WORKER_ID = int(os.getenv('WORKER_ID', '0'))
BOT_ROLE = os.getenv('BOT_ROLE', 'all').strip().lower()   # all | bot | worker
RECONCILE_INTERVAL = int(os.getenv('RECONCILE_INTERVAL', '15'))
START_BATCH = int(os.getenv('START_BATCH', '25'))
# Soft cap: max accounts a single worker will run (0 = unlimited). The manager
# uses this to decide how many workers to spawn; the reconciler enforces it so a
# worker never overloads its event loop / IP.
MAX_ACCOUNTS_PER_WORKER = int(os.getenv('MAX_ACCOUNTS_PER_WORKER', '0'))
# Minimum pause between rounds when target-frequency pacing is on.
TARGET_MIN_CYCLE_FLOOR = int(os.getenv('TARGET_MIN_CYCLE_FLOOR', '30'))
# Hard floor for per-message delay (anti-burst safety; prevents flooding 100 groups
# in seconds even when the cadence is capped). Applies even to old stored values.
MIN_MSG_DELAY = int(os.getenv('MIN_MSG_DELAY', '5'))
# ---- Anti-ban: warmup + smart rotation ----
# Warmup: new accounts ramp up group volume gradually over WARMUP_DAYS (hard cap 2)
# so a fresh account isn't instantly flagged for mass-messaging.
WARMUP_ENABLED = os.getenv('WARMUP_ENABLED', '1').strip().lower() in ('1', 'true', 'yes', 'on')
WARMUP_DAYS = min(2.0, float(os.getenv('WARMUP_DAYS', '2')))   # never exceed 2 days
WARMUP_MIN_FRACTION = float(os.getenv('WARMUP_MIN_FRACTION', '0.15'))  # start at 15% of groups
WARMUP_MIN_GROUPS = int(os.getenv('WARMUP_MIN_GROUPS', '5'))
# Smart rotation: send this many groups per round (one chunk); rounds rotate
# through chunks so the account bursts less. Per-group frequency is preserved.
ROTATION_CHUNK = int(os.getenv('ROTATION_CHUNK', '0'))  # 0 = no cap (send all groups, shuffled when smart_rotation)
# Per-account health: auto-pause an account after this many consecutive rounds
# with a PeerFlood (Telegram is actively flagging it -> stop before it's banned).
HEALTH_PEERFLOOD_LIMIT = int(os.getenv('HEALTH_PEERFLOOD_LIMIT', '3'))
# ---- Toxic-group auto-pruning (default ON per user) ----
# Some groups silently burn accounts: admin-only (can't post), they ban-on-post,
# or they have heavy slow-mode (so the account wastes its cadence retrying). We
# count strikes per (account, group) and, once a group crosses the threshold for
# its reason, STOP sending to it for that account. Users can toggle this off.
TOXIC_PRUNE_DEFAULT = os.getenv('TOXIC_PRUNE_DEFAULT', '0').strip().lower() in ('1', 'true', 'yes', 'on')
TOXIC_ADMIN_ONLY_STRIKES = int(os.getenv('TOXIC_ADMIN_ONLY_STRIKES', '2'))  # can't-write (admin-only)
TOXIC_BAN_STRIKES = int(os.getenv('TOXIC_BAN_STRIKES', '1'))                # banned-on-post -> drop now
TOXIC_SLOWMODE_SEC = int(os.getenv('TOXIC_SLOWMODE_SEC', '3600'))           # slow-mode >= this = "heavy"
TOXIC_SLOWMODE_STRIKES = int(os.getenv('TOXIC_SLOWMODE_STRIKES', '3'))      # heavy-slowmode hits to drop
# ---- Account longevity: optional per-account daily send ceiling ----
# 0 = unlimited (default; keeps the 3/hr-per-group policy intact). Set > 0 to cap
# total sends per account per day as a hard safety ceiling for fragile accounts.
MAX_DAILY_SENDS = int(os.getenv('MAX_DAILY_SENDS', '0'))
# ---- Day/night rhythm: gently slow rounds during server-night hours ----
# 1.0 = off. e.g. 2.0 doubles the round delay during the night window so accounts
# look more human (quieter at night). Independent of per-user Quiet Hours.
NIGHT_SLOWDOWN = float(os.getenv('NIGHT_SLOWDOWN', '1.0'))
NIGHT_START_HOUR = int(os.getenv('NIGHT_START_HOUR', '1'))   # server local hour [0-23]
NIGHT_END_HOUR = int(os.getenv('NIGHT_END_HOUR', '7'))
# Live per-send logging: OFF by default (round summaries already report results).
# Turn ON (LIVE_SEND_LOGS=1) only at small scale; per-send logger calls do not
# scale (a bot FloodWaits past ~30 msgs/sec).
LIVE_SEND_LOGS = os.getenv('LIVE_SEND_LOGS', '0').strip().lower() in ('1', 'true', 'yes', 'on')
DISABLE_TEXT_STYLE = os.getenv('DISABLE_TEXT_STYLE', '0').strip().lower() in ('1', 'true', 'yes', 'on')
LIVE_LOG_MAX_PENDING = int(os.getenv('LIVE_LOG_MAX_PENDING', '200'))
# Chatty per-send stdout (Sent to / USERLOG / DEBUG). Off unless debugging.
_FORWARD_VERBOSE = (
    os.getenv('FORWARD_VERBOSE_LOGS', '0').strip().lower() in ('1', 'true', 'yes', 'on')
    or os.getenv('LOG_LEVEL', 'INFO').strip().upper() == 'DEBUG'
)

def _fwd_verbose():
    return _FORWARD_VERBOSE

if not LIVE_SEND_LOGS:
    try:
        set_global_setting('live_send_logs', False)
    except Exception as _e:
        print(f"[INIT] could not clear live_send_logs in Mongo: {_e}")


def _node_owns_account(account_id):
    """Which VPS node owns this account. With NODE_COUNT=1 (single machine)
    every account belongs to this node."""
    if NODE_COUNT <= 1:
        return True
    return (_stable_hash(account_id) % NODE_COUNT) == (NODE_ID % NODE_COUNT)


def _owns_account(account_id):
    """Does THIS process own (forward) the given account?
    - role 'bot' never forwards.
    - first shard by VPS node (NODE_COUNT), then by worker within the node
      (WORKER_COUNT). The worker hash is salted so it does not correlate with the
      node split (accounts stay evenly spread across a node's workers)."""
    if BOT_ROLE == 'bot':
        return False
    if not _node_owns_account(account_id):
        return False
    return (_stable_hash('w:' + str(account_id)) % WORKER_COUNT) == (WORKER_ID % WORKER_COUNT)


def parse_link(link):
    topic_id = None
    match = re.search(r'/(\d+)$', link)
    if match:
        topic_id = int(match.group(1))
    base = re.sub(r'/\d+$', '', link).rstrip('/')
    if '/c/' in base:
        cid = base.split('/c/')[-1]
        peer = int('-100' + cid)
        url = f"https://t.me/c/{cid}"
    else:
        username = base.split('t.me/')[-1]
        peer = username
        url = f"https://t.me/{username}"
    return peer, url, topic_id


def _account_id_variants(account_id):
    """Return possible stored variants for account_id field (ObjectId vs str)."""
    return [account_id, str(account_id)]

async def delete_account_and_related(account_id):
    from bson.objectid import ObjectId

    variants = set(_account_id_variants(account_id))
    obj_id = None
    try:
        obj_id = ObjectId(str(account_id))
        variants.add(obj_id)
    except Exception:
        obj_id = None

    if obj_id is not None:
        accounts_col.delete_one({'_id': obj_id})
    else:
        accounts_col.delete_one({'_id': account_id})

    variant_list = list(variants)
    account_topics_col.delete_many({'account_id': {'$in': variant_list}})
    account_settings_col.delete_many({'account_id': {'$in': variant_list}})
    account_stats_col.delete_many({'account_id': {'$in': variant_list}})
    account_auto_groups_col.delete_many({'account_id': {'$in': variant_list}})
    account_failed_groups_col.delete_many({'account_id': {'$in': variant_list}})
    account_flood_waits_col.delete_many({'account_id': {'$in': variant_list}})
    toxic_groups_col.delete_many({'account_id': {'$in': variant_list}})
    logger_tokens_col.delete_many({'account_id': {'$in': variant_list}})

    for key in list(variants):
        if key in forwarding_tasks:
            forwarding_tasks[key].cancel()
            del forwarding_tasks[key]
        if key in auto_reply_clients:
            try:
                await auto_reply_clients[key].disconnect()
            except Exception:
                pass
            del auto_reply_clients[key]

    # Evict cached logs-chat entries for this account so the cache doesn't retain
    # dead keys after deletion.
    try:
        with _cache_lock:
            for key in variants:
                _logs_chat_cache.pop(str(key), None)
    except Exception:
        pass

async def safe_leave_chat(client, target):
    """Best-effort leave for channels/supergroups and basic groups.

    `target` can be an entity, username, chat id, or input peer.
    """
    if target is None:
        return False

    try:
        entity = target
        # Resolve to an entity if needed
        if isinstance(target, (str, int)):
            entity = await client.get_entity(target)

        # Channels / supergroups
        if isinstance(entity, Channel) or isinstance(entity, InputPeerChannel):
            peer = await client.get_input_entity(entity)
            await client(LeaveChannelRequest(peer))
            return True

        # Basic groups
        if isinstance(entity, Chat) or isinstance(entity, InputPeerChat):
            chat_id = entity.id if hasattr(entity, 'id') else getattr(entity, 'chat_id', None)
            await client(DeleteChatUserRequest(chat_id=chat_id, user_id='me'))
            return True

        # Fallback: try leave as channel
        peer = await client.get_input_entity(entity)
        await client(LeaveChannelRequest(peer))
        return True

    except Exception:
        return False


def _is_auto_leave_enabled(user_id: int) -> bool:
    """User-level toggle for whether bot should auto-leave groups on permanent send failures."""
    try:
        doc = get_user_cached(int(user_id))
        return bool(doc.get('auto_leave_groups', False))
    except Exception:
        return False

def _parse_time_24h(value: str):
    value = (value or "").strip()
    m = re.match(r'^([01]?\d|2[0-3]):([0-5]\d)$', value)
    if not m:
        return None
    hh = int(m.group(1))
    mm = int(m.group(2))
    return f"{hh:02d}:{mm:02d}"

def _get_quiet_hours_wait(user_id: int, user_doc=None):
    if user_doc is None:
        user_doc = get_user_cached(user_id)
    q = user_doc.get('quiet_hours') or {}
    if not q.get('enabled'):
        return 0, None
    start = _parse_time_24h(q.get('start'))
    end = _parse_time_24h(q.get('end'))
    if not start or not end:
        return 0, None
    label = q.get('label') or f"{start}-{end}"

    # Quiet-hours window is defined in IST (Asia/Kolkata, UTC+5:30). Evaluate it
    # against IST wall-clock regardless of the server's timezone (the VPS runs UTC),
    # otherwise the pause fires at the wrong hours.
    now = datetime.utcnow() + timedelta(hours=5, minutes=30)
    start_h, start_m = map(int, start.split(':'))
    end_h, end_m = map(int, end.split(':'))
    start_dt = now.replace(hour=start_h, minute=start_m, second=0, microsecond=0)
    end_dt = now.replace(hour=end_h, minute=end_m, second=0, microsecond=0)

    start_min = start_h * 60 + start_m
    end_min = end_h * 60 + end_m
    now_min = now.hour * 60 + now.minute

    if start_min <= end_min:
        if now_min < start_min or now_min >= end_min:
            return 0, label
        wait_secs = int((end_dt - now).total_seconds())
        return max(wait_secs, 0), label
    else:
        if now_min >= start_min:
            end_dt = end_dt + timedelta(days=1)
            wait_secs = int((end_dt - now).total_seconds())
            return max(wait_secs, 0), label
        if now_min < end_min:
            wait_secs = int((end_dt - now).total_seconds())
            return max(wait_secs, 0), label
        return 0, label

async def _interruptible_round_sleep(total_seconds, account_id, check_interval=15):
    """Sleep up to total_seconds while still honoring stop requests.

    Stopping a broadcast cancels this task, so asyncio cancellation is the primary
    (instant) stop mechanism. The periodic is_forwarding check is only a fallback
    for flag-based stops. This replaces the old per-second DB poll, cutting idle
    DB load by ~check_interval x per active account (the main cause of lag at
    scale)."""
    remaining = int(max(0, total_seconds))
    while remaining > 0:
        step = min(int(check_interval), remaining)
        await asyncio.sleep(step)
        remaining -= step
        try:
            _touch_activity(account_id)
        except Exception:
            pass
        # Offload the flag-poll to the DB thread pool: at 100-2000 accounts a sync
        # find_one here (every check_interval, per account) stalls the event loop.
        acc = await db_call(get_account_by_id, account_id)
        if not acc or not acc.get('is_forwarding', False):
            return False
    return True


async def _sleep_quiet_hours(wait_seconds: int, account_id):
    remaining = int(wait_seconds)
    while remaining > 0:
        acc = await db_call(get_account_by_id, account_id)
        if not acc or not acc.get('is_forwarding'):
            return False
        step = min(60, remaining)
        await asyncio.sleep(step)
        remaining -= step
    return True

def _format_duration(seconds: int) -> str:
    seconds = int(max(0, seconds))
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    if hours > 0:
        return f"{hours}h {minutes}m"
    if minutes > 0:
        return f"{minutes}m"
    return f"{seconds}s"

def _quiet_hours_label_from_doc(user_doc: dict) -> str:
    q = user_doc.get('quiet_hours') or {}
    if not q.get('enabled'):
        return "Off"
    start = _parse_time_24h(q.get('start'))
    end = _parse_time_24h(q.get('end'))
    if not start or not end:
        return "Off"
    return f"{start}-{end}"


def remove_group_from_db(account_id, target_type, group_key, data=None):
    """Remove a group/topic target permanently from DB for this account."""
    try:
        # Clear failure/flood tracking too
        account_failed_groups_col.delete_one({'account_id': account_id, 'group_key': group_key})
        account_flood_waits_col.delete_one({'account_id': account_id, 'group_key': group_key})

        if target_type == 'topic':
            data = data or {}
            link = data.get('url') or data.get('link') or group_key
            # Backwards compatibility: some docs might store as url
            account_topics_col.delete_many({'account_id': {'$in': _account_id_variants(account_id)}, '$or': [{'link': link}, {'url': link}]})
            return True

        if target_type == 'auto':
            data = data or {}
            gid = data.get('group_id')
            if gid is None:
                try:
                    gid = int(str(group_key))
                except Exception:
                    gid = None
            q = {'account_id': account_id}
            if gid is not None:
                q['group_id'] = gid
            else:
                q['group_id'] = {'$exists': True}
            account_auto_groups_col.delete_many(q)
            return True

        return False
    except Exception:
        return False


async def notify_auto_left(account_id, phone, group_name, group_key, reason=None):
    """Send logger notification when a group is auto-left."""
    try:
        reason_txt = f"\nReason: {reason}" if reason else ""
        msg = (
            "🚪 <b>Auto Left Group</b>\n"
            f"Phone: <code>{_h(phone or 'Unknown')}</code>\n"
            f"Group: <code>{_h(group_name or 'Unknown')}</code>\n"
            f"Key: <code>{_h(str(group_key))}</code>"
            f"{reason_txt}"
        )
        await send_log(account_id, msg)
    except Exception:
        pass


async def notify_toxic_pruned(account_id, phone, group_name, reason):
    """Tell the user a toxic group was dropped (and why), so it stops burning the account."""
    try:
        label = _TOXIC_REASON_LABELS.get(reason, reason)
        msg = (
            "\U0001F6E1\uFE0F <b>Toxic group dropped</b>\n"
            f"Phone: <code>{_h(phone or 'Unknown')}</code>\n"
            f"Group: <code>{_h(group_name or 'Unknown')}</code>\n"
            f"Reason: <code>{_h(label)}</code>\n\n"
            "<i>Stopped sending here to protect this account. Turn off in Settings \u2192 Automation \u2192 Drop Toxic Groups.</i>"
        )
        await send_log(account_id, msg)
    except Exception:
        pass


async def _get_user_logs_chat_id_for_account(account_id):
    """Logs are configured once per USER and apply to all their accounts."""
    key = str(account_id)
    now = time.monotonic()
    with _cache_lock:
        hit = _logs_chat_cache.get(key)
        if hit and hit[0] > now:
            return hit[1]
    result = None
    try:
        def _lookup():
            acc = accounts_col.find_one({'_id': account_id}, {'owner_id': 1})
            if not acc or not acc.get('owner_id'):
                return None
            user_doc = users_col.find_one({'user_id': int(acc['owner_id'])}, {'logs_chat_id': 1})
            return (user_doc or {}).get('logs_chat_id')
        result = await db_call(_lookup)
    except Exception:
        result = None
    with _cache_lock:
        _logs_chat_cache[key] = (now + _LOGS_CACHE_TTL, result)
    return result


# Dedicated HTTP pool for logger-bot API calls (isolated from DB threads)
_HTTP_POOL = concurrent.futures.ThreadPoolExecutor(
    max_workers=int(os.getenv('HTTP_THREAD_POOL', '32')),
    thread_name_prefix='http',
)
_HTTP_SESSION = requests.Session()
try:
    _HTTP_SESSION.mount('https://', requests.adapters.HTTPAdapter(
        pool_connections=20, pool_maxsize=50, max_retries=0))
except Exception:
    pass


async def _tg_send_http(token, chat_id, text, url_button=None):
    """Send a message via the Telegram Bot HTTP API on a dedicated HTTP thread
    pool (isolated from DB work) using a keep-alive Session. Stateless, so it is
    safe from ANY worker process. Returns True on success. Handles 429 with one
    short retry and surfaces real failures instead of silently dropping them."""
    payload = {
        'chat_id': int(chat_id),
        'text': text,
        'parse_mode': 'HTML',
        'disable_web_page_preview': True,
    }
    if url_button:
        label, url = url_button
        payload['reply_markup'] = {'inline_keyboard': [[{'text': label, 'url': url}]]}
    api = f"https://api.telegram.org/bot{token}/sendMessage"

    def _post():
        for attempt in range(2):
            try:
                r = _HTTP_SESSION.post(api, json=payload, timeout=(5, 15))
            except Exception as e:
                if attempt == 0:
                    time.sleep(1)
                    continue
                print(f"[LOG HTTP] network error: {e}")
                return False
            if r.status_code == 429:
                try:
                    retry_after = int(r.json().get('parameters', {}).get('retry_after', 1))
                except Exception:
                    retry_after = 1
                if attempt == 0 and retry_after <= 5:
                    time.sleep(retry_after + 0.5)
                    continue
                print(f"[LOG HTTP] 429 (retry_after={retry_after}) dropped")
                return False
            if not r.ok:
                print(f"[LOG HTTP] {r.status_code}: {r.text[:160]}")
                return False
            return True
        return False

    try:
        return await asyncio.get_running_loop().run_in_executor(_HTTP_POOL, _post)
    except Exception as e:
        print(f"[LOG HTTP] dispatch failed: {e}")
        return False


async def send_log(account_id, message, view_link=None, group_name=None, delay_sec=None, ad_no=None, ad_total=None):
    """Send logs to the user's logs chat via the logger bot HTTP API. Multi-worker
    safe and low-load: one account fetch + a cached user-doc read (no per-call
    blocking find_one on the event loop like before)."""
    try:
        token = CONFIG.get('logger_bot_token')
        if not token:
            if _fwd_verbose():
                print(f"[LIVE_LOG DEBUG] skip account={account_id}: no LOGGER_BOT_TOKEN")
            return
        acc = await db_call(get_account_by_id, account_id)
        owner_id = acc.get('owner_id') if acc else None
        phone = acc.get('phone') if acc else None
        if not owner_id:
            if _fwd_verbose():
                print(f"[LIVE_LOG DEBUG] skip account={account_id}: no owner_id on account doc")
            return
        # get_user is cached (TTL) and carries logs_chat_id + logmode_until.
        user_doc = await db_call(get_user_cached, int(owner_id))
        chat_id = user_doc.get('logs_chat_id') if user_doc else None
        if not chat_id:
            if _fwd_verbose():
                print(f"[LIVE_LOG DEBUG] skip account={account_id} owner={owner_id}: "
                  f"no logs_chat_id (user must /start logger bot & link channel)")
            return
        is_owner_admin = await db_call(is_admin, owner_id)
        until = user_doc.get('logmode_until')
        allow_view = is_owner_admin or (isinstance(until, datetime) and until > datetime.now())

        if view_link and group_name:
            account_text = f"\n<b>Account:</b> <code>{_h(phone or 'Unknown')}</code>" if is_owner_admin else ""
            delay_text = ""
            if delay_sec is not None and is_owner_admin:
                delay_text = f"\n<b>Delay:</b> <code>{delay_sec:.2f}s</code>"
            ad_text = f"\n<b>Ad:</b> <code>#{ad_no} of {ad_total}</code>" if (ad_no and ad_total) else ""
            full_msg = f"<b>Sent to {_h(group_name)}</b>{ad_text}{account_text}{delay_text}"
            ok = await _tg_send_http(token, chat_id, full_msg,
                                url_button=("View Message", view_link) if allow_view else None)
            if ok:
                await _mirror_live_log_to_admin(
                    owner_id, full_msg,
                    url_button=("View Message", view_link) if (allow_view and view_link) else None,
                )
            if not ok:
                if _fwd_verbose():
                    print(f"[LIVE_LOG DEBUG] HTTP send failed account={account_id} chat={chat_id} group={group_name}")
            else:
                if _fwd_verbose():
                    print(f"[LIVE_LOG DEBUG] ok account={account_id} -> {group_name}")
        elif message:
            msg_text = message if isinstance(message, str) else str(message)
            ok = await _tg_send_http(token, chat_id, msg_text)
            if not ok:
                if _fwd_verbose():
                    print(f"[LIVE_LOG DEBUG] HTTP send failed account={account_id} chat={chat_id} (round/status msg)")
    except Exception as e:
        print(f"[LOG ERROR] account={account_id}: {type(e).__name__}: {e}")



async def _mirror_live_log_to_admin(owner_id, html_msg, url_button=None):
    try:
        entry = _logmode_mirrors.get(int(owner_id))
        if not entry:
            return
        admin_id, until = entry
        if not isinstance(until, datetime) or until <= datetime.now():
            _logmode_mirrors.pop(int(owner_id), None)
            return
        token = CONFIG.get('logger_bot_token') or CONFIG.get('bot_token')
        if not token:
            return
        prefix = f"<b>[User {owner_id}]</b> "
        await _tg_send_http(token, int(admin_id), prefix + (html_msg or ''), url_button=url_button)
    except Exception as e:
        print(f"[LOG MIRROR] {e}")


async def add_user_log(user_id, log_msg):
    # `recent_logs` is never read or shown anywhere, so we no longer persist a
    # per-user activity log to MongoDB (it was pure write load on hot user docs).
    # A cheap stdout line keeps the info in server logs at no DB/RAM cost.
    if _fwd_verbose():
        print(f"[USERLOG {user_id}] {log_msg}")


# Bounded fire-and-forget live logging: never let a slow/flood-limited logger bot
# stall forwarding. Beyond LIVE_LOG_MAX_PENDING in-flight logs we simply drop them.
_pending_live_logs = 0

async def _fire_live_log(account_id, view_link, group_name, send_gap, ad_no=None, ad_total=None):
    global _pending_live_logs
    if _pending_live_logs >= LIVE_LOG_MAX_PENDING:
        if _fwd_verbose():
            print(f"[LIVE_LOG DEBUG] drop (pending>={LIVE_LOG_MAX_PENDING}) account={account_id} group={group_name}")
        return
    _pending_live_logs += 1
    try:
        await send_log(account_id, None, view_link=view_link, group_name=group_name, delay_sec=send_gap, ad_no=ad_no, ad_total=ad_total)
    except Exception as e:
        if _fwd_verbose():
            print(f"[LIVE_LOG DEBUG] _fire_live_log error account={account_id}: {type(e).__name__}: {e}")
    finally:
        _pending_live_logs -= 1


_SPINTAX_RE = re.compile(r'\{([^{}]*)\}')


def spin(text):
    """Resolve spintax: '{a|b|c}' -> a random option, supports nesting.
    Returns text unchanged if there are no braces. Used to vary each outgoing ad
    so accounts don't send identical messages to many groups (anti-spam-flag)."""
    if not text or '{' not in text:
        return text
    out = text
    prev = None
    guard = 0
    while '{' in out and out != prev and guard < 50:
        prev = out
        out = _SPINTAX_RE.sub(lambda m: random.choice(m.group(1).split('|')), out)
        guard += 1
    return out


async def find_niche_groups(uid, keyword, limit=50):
    """Search Telegram for public GROUPS matching a niche keyword, using one of
    the user's logged-in accounts (bots can't do this search)."""
    accs = list(accounts_col.find({'owner_id': uid}).limit(1))
    if not accs:
        return None, "no_account"
    acc = accs[0]
    try:
        session = cipher_suite.decrypt(acc['session'].encode()).decode()
    except Exception:
        return None, "session_error"
    client = make_account_client(session, acc['_id'])
    found = []
    try:
        await client.connect()
        if not await client.is_user_authorized():
            return None, "unauthorized"
        from telethon.tl.functions.contacts import SearchRequest
        res = await client(SearchRequest(q=keyword, limit=limit))
        seen = set()
        seed_entities = []
        for ch in getattr(res, 'chats', []) or []:
            uname = getattr(ch, 'username', None)
            if uname and getattr(ch, 'megagroup', False) and uname.lower() not in seen:
                seen.add(uname.lower())
                found.append({'username': uname, 'title': getattr(ch, 'title', uname) or uname, 'members': int(getattr(ch, 'participants_count', 0) or 0)})
                seed_entities.append(ch)

        # ---- Seed crawling: read recent messages of the top seed groups and
        # extract more t.me/@group links mentioned there, then resolve which are
        # public groups. This finds far more niche groups than name-search alone.
        if FIND_CRAWL_SEEDS > 0 and seed_entities:
            link_re = re.compile(r'(?:t\.me/|@)([A-Za-z0-9_]{4,32})')
            candidates = []
            cand_seen = set()
            for seed in seed_entities[:FIND_CRAWL_SEEDS]:
                try:
                    async for msg in client.iter_messages(seed, limit=FIND_CRAWL_MSGS):
                        for u in link_re.findall(msg.message or ''):
                            ul = u.lower()
                            if ul not in seen and ul not in cand_seen and not ul.endswith('bot'):
                                cand_seen.add(ul)
                                candidates.append(u)
                except Exception:
                    continue
            resolved = 0
            for cand in candidates:
                if resolved >= FIND_CRAWL_RESOLVE:
                    break
                try:
                    ent = await client.get_entity(cand)
                    un = getattr(ent, 'username', None)
                    if un and getattr(ent, 'megagroup', False) and un.lower() not in seen:
                        seen.add(un.lower())
                        found.append({'username': un, 'title': getattr(ent, 'title', un) or un, 'members': int(getattr(ent, 'participants_count', 0) or 0)})
                except FloodWaitError:
                    break  # stop crawling on flood, keep what we have
                except Exception:
                    pass
                resolved += 1
                await asyncio.sleep(0.5)

        # ---- Merge in groups discovered by the n8n web/directory scraper.
        # The n8n "group-discovery" workflow writes public @usernames it finds
        # across search engines + Telegram directory sites into the
        # 'discovered_groups' collection. We resolve a capped number here (with
        # the same megagroup filter) so those appear alongside in-app results.
        try:
            disc = await db_call(
                lambda: list(discovered_groups_col.find(
                    {'niche': {'$regex': re.escape(keyword), '$options': 'i'}},
                    {'username': 1}
                ).limit(FIND_DB_RESOLVE * 3))
            )
        except Exception:
            disc = []
        d_resolved = 0
        for d in disc:
            if d_resolved >= FIND_DB_RESOLVE:
                break
            un_raw = (d.get('username') or '').lstrip('@')
            if not un_raw or un_raw.lower() in seen:
                continue
            try:
                ent = await client.get_entity(un_raw)
                un = getattr(ent, 'username', None)
                if un and getattr(ent, 'megagroup', False) and un.lower() not in seen:
                    seen.add(un.lower())
                    found.append({'username': un, 'title': getattr(ent, 'title', un) or un, 'members': int(getattr(ent, 'participants_count', 0) or 0)})
            except FloodWaitError:
                break
            except Exception:
                pass
            d_resolved += 1
            await asyncio.sleep(0.5)
    except FloodWaitError as e:
        return None, f"flood_{getattr(e, 'seconds', 0)}"
    except Exception as e:
        return None, f"error_{str(e)[:60]}"
    finally:
        try:
            await client.disconnect()
        except Exception:
            pass
    found.sort(key=lambda g: g.get('members', 0), reverse=True)
    return found, "ok"


async def _join_groups_for_user(uid, usernames, chat_id, label="Joining groups"):
    """Join a list of group usernames across all the user's accounts, paced and
    FloodWait-safe, with the existing Stop (auto_join_cancel) support. Runs as a
    background task so it never blocks the bot."""
    accs = list(accounts_col.find({'owner_id': uid}))
    if not accs or not usernames:
        return
    from telethon.tl.functions.channels import JoinChannelRequest
    auto_join_cancel[uid] = False
    joined = failed = 0
    total = len(accs) * len(usernames)
    delay = float(os.getenv('JOIN_DELAY', '4'))
    try:
        status = await main_bot.send_message(chat_id, f"<b>{label}…</b>\n0/{total}", parse_mode='html')
    except Exception:
        status = None
    for acc in accs:
        if auto_join_cancel.get(uid):
            break
        try:
            session = cipher_suite.decrypt(acc['session'].encode()).decode()
        except Exception:
            continue
        client = make_account_client(session, acc['_id'])
        try:
            await client.connect()
            if not await client.is_user_authorized():
                continue
            for uname in usernames:
                if auto_join_cancel.get(uid):
                    break
                try:
                    ent = await client.get_entity(uname)
                    await client(JoinChannelRequest(ent))
                    joined += 1
                except FloodWaitError as e:
                    await asyncio.sleep(min(int(getattr(e, 'seconds', 60)) + 1, 600))
                    continue
                except Exception:
                    failed += 1
                await asyncio.sleep(delay + random.uniform(0, delay))
        finally:
            try:
                await client.disconnect()
            except Exception:
                pass
    if status:
        try:
            await main_bot.edit_message(chat_id, status.id,
                f"<b>✅ {label} done</b>\nJoined: <code>{joined}</code>  Failed: <code>{failed}</code>",
                parse_mode='html')
        except Exception:
            pass



async def _note_account_issue(account_id, message: str, code: str = 'error'):
    """Only on real failures — one update per incident."""
    try:
        await db_call(
            accounts_col.update_one,
            {'_id': account_id},
            {'$set': {
                'last_error': str(message)[:200],
                'last_error_code': str(code)[:40],
                'last_error_at': datetime.now(),
            }},
        )
    except Exception as e:
        print(f"[NOTE] {account_id}: {e}")


async def _mark_account_auth_dead(account_id, reason: str = 'auth_invalid'):
    """Stop forwarding until re-add. last_error piggybacks same update (no extra write)."""
    try:
        reason_s = str(reason)[:120]
        await db_call(
            accounts_col.update_one,
            {'_id': account_id},
            {'$set': {
                'is_forwarding': False,
                'auth_invalid': True,
                'auth_invalid_reason': reason_s,
                'auth_invalid_at': datetime.now(),
                'last_error': reason_s,
                'last_error_code': 'auth_invalid',
                'last_error_at': datetime.now(),
            }},
        )
    except Exception as e:
        print(f"[AUTH] mark dead failed {account_id}: {e}")
    try:
        await send_log(
            account_id,
            f"<b>⚠ Session invalid</b>\n\n<code>{_h(str(reason)[:80])}</code>\n"
            f"<i>Forwarding stopped. Re-add this account to continue.</i>",
        )
    except Exception:
        pass


async def run_forwarding_loop(user_id, account_id):
    if _fwd_verbose():
        print(f"[FORWARDING] Starting loop for account {account_id}")
    client = None
    
    try:
        acc = await db_call(accounts_col.find_one, {'_id': account_id})
        if not acc:
            print(f"[FORWARDING] Account {account_id} not found")
            return

        # Used in logger messages (Starting / Completed rounds)
        account_phone = str(acc.get('phone') or acc.get('name') or account_id)
        
        session = cipher_suite.decrypt(acc['session'].encode()).decode()
        # Lean client: receive_updates only when private/group auto-reply is on.
        # Sends/forwards are identical either way; updates off = less RAM per account.
        owner_id = acc.get('owner_id')
        try:
            _user_pre = await db_call(get_user_cached, owner_id) if owner_id is not None else {}
        except Exception:
            _user_pre = {}
        _need_updates = bool(
            (_user_pre or {}).get('autoreply_enabled')
            or (_user_pre or {}).get('group_autoreply_enabled')
        )
        client = make_account_client(
            session, account_id, receive_updates=_need_updates
        )
        await client.connect()
        
        if not await client.is_user_authorized():
            print(f"[FORWARDING] Account {account_id} not authorized - disabling")
            await _mark_account_auth_dead(account_id, 'not_authorized')
            return
        
        if _fwd_verbose():
            print(f"[FORWARDING] Client connected for account {account_id}")
        
        # Attach auto-reply handler to the SAME client (best practice)
        owner_id = acc.get('owner_id')
        user = await db_call(get_user, owner_id)
        # Private and/or group auto-reply (premium/admin)
        _ar_priv = bool(user.get('autoreply_enabled', False))
        _ar_grp = bool(user.get('group_autoreply_enabled', False))
        if _ar_priv or _ar_grp:
            @client.on(events.NewMessage(incoming=True))
            async def autoreply_handler(event):
                try:
                    if isinstance(getattr(event, 'sender', None), User) and event.sender.bot:
                        return
                except Exception:
                    pass
                try:
                    owner = int(owner_id) if owner_id is not None else None
                    if owner is None:
                        return
                    udoc = await db_call(get_user_cached, owner)
                    if not udoc:
                        return
                    is_priv = bool(event.is_private)
                    is_grp = bool(event.is_group or event.is_channel)
                    priv_on = bool(udoc.get('autoreply_enabled', False)) and (
                        await db_call(is_admin, owner) or await db_call(can_use_private_autoreply, owner)
                    )
                    grp_on = bool(udoc.get('group_autoreply_enabled', False)) and (
                        await db_call(is_admin, owner) or await db_call(can_use_group_autoreply, owner)
                    )

                    # ---------- PRIVATE ----------
                    if is_priv and priv_on:
                        incoming = (getattr(event, 'raw_text', None) or event.text or '') or ''
                        incoming_l = incoming.lower()
                        reply_body = None
                        kws = udoc.get('keyword_replies') or []
                        if kws and incoming_l.strip():
                            best_len = -1
                            for item in kws:
                                if not isinstance(item, dict):
                                    continue
                                kw = str(item.get('keyword') or '').strip()
                                msg = str(item.get('message') or '').strip()
                                if not kw or not msg:
                                    continue
                                if kw.lower() in incoming_l and len(kw) > best_len:
                                    best_len = len(kw)
                                    reply_body = msg
                        if not reply_body:
                            sdoc = await db_call(
                                account_settings_col.find_one,
                                {'account_id': str(account_id)},
                            )
                            reply_body = (sdoc or {}).get('auto_reply') if sdoc else None
                            if reply_body:
                                reply_body = str(reply_body).strip() or None
                        if reply_body:
                            # Reuse saved variants (AI only on first miss when few keywords)
                            try:
                                await asyncio.to_thread(
                                    _ensure_text_variants, owner, str(reply_body), 1
                                )
                                reply_body = await asyncio.to_thread(
                                    _pick_send_text, owner, str(reply_body)
                                )
                            except Exception:
                                pass
                            await event.reply(reply_body)
                            _spawn_bg(db_call(
                                account_stats_col.update_one,
                                {'account_id': str(account_id)},
                                {'$inc': {'auto_replies': 1}},
                                upsert=True,
                            ))
                            print(f"[AUTO-REPLY/DM] {account_id} -> {getattr(event, 'sender_id', '?')}")
                        return

                    # ---------- GROUP (mention me OR reply to my message) ----------
                    if is_grp and grp_on and await db_call(can_use_group_autoreply, owner):
                        grp_msg = (udoc.get('group_auto_reply') or '').strip()
                        if not grp_msg:
                            return
                        me = await client.get_me()
                        my_id = int(me.id)
                        my_user = (me.username or '').lower()
                        triggered = False
                        # Reply to one of our messages
                        try:
                            if event.is_reply:
                                rep = await event.get_reply_message()
                                if rep is not None:
                                    sid = getattr(rep, 'sender_id', None)
                                    if sid is None and getattr(rep, 'from_id', None) is not None:
                                        sid = getattr(rep.from_id, 'user_id', None)
                                    if sid is not None and int(sid) == my_id:
                                        triggered = True
                        except Exception:
                            pass
                        # @mention / text mention of this account
                        if not triggered:
                            try:
                                raw = (getattr(event, 'raw_text', None) or event.text or '') or ''
                                if my_user and ('@' + my_user) in raw.lower():
                                    triggered = True
                                entities = getattr(event.message, 'entities', None) or []
                                for ent in entities:
                                    # MessageEntityMentionName / TextMention
                                    ent_name = type(ent).__name__
                                    if 'MentionName' in ent_name or 'TextMention' in ent_name:
                                        uid_ent = getattr(ent, 'user_id', None)
                                        if uid_ent is not None and int(uid_ent) == my_id:
                                            triggered = True
                                            break
                            except Exception:
                                pass
                        if not triggered:
                            return
                        try:
                            await asyncio.to_thread(
                                _ensure_text_variants, owner, str(grp_msg), 1
                            )
                            grp_msg = await asyncio.to_thread(
                                _pick_send_text, owner, str(grp_msg)
                            )
                        except Exception:
                            pass
                        await event.reply(grp_msg)
                        _spawn_bg(db_call(
                            account_stats_col.update_one,
                            {'account_id': str(account_id)},
                            {'$inc': {'group_auto_replies': 1}},
                            upsert=True,
                        ))
                        print(f"[AUTO-REPLY/GROUP] {account_id} chat={event.chat_id}")
                except Exception as e:
                    print(f"[AUTO-REPLY ERROR] {e}")
            print(f"[AUTO-REPLY] Handler attached for account {account_id} (priv={_ar_priv} grp={_ar_grp})")
        
        round_num = 0
        rotation_offset = 0  # advances each round for smart rotation
        peerflood_streak = 0  # consecutive rounds with PeerFlood -> auto-pause
        day_key = datetime.now().date()  # daily-cap reset tracker
        day_sent = 0  # sends counted toward MAX_DAILY_SENDS today
        entity_cache = {}  # group_key -> resolved Telethon entity (reused across rounds)
        _touch_activity(account_id)
        while True:
            try:
                if _is_draining():
                    print(f"[FORWARDING] Drain — stop account {account_id}")
                    break
                _touch_activity(account_id)  # in-memory only, no Mongo
                round_num += 1
                # Bound the per-account entity cache so a huge-group account can't
                # grow it without limit across rounds (memory safety at scale).
                if len(entity_cache) > int(os.getenv('ENTITY_CACHE_MAX', '400')):
                    entity_cache.clear()
                # Connection watchdog: if the link dropped (timeout/network), bring it
                # back before doing work. auto_reconnect usually handles this; this is a
                # belt-and-suspenders check that prevents "stuck disconnected" loops.
                if not client.is_connected():
                    try:
                        await client.connect()
                        if _fwd_verbose():
                            print(f"[FORWARDING] Reconnected account {account_id}")
                    except Exception as e:
                        _health_bump('timeouts')
                        if _fwd_verbose():
                            print(f"[FORWARDING] Reconnect failed {account_id}: {str(e)[:80]}; retrying")
                        await asyncio.sleep(15)
                        continue
                acc = await db_call(accounts_col.find_one, {'_id': account_id})
                if not acc or not acc.get('is_forwarding'):
                    if _fwd_verbose():
                        print(f"[FORWARDING] Account {account_id} stopped")
                    break
                
                # Daily send ceiling (optional account-longevity safety; 0 = unlimited).
                _today = datetime.now().date()
                if _today != day_key:
                    day_key = _today
                    day_sent = 0
                if MAX_DAILY_SENDS and day_sent >= MAX_DAILY_SENDS:
                    if _fwd_verbose():
                        print(f"[FORWARDING] {account_id} hit daily cap {MAX_DAILY_SENDS}; resting")
                    napped = await _interruptible_round_sleep(1800, account_id, check_interval=30)
                    if not napped:
                        break
                    continue
                user = await db_call(get_user_cached, user_id)
                tier_settings = await db_call(get_user_tier_settings, user_id)
                # Default matches user creation ('auto' = Groups Only)
                fwd_mode = user.get('forwarding_mode') or 'auto'
                if _fwd_verbose():
                    if _fwd_verbose():
                        print(f"[FORWARDING DEBUG] round start account={account_id} user={user_id} "
                          f"fwd_mode={fwd_mode} ads_mode={user.get('ads_mode', 'saved')} "
                          f"is_forwarding={acc.get('is_forwarding')}")
                
                # Use user-level interval presets (including custom)
                preset = user.get('interval_preset', 'medium')
                if user.get('msg_delay_sec'):
                    msg_delay = user.get('msg_delay_sec')
                    round_delay = 600  # ignored; cycle uses get_cycle_interval_sec
                elif preset == 'custom' and user.get('custom_interval'):
                    custom = user.get('custom_interval', {})
                    msg_delay = custom.get('msg_delay', 30)
                    round_delay = custom.get('round_delay', 600)
                else:
                    interval_data = INTERVAL_PRESETS.get(preset, INTERVAL_PRESETS['medium'])
                    msg_delay = interval_data.get('msg_delay', tier_settings['msg_delay'])
                    round_delay = interval_data.get('round_delay', tier_settings['round_delay'])
                
                # Safety floor: never burst faster than MIN_MSG_DELAY between sends,
                # even if an old/custom value is lower.
                try:
                    msg_delay = max(MIN_MSG_DELAY, int(msg_delay))
                except Exception:
                    msg_delay = MIN_MSG_DELAY
                
                # ===================== Ads Source (Ads Mode) =====================
                ads_mode = user.get('ads_mode', 'saved')

                ads = []
                custom_text = None
                post_source_entity = None
                post_source_msg_id = None
                post_source_input_peer = None

                if ads_mode == 'custom':
                    custom_text = (user.get('ads_custom_message') or '').strip()
                    if not custom_text:
                        if _fwd_verbose():
                            print(f"[FORWARDING] Custom message not set for {account_id}")
                        await add_user_log(user_id, "Custom message not set - Settings → Ads Mode → Set Custom Message")
                        await asyncio.sleep(60)
                        continue
                    # Per-user variants (max 30 texts × 1 variant). AI once; then used on send.
                    try:
                        await asyncio.to_thread(_ensure_text_variants, user_id, custom_text, 1)
                        custom_text = await asyncio.to_thread(_pick_send_text, user_id, custom_text)
                        if _fwd_verbose():
                            print(f"[FORWARDING] custom text ready for send (variant rotation on)")
                    except Exception as _ai_e:
                        if _fwd_verbose():
                            print(f"[FORWARDING] variant pool skipped: {_ai_e}")
                    ads = [None]
                    if _fwd_verbose():
                        print(f"[FORWARDING] Using Custom Message mode")

                elif ads_mode == 'post':
                    link = (user.get('ads_post_link') or '').strip()
                    if not link:
                        if _fwd_verbose():
                            print(f"[FORWARDING] Post link not set for {account_id}")
                        await add_user_log(user_id, "Post link not set - Settings → Ads Mode → Set Post Link")
                        await asyncio.sleep(60)
                        continue

                    try:
                        tail = link.replace('https://t.me/', '')
                        parts = [p for p in tail.split('/') if p]
                        if parts and parts[0] == 'c' and len(parts) >= 3:
                            cid = parts[1]
                            post_source_entity = int('-100' + str(cid))
                            post_source_msg_id = int(parts[2])
                        else:
                            post_source_entity = parts[0]
                            post_source_msg_id = int(parts[-1])

                        _m = await client.get_messages(post_source_entity, ids=post_source_msg_id)
                        if not _m:
                            raise Exception('Message not found / no access')
                        post_source_input_peer = await client.get_input_entity(post_source_entity)
                        ads = [None]
                        if _fwd_verbose():
                            print(f"[FORWARDING] Using Post Link mode")
                    except Exception as e:
                        if _fwd_verbose():
                            print(f"[FORWARDING] Invalid post link: {e}")
                        await add_user_log(user_id, f"Invalid post link or no access: {str(e)[:120]}")
                        await asyncio.sleep(60)
                        continue

                else:
                    # Saved Messages mode — load from account's own Saved Messages
                    try:
                        async for msg in client.iter_messages('me', limit=10):
                            if msg.text or msg.media:
                                ads.append(msg)
                        ads.reverse()
                    except Exception as e:
                        if _fwd_verbose():
                            print(f"[FORWARDING] Failed reading Saved Messages for {account_id}: "
                                  f"{type(e).__name__}: {e}")
                        await add_user_log(user_id, f"Cannot read Saved Messages: {type(e).__name__}")
                        await asyncio.sleep(60)
                        continue

                    if not ads:
                        if _fwd_verbose():
                            print(f"[FORWARDING] No ads in Saved Messages for {account_id}")
                        await add_user_log(user_id, "No ads in Saved Messages - add messages to Saved Messages")
                        await asyncio.sleep(60)
                        continue
                    if _fwd_verbose():
                        print(f"[FORWARDING DEBUG] Saved Messages sample ids={[m.id for m in ads[:5]]} "
                          f"has_media={[bool(m.media) for m in ads[:5]]}")

                    # Shuffle ads each cycle so the same group does not always
                    # get the same message in the same order (anti-spam pattern).
                    if len(ads) > 1:
                        import random as _rnd
                        _rnd.shuffle(ads)
                    if _fwd_verbose():
                        print(f"[FORWARDING] Loaded {len(ads)} ads from Saved Messages (shuffled)")
                
                # Round start log so user can confirm next round started
                try:
                    # Get user settings for display
                    user_doc = user  # reuse already-loaded user doc (avoids a per-round DB read)
                    
                    # Fix mode display to show user-friendly text
                    if fwd_mode == 'topics':
                        mode_display = "Topics Only"
                    elif fwd_mode == 'auto':
                        mode_display = "Groups Only"
                    elif fwd_mode == 'both':
                        mode_display = "Topics & Groups"
                    else:
                        mode_display = fwd_mode.capitalize()
                    
                    # Get auto leave and auto reply status
                    auto_leave = "✅ ON" if user_doc.get('auto_leave_groups', False) else "❌ OFF"
                    auto_reply = "✅ ON" if user_doc.get('auto_reply_enabled', False) else "❌ OFF"
                    
                    log_msg = (
                        f"<b>🔄 Starting Round {round_num}</b>\n📱 <code>{account_phone}</code>\n\n"
                        f"<b>Mode:</b> <code>{mode_display}</code>\n"
                        f"<b>Ads Mode:</b> <code>{ads_mode.upper()}</code>\n"
                        f"<b>Auto Leave:</b> {auto_leave}\n"
                        f"<b>Auto Reply:</b> {auto_reply}"
                    )
                    await send_log(account_id, log_msg)
                except Exception:
                    pass

                groups_to_forward = []
                
                acc_id_str = str(account_id)
                
                # Preload per-account failure + flood-wait state ONCE per round so we
                # don't fire a blocking DB query for every single group (this was a
                # major source of event-loop blocking for accounts with many groups).
                _now = datetime.now()
                failed_set = set()
                flood_map = {}
                pruned_set = set()
                # Read per-round policy flags ONCE (off-loop) instead of on every
                # send/failure — these hit cached settings/user find_ones otherwise.
                def _round_flags():
                    return (
                        _toxic_prune_enabled(user_id),
                        live_logs_enabled(),
                        _is_auto_leave_enabled(user_id),
                        get_global_setting('warmup_disabled', False),
                    )
                prune_on, _live_logs, auto_leave_on, warmup_off_global = await db_call(_round_flags)
                try:
                    def _load_round_state():
                        fset = {d.get('group_key') for d in account_failed_groups_col.find(
                            {'account_id': acc_id_str}, {'group_key': 1})}
                        fmap = {d.get('group_key'): d.get('wait_until') for d in account_flood_waits_col.find(
                            {'account_id': account_id, 'wait_until': {'$gt': _now}}, {'group_key': 1, 'wait_until': 1})}
                        pset = load_pruned_group_keys(account_id) if prune_on else set()
                        return fset, fmap, pset
                    failed_set, flood_map, pruned_set = await db_call(_load_round_state)
                except Exception as _e:
                    if _fwd_verbose():
                        print(f"[FORWARDING] Preload round state failed: {_e}")
                # Groups we won't send to this round: permanently-failed + (toxic-pruned
                # when the user has Drop Toxic Groups ON).
                skip_set = failed_set | pruned_set
                
                if fwd_mode in ('topics', 'both'):
                    topic_groups = await db_call(lambda: list(account_topics_col.find({'account_id': acc_id_str})))
                    if not topic_groups:
                        topic_groups = await db_call(lambda: list(account_topics_col.find({'account_id': {'$in': _account_id_variants(account_id)}})))
                    
                    for tg in topic_groups:
                        link = tg.get('link') or tg.get('url')
                        if link and 't.me/' in link:
                            if '?' in link:
                                link = link.split('?')[0]
                            peer, url, topic_id = parse_link(link)
                            group_key = link
                            if group_key not in skip_set:
                                groups_to_forward.append({
                                    'peer': peer,
                                    'url': url,
                                    'topic_id': topic_id,
                                    'title': tg.get('title', link.split('/')[-2] if '/' in link else 'Unknown'),
                                    'type': 'topic',
                                    'key': group_key
                                })
                    if _fwd_verbose():
                        print(f"[FORWARDING] Added {len([g for g in groups_to_forward if g.get('type')=='topic'])} topic groups "
                              f"(db_topics={len(topic_groups)}, skipped={len(skip_set)})")
                
                if fwd_mode in ('auto', 'both'):
                    auto_limit = await db_call(get_user_auto_group_limit, user_id)
                    count = 0
                    auto_groups = await db_call(lambda: list(account_auto_groups_col.find(
                        {'account_id': {'$in': _account_id_variants(account_id)}}
                    ).sort('_id', 1)))
                    if _fwd_verbose():
                        print(f"[FORWARDING DEBUG] auto_groups in DB for {account_id}: {len(auto_groups)} "
                          f"(limit={auto_limit}, skip_set={len(skip_set)})")
                    
                    for ag in auto_groups:
                        group_key = str(ag['group_id'])
                        if group_key not in skip_set:
                            groups_to_forward.append({
                                'group_id': ag['group_id'],
                                'access_hash': ag.get('access_hash'),
                                'username': ag.get('username'),
                                'title': ag.get('title', 'Unknown'),
                                'type': 'auto',
                                'key': group_key
                            })
                            count += 1
                            if auto_limit and count >= auto_limit:
                                break
                    if _fwd_verbose():
                        print(f"[FORWARDING] Added {count} auto groups")
                
                if not groups_to_forward:
                    if _fwd_verbose():
                        print(f"[FORWARDING] No groups to forward to for {account_id} "
                              f"(mode={fwd_mode}, failed={len(failed_set)}, pruned={len(pruned_set)})")
                    await add_user_log(
                        user_id,
                        f"No groups for mode={fwd_mode} (failed={len(failed_set)} pruned={len(pruned_set)}) - waiting"
                    )
                    await asyncio.sleep(60)
                    continue
                if _fwd_verbose():
                    print(f"[FORWARDING DEBUG] Will send to {len(groups_to_forward)} groups this round "
                      f"(mode={fwd_mode}, live_logs={_live_logs})")
                
                # ---- Warmup: new accounts ramp up gradually (hard cap WARMUP_DAYS) ----
                # Skipped if disabled globally (/nowarmup all) or per-account (/nowarmup).
                if WARMUP_ENABLED and not warmup_off_global and not acc.get('skip_warmup') and acc.get('added_at'):
                    try:
                        age_days = (datetime.now() - acc['added_at']).total_seconds() / 86400.0
                    except Exception:
                        age_days = 999.0
                    if 0 <= age_days < WARMUP_DAYS and groups_to_forward:
                        frac = max(WARMUP_MIN_FRACTION, age_days / WARMUP_DAYS)
                        cap = max(WARMUP_MIN_GROUPS, int(len(groups_to_forward) * frac))
                        if cap < len(groups_to_forward):
                            groups_to_forward = groups_to_forward[:cap]
                            if _fwd_verbose():
                                print(f"[FORWARDING] {account_id}: warmup {age_days:.1f}d -> {cap} groups")

                # ---- Per-round group window: plan cap + optional smart rotation ----
                # ONE sliding window handles both the per-plan per-round cap
                # (Starter 100 / Pro 150 / Elite 200) AND smart rotation, so groups
                # ROTATE each round (no group is starved) and the frequency math
                # (rotation_buckets) stays correct. All inputs are already in memory
                # (user doc + config), so this adds NO extra DB calls.
                # Smart rotation (default ON): shuffle ALL groups each cycle so
                # order never repeats the same pattern. Optional ROTATION_CHUNK>0
                # can still limit window size; 0 (default) = every group every cycle.
                rotation_buckets = 1
                total_g = len(groups_to_forward)
                smart_on = bool(user.get('smart_rotation', True))
                plan_round_cap = _groups_per_round_for_user(user)  # 0 = unlimited
                window = total_g
                if plan_round_cap and plan_round_cap > 0 and plan_round_cap < window:
                    window = plan_round_cap
                if ROTATION_CHUNK and ROTATION_CHUNK > 0 and ROTATION_CHUNK < window:
                    window = ROTATION_CHUNK
                if smart_on and total_g > 1:
                    import random as _rnd
                    _rnd.shuffle(groups_to_forward)
                if window < total_g:
                    # Optional partial window (only if explicit cap set)
                    rotation_buckets = (total_g + window - 1) // window
                    start = (rotation_offset % rotation_buckets) * window
                    groups_to_forward = groups_to_forward[start:start + window]
                    rotation_offset += 1
                    if smart_on and len(groups_to_forward) > 1:
                        import random as _rnd
                        _rnd.shuffle(groups_to_forward)

                # ---- Sick-account cooldown (repeated floods) ----
                _sick_left = _sick_remaining(account_id)
                if _sick_left > 0:
                    if _fwd_verbose():
                        print(f"[FORWARDING] {account_id}: sick cooldown {int(_sick_left)}s")
                    ok = await _interruptible_round_sleep(int(_sick_left) + 1, account_id, check_interval=20)
                    if not ok:
                        break
                    continue

                # ---- Cycle interval + frequency cap (do NOT shrink interval) ----
                # cycle_interval = minimum gap AFTER a cycle finishes (never reduced).
                # freq_per_hour  = max cycle STARTS in any rolling 60 minutes (optional).
                # Example: cycle work 15m + interval 10m => next start ~25m later.
                # If freq=2 and two cycles already ran this hour, wait until a slot frees.
                n_groups = len(groups_to_forward)
                cycle_interval = max(TARGET_MIN_CYCLE_FLOOR, int(get_cycle_interval_sec(user, tier_settings)))
                round_delay = cycle_interval  # baseline gap; may only INCREASE below
                freq_cap = get_user_freq_per_hour(user)  # None = no hourly cap

                # Wait for a frequency slot BEFORE starting this cycle (can only lengthen waits)
                if freq_cap:
                    wait_slot = _seconds_until_freq_slot(account_id, freq_cap)
                    if wait_slot > 0:
                        if _fwd_verbose():
                            print(f"[FORWARDING] {account_id}: freq cap {freq_cap}/hr — waiting {int(wait_slot)}s for slot")
                        ok = await _interruptible_round_sleep(int(wait_slot) + 1, account_id, check_interval=15)
                        if not ok:
                            break

                _record_cycle_start(account_id)
                if freq_cap:
                    freq_note = f" | cycle_gap>={cycle_interval}s | freq_cap={freq_cap}/hr"
                else:
                    freq_note = f" | cycle_gap>={cycle_interval}s | freq=off"
                if _fwd_verbose():
                    print(f"[FORWARDING] {account_id}: {n_groups} groups, msg_delay={msg_delay}s, "
                          f"round_delay={round_delay}s{freq_note}")

                sent = 0
                failed = 0
                skipped = 0
                stats_failed = 0
                peerflood_hit = False
                toxic_dropped = 0
                needs_drop = 0   # groups the account can't post to (permanent) -> user should remove them
                last_send_started_at = None
                
                for i, group in enumerate(groups_to_forward):
                    # Re-check the stop flag only periodically. Stopping cancels this
                    # task (instant), so this DB read is just a fallback; doing it every
                    # 10th group instead of every group avoids hundreds of blocking
                    # queries per round when an account has many groups.
                    if i % 10 == 0:
                        fresh_acc = await db_call(accounts_col.find_one, {'_id': account_id})
                        if not fresh_acc or not fresh_acc.get('is_forwarding'):
                            break
                        acc = fresh_acc

                    wait_seconds, quiet_label = _get_quiet_hours_wait(user_id, user)
                    if wait_seconds > 0:
                        try:
                            wait_text = _format_duration(wait_seconds)
                            quiet_label = quiet_label or "Quiet Hours"
                            await send_log(
                                account_id,
                                "<b>Quiet Hours Active</b>\n\n"
                                f"<b>Window:</b> <code>{quiet_label}</code>\n"
                                f"<b>Pausing:</b> <code>{wait_text}</code>"
                            )
                        except Exception:
                            pass
                        ok = await _sleep_quiet_hours(wait_seconds, account_id)
                        if not ok:
                            break
                    
                    group_key = group.get('key', group.get('title', 'unknown'))
                    _wait_until = flood_map.get(group_key)
                    if _wait_until and _wait_until > datetime.now():
                        skipped += 1
                        remaining_m = int((_wait_until - datetime.now()).total_seconds()) // 60
                        if _fwd_verbose():
                            print(f"[FORWARDING] Skipped {group['title']} (flood wait: {remaining_m}m)")
                        continue
                    
                    msg = ads[i % len(ads)] if ads_mode == 'saved' else None
                    
                    try:
                        sent_msg_id = None
                        current_entity = None
                        current_topic_id = None
                        send_gap = None
                        send_started = None
                        
                        if group['type'] == 'topic':
                            peer = group['peer']
                            current_topic_id = group.get('topic_id')
                            current_entity = entity_cache.get(group_key)
                            
                            if current_entity is None:
                                try:
                                    if isinstance(peer, str):
                                        current_entity = await client.get_entity(peer)
                                    elif isinstance(peer, int):
                                        if peer > 0:
                                            peer = int('-100' + str(peer))
                                        current_entity = await client.get_entity(peer)
                                except Exception:
                                    pass
                                if current_entity is not None:
                                    entity_cache[group_key] = current_entity
                            
                            if current_entity is None:
                                raise Exception(f"Cannot resolve topic peer: {peer}")
                            
                            group_name = getattr(current_entity, 'title', group['title'])[:30]
                            
                            if ads_mode == 'custom':
                                send_started = time.monotonic()
                                if last_send_started_at is not None:
                                    send_gap = send_started - last_send_started_at
                                if current_topic_id:
                                    r = await client.send_message(current_entity, spin(custom_text), reply_to=current_topic_id)
                                else:
                                    r = await client.send_message(current_entity, spin(custom_text))
                                sent_msg_id = getattr(r, 'id', None)

                            elif ads_mode == 'post':
                                send_started = time.monotonic()
                                if last_send_started_at is not None:
                                    send_gap = send_started - last_send_started_at
                                if current_topic_id:
                                    sent_msg_id = await forward_message(client, current_entity, post_source_msg_id, post_source_input_peer, current_topic_id)
                                else:
                                    result = await client.forward_messages(current_entity, post_source_msg_id, post_source_entity)
                                    if result:
                                        if isinstance(result, list):
                                            sent_msg_id = result[0].id if len(result) > 0 else None
                                        else:
                                            sent_msg_id = result.id

                            else:
                                send_started = time.monotonic()
                                if last_send_started_at is not None:
                                    send_gap = send_started - last_send_started_at
                                if current_topic_id:
                                    sent_msg_id = await forward_message(client, current_entity, msg.id, msg.peer_id, current_topic_id)
                                else:
                                    result = await client.forward_messages(current_entity, msg.id, 'me')
                                    if result:
                                        if isinstance(result, list):
                                            sent_msg_id = result[0].id if len(result) > 0 else None
                                        else:
                                            sent_msg_id = result.id
                        else:
                            current_entity = entity_cache.get(group_key)
                            group_id = group['group_id']
                            
                            if current_entity is None and group.get('username'):
                                try:
                                    current_entity = await client.get_entity(group['username'])
                                except Exception as _re:
                                    if _fwd_verbose():
                                        print(f"[FORWARDING DEBUG] resolve username @{group.get('username')} failed: "
                                          f"{type(_re).__name__}: {_re}")
                            
                            if current_entity is None:
                                try:
                                    full_id = int('-100' + str(abs(group_id))) if group_id > 0 else group_id
                                    current_entity = await client.get_entity(full_id)
                                except Exception as _re:
                                    if _fwd_verbose():
                                        print(f"[FORWARDING DEBUG] resolve id {group_id} failed: "
                                          f"{type(_re).__name__}: {_re}")
                            
                            if current_entity is None and group.get('access_hash'):
                                try:
                                    current_entity = InputPeerChannel(channel_id=abs(group_id), access_hash=group['access_hash'])
                                except Exception as _re:
                                    if _fwd_verbose():
                                        print(f"[FORWARDING DEBUG] InputPeerChannel build failed: "
                                          f"{type(_re).__name__}: {_re}")
                            
                            if current_entity is None:
                                raise Exception(
                                    f"Cannot resolve entity for group {group_id} "
                                    f"(username={group.get('username')}, access_hash={bool(group.get('access_hash'))})"
                                )
                            
                            entity_cache[group_key] = current_entity
                            group_name = group['title'][:30]

                            if ads_mode == 'custom':
                                send_started = time.monotonic()
                                if last_send_started_at is not None:
                                    send_gap = send_started - last_send_started_at
                                r = await client.send_message(current_entity, spin(custom_text))
                                sent_msg_id = getattr(r, 'id', None)

                            elif ads_mode == 'post':
                                send_started = time.monotonic()
                                if last_send_started_at is not None:
                                    send_gap = send_started - last_send_started_at
                                result = await client.forward_messages(current_entity, post_source_msg_id, post_source_entity)
                                if result:
                                    if isinstance(result, list):
                                        sent_msg_id = result[0].id if len(result) > 0 else None
                                    else:
                                        sent_msg_id = result.id

                            else:
                                send_started = time.monotonic()
                                if last_send_started_at is not None:
                                    send_gap = send_started - last_send_started_at
                                result = await client.forward_messages(current_entity, msg.id, 'me')
                                if result:
                                    if isinstance(result, list):
                                        sent_msg_id = result[0].id if len(result) > 0 else None
                                    else:
                                        sent_msg_id = result.id
                        
                        sent += 1
                        if send_started is not None:
                            last_send_started_at = send_started
                        if _fwd_verbose():
                            print(f"[FORWARDING] Sent to {group_name} ({i+1}/{len(groups_to_forward)})")
                        # Per-send user logs are batched into the round summary (end
                        # of loop) instead of a DB write on every message.
                        # Live "sent to X" log is fire-and-forget + bounded so a slow
                        # or flood-limited logger bot never throttles forwarding.
                        if sent_msg_id and current_entity and live_logs_enabled():
                            view_link = build_message_link(current_entity, sent_msg_id, current_topic_id)
                            if view_link:
                                _ad_no = (i % len(ads)) + 1 if (ads_mode == 'saved' and ads) else 1
                                _ad_total = len(ads) if (ads_mode == 'saved' and ads) else 1
                                _spawn_bg(_fire_live_log(account_id, view_link, group_name, send_gap, _ad_no, _ad_total))
                        
                        # Stats are flushed once per round (see end of loop) to avoid
                        # a blocking DB write on every single message.
                        
                    except FloodWaitError as e:
                        wait_time = e.seconds
                        failed += 1
                        await db_call(set_flood_wait, account_id, group_key, group['title'], wait_time)
                        _health_bump('floods')
                        if _fwd_verbose():
                            print(f"[FORWARDING] FloodWait {wait_time // 60}m for {group['title']} - will skip until expires")
                        await add_user_log(user_id, f"FloodWait {wait_time // 60}m in {group['title'][:20]}")
                        
                    except (ChannelPrivateError, ChatWriteForbiddenError, UserBannedInChannelError) as e:
                        needs_drop += 1   # account can't post here (private/admin-only/banned) -> user should drop it
                        entity_cache.pop(group_key, None)
                        await db_call(mark_group_failed, account_id, group_key, str(e))
                        if _fwd_verbose():
                            print(f"[FORWARDING] Permanent fail {group['title']}: {type(e).__name__}")
                        if prune_on:
                            _treason = ('admin_only' if isinstance(e, ChatWriteForbiddenError)
                                        else 'banned' if isinstance(e, UserBannedInChannelError)
                                        else None)
                            if _treason and await db_call(record_toxic_strike, account_id, group_key, group['title'], _treason):
                                toxic_dropped += 1
                                await notify_toxic_pruned(account_id, acc.get('phone'), group['title'], _treason)

                        # Auto-leave the group if sending fails (only if enabled)
                        if auto_leave_on:
                            try:
                                if current_entity is not None:
                                    left_ok = await safe_leave_chat(client, current_entity)
                                    if left_ok:
                                        await db_call(remove_group_from_db, acc_id_str, group.get('type'), group_key, group)
                                        await notify_auto_left(account_id, acc.get('phone'), group.get('title'), group_key, reason=type(e).__name__)
                                    await add_user_log(user_id, f"Auto-left {group['title'][:20]} after failure")
                            except Exception as le:
                                if _fwd_verbose():
                                    print(f"[FORWARDING] Leave failed: {str(le)[:80]}")
                        else:
                            await add_user_log(user_id, f"Auto-leave disabled; kept {group['title'][:20]}")
                        
                    except SlowModeWaitError as e:
                        failed += 1
                        wait_time = int(getattr(e, 'seconds', 60) or 60)
                        await db_call(set_flood_wait, account_id, group_key, group['title'], wait_time)
                        if _fwd_verbose():
                            print(f"[FORWARDING] SlowMode {wait_time}s for {group['title']}")
                        await add_user_log(user_id, f"SlowMode {wait_time}s in {group['title'][:20]}")
                        if prune_on and wait_time >= TOXIC_SLOWMODE_SEC:
                            if await db_call(record_toxic_strike, account_id, group_key, group['title'], 'slowmode'):
                                toxic_dropped += 1
                                await notify_toxic_pruned(account_id, acc.get('phone'), group['title'], 'slowmode')

                    except PeerFloodError:
                        # Account-wide spam limit (Telegram flagged too many messages to
                        # new peers). Stop this round immediately and cool down hard rather
                        # than risk an account ban.
                        failed += 1
                        peerflood_hit = True
                        try:
                            _sick_record(account_id)
                        except Exception:
                            pass
                        _health_bump('peerfloods')
                        if _fwd_verbose():
                            print(f"[FORWARDING] PeerFlood for account {account_id} - cooling down")
                        await add_user_log(user_id, "PeerFlood detected - pausing this account to stay safe")
                        try:
                            await send_log(
                                account_id,
                                "<b>⚠ PeerFlood detected</b>\n\n"
                                "<i>Telegram flagged this account for sending too fast. "
                                "Pausing it for a while to avoid a ban.</i>"
                            )
                        except Exception:
                            pass
                        break

                    except Exception as e:
                        entity_cache.pop(group_key, None)
                        error_str = str(e)
                        if _fwd_verbose():
                            print(f"[FORWARDING] Send error account={account_id} group={group.get('title')} "
                                  f"type={group.get('type')} err={type(e).__name__}: {error_str[:160]}")
                        wait_match = re.search(r'wait of (\d+) seconds', error_str, re.IGNORECASE)
                        if wait_match:
                            failed += 1   # transient rate-limit wait embedded in a generic error
                            wait_time = int(wait_match.group(1))
                            await db_call(set_flood_wait, account_id, group_key, group['title'], wait_time)
                        else:
                            needs_drop += 1   # permanent send failure -> user should drop/remove this group
                            if _fwd_verbose():
                                print(f"[FORWARDING] Error {group['title']}: {error_str[:120]}")

                            # Auto-leave on any non-flood send failure (only if enabled)
                            if auto_leave_on:
                                try:
                                    if current_entity is not None:
                                        left_ok = await safe_leave_chat(client, current_entity)
                                        if left_ok:
                                            await db_call(remove_group_from_db, acc_id_str, group.get('type'), group_key, group)
                                            await notify_auto_left(account_id, acc.get('phone'), group.get('title'), group_key, reason=error_str[:120])
                                        await add_user_log(user_id, f"Auto-left {group['title'][:20]} after failure")
                                except Exception as le:
                                    if _fwd_verbose():
                                        print(f"[FORWARDING] Leave failed: {str(le)[:80]}")
                            else:
                                await add_user_log(user_id, f"Auto-leave disabled; kept {group['title'][:20]}")

                        # Counted here; stats are flushed once per round below.
                        stats_failed += 1
                    
                    # Small random jitter so many accounts don't hit Telegram in
                    # lockstep (reduces synchronized bursts -> fewer flood errors).
                    await asyncio.sleep(msg_delay + random.uniform(0, max(1.0, msg_delay * 0.25)))
                
                # Flush accumulated stats once per round (1 write instead of N).
                if sent or stats_failed:
                    await db_call(update_account_stats, str(account_id), sent=sent, failed=stats_failed)
                day_sent += sent
                _health_bump('sends', sent)
                _health_bump('fails', stats_failed)
                
                if _fwd_verbose():
                    print(f"[FORWARDING] Round complete. Sent: {sent}, Failed: {failed}, NeedsDrop: {needs_drop}, Skipped: {skipped}")
                # "Auto-Dropped" = groups auto-removed by toxic-pruning (off by default).
                drop_note = f" | 🛡️ <b>Auto-Dropped:</b> <code>{toxic_dropped}</code>" if toxic_dropped else ""
                try:
                    await send_log(account_id, f"<b>✅ Round {round_num} Completed</b>\n📱 <code>{account_phone}</code>\n\n📤 <b>Sent:</b> <code>{sent}</code> | ❌ <b>Failed:</b> <code>{failed}</code> | 🗑 <b>Needs Drop:</b> <code>{needs_drop}</code> | ⏭ <b>Skipped:</b> <code>{skipped}</code>{drop_note}\n\n⏰ <b>Next Round:</b> <code>{round_delay}s</code>{freq_note}")
                except Exception:
                    pass
                await add_user_log(user_id, f"Round: {sent} sent, {failed} failed, {needs_drop} needs-drop, {skipped} skipped")
                
                # Check if still forwarding before waiting for next round
                if not acc.get('is_forwarding', False):
                    print(f"[{account_id}] Stopped before round delay")
                    break
                
                # Per-account health: repeated PeerFlood means Telegram is actively
                # flagging this account -> auto-pause it before it gets banned.
                peerflood_streak = peerflood_streak + 1 if peerflood_hit else 0
                if peerflood_streak >= HEALTH_PEERFLOOD_LIMIT:
                    if _fwd_verbose():
                        print(f"[FORWARDING] {account_id} auto-paused (PeerFlood x{peerflood_streak})")
                    await db_call(accounts_col.update_one, {'_id': account_id},
                        {'$set': {
                            'is_forwarding': False,
                            'health_paused': True,
                            'health_paused_at': datetime.now(),
                            'last_error': f'PeerFlood x{peerflood_streak} — auto-paused',
                            'last_error_code': 'peerflood',
                            'last_error_at': datetime.now(),
                        }})
                    try:
                        await send_log(account_id,
                            "<b>\u26d4 Account auto-paused (health protection)</b>\n\n"
                            f"<i>Telegram flagged this account with PeerFlood {peerflood_streak} rounds in a "
                            "row. Forwarding was paused to protect it from a ban. Let it rest, then start "
                            "again when ready.</i>")
                    except Exception:
                        pass
                    break

                # Gap after cycle: NEVER below cycle_interval; may increase for freq/PeerFlood.
                effective_delay = round_delay
                if peerflood_hit:
                    effective_delay = max(effective_delay, int(os.getenv('PEERFLOOD_COOLDOWN', '3600')))
                    if _fwd_verbose():
                        print(f"[FORWARDING] PeerFlood cooldown: waiting {effective_delay}s")
                # If the next start would exceed freq, stretch the gap (still >= cycle_interval)
                if freq_cap:
                    extra = _seconds_until_freq_slot(account_id, freq_cap)
                    if extra > 0:
                        effective_delay = max(effective_delay, int(extra))

                # Day/night rhythm: stretch the gap during server-night hours so an
                # account looks more human (quieter at night). NIGHT_SLOWDOWN=1.0 -> off.
                if NIGHT_SLOWDOWN > 1.0:
                    _hour = datetime.now().hour
                    _is_night = (NIGHT_START_HOUR <= _hour < NIGHT_END_HOUR) if NIGHT_START_HOUR <= NIGHT_END_HOUR else (_hour >= NIGHT_START_HOUR or _hour < NIGHT_END_HOUR)
                    if _is_night:
                        effective_delay = int(effective_delay * NIGHT_SLOWDOWN)
                if _fwd_verbose():
                    print(f"[FORWARDING] Waiting {effective_delay}s for next round...")
                still_active = await _interruptible_round_sleep(effective_delay, account_id, check_interval=15)
                if not still_active:
                    print(f"[{account_id}] Stopped during round delay")
                    break
                
            except asyncio.CancelledError:
                print(f"[FORWARDING] Task cancelled for account {account_id}")
                break
            except (asyncio.TimeoutError, ConnectionError, OSError) as e:
                # Transient network / Telegram connection timeout: keep the client,
                # back off briefly and retry next round (auto_reconnect + the round-start
                # check recover the link) instead of tearing the whole loop down.
                _health_bump('timeouts')
                if _fwd_verbose():
                    print(f"[FORWARDING] Connection issue for {account_id}: {type(e).__name__}: {str(e)[:80]} - retrying")
                await asyncio.sleep(15)
                continue
            except Exception as e:
                if _fwd_verbose():
                    print(f"[FORWARDING] Round error for {account_id}: {type(e).__name__}: {str(e)[:120]} - retrying")
                await asyncio.sleep(15)
                continue
        
    except asyncio.CancelledError:
        print(f"[FORWARDING] Task cancelled for account {account_id}")
    except Exception as e:
        print(f"[FORWARDING] Error in loop: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if client:
            try:
                await client.disconnect()
                if _fwd_verbose():
                    print(f"[FORWARDING] Client disconnected for account {account_id}")
            except Exception:
                pass
            try:
                _clear_activity(account_id)
            except Exception:
                pass
        # NOTE: task registration in forwarding_tasks is owned by supervise_forwarding,
        # which calls this loop. Do not delete it here or the supervisor loses track.

async def supervise_forwarding(user_id, account_id):
    """Keep an account's forwarding loop alive in production.

    - Restarts run_forwarding_loop with exponential backoff if it crashes
      unexpectedly (network/Telegram errors), so an account never silently stops.
    - Stops cleanly when forwarding is turned off, the task is cancelled, or the
      session becomes unauthorized (run_forwarding_loop clears is_forwarding).
    This is the task registered in forwarding_tasks; cancelling it cancels the
    whole chain instantly."""
    backoff = 5
    try:
        while True:
            acc = await db_call(get_account_by_id, account_id)
            if not acc or not acc.get('is_forwarding', False):
                break
            if acc.get('auth_invalid'):
                print(f"[SUPERVISOR] Account {account_id} auth_invalid — not restarting")
                break
            started_at = time.monotonic()
            try:
                await run_forwarding_loop(user_id, account_id)
            except asyncio.CancelledError:
                raise
            except _AUTH_DEAD_ERRORS as e:
                print(f"[SUPERVISOR] Account {account_id} auth dead: {e}")
                await _mark_account_auth_dead(account_id, type(e).__name__)
                break
            except Exception as e:
                en = type(e).__name__
                # String fallback for Telethon version differences
                if any(x in en for x in (
                    'AuthKeyUnregistered', 'UserDeactivated', 'SessionRevoked',
                    'AuthKeyDuplicated', 'AuthKeyNotFound', 'Unauthorized',
                )):
                    print(f"[SUPERVISOR] Account {account_id} auth dead ({en}): {e}")
                    await _mark_account_auth_dead(account_id, en)
                    break
                print(f"[SUPERVISOR] Account {account_id} crashed: {e}")
                import traceback
                traceback.print_exc()
            if time.monotonic() - started_at > 120:
                backoff = 5
            acc = await db_call(get_account_by_id, account_id)
            if not acc or not acc.get('is_forwarding', False) or acc.get('auth_invalid'):
                break
            if _fwd_verbose():
                print(f"[SUPERVISOR] Restarting account {account_id} in {backoff}s")
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 300)
    except asyncio.CancelledError:
        if _fwd_verbose():
            print(f"[SUPERVISOR] Cancelled for account {account_id}")
    finally:
        # Only drop OUR task. Quick Stop→Start can register a new supervisor
        # under the same key before this cancelled task's finally runs.
        try:
            cur = asyncio.current_task()
            if forwarding_tasks.get(account_id) is cur:
                forwarding_tasks.pop(account_id, None)
        except Exception:
            pass


async def resume_active_forwarding():
    """On startup, resume any accounts that were forwarding before the restart.
    Staggered so we don't reconnect hundreds of sessions all at once."""
    try:
        active = await db_call(lambda: list(accounts_col.find({'is_forwarding': True})))
    except Exception as e:
        print(f"[RESUME] Could not query active accounts: {e}")
        return
    if not active:
        print("[RESUME] No active accounts to resume")
        return
    print(f"[RESUME] Resuming {len(active)} account(s)...")
    stagger = float(os.getenv('RESUME_STAGGER_SECONDS', '2'))
    resumed = 0
    for acc in active:
        acc_id = acc['_id']
        owner_id = acc.get('owner_id')
        if owner_id is None:
            continue
        existing = forwarding_tasks.get(acc_id)
        if existing and not existing.done():
            continue
        task = asyncio.create_task(supervise_forwarding(owner_id, acc_id))
        forwarding_tasks[acc_id] = task
        resumed += 1
        await asyncio.sleep(stagger)
    print(f"[RESUME] Started {resumed} forwarding supervisor(s)")


# ===================== Desired-state reconciliation engine =====================
# Forwarding is driven by the `is_forwarding` flag in MongoDB (the "desired
# state"). Each process runs a reconciler that ensures the accounts IT owns
# (by shard) and that should be forwarding have a running supervisor, and that
# anything it shouldn't run is stopped. This is what makes the bot horizontally
# scalable: spin up more worker processes (each with its own WORKER_ID) and they
# automatically split the load with no extra coordination code.

def ensure_account_running(owner_id, account_id):
    """Start a supervisor for this account locally if we own it and it isn't
    already running. Returns True if a task is running/was started here.
    Idempotent: double-Start will not spawn a second supervisor."""
    if owner_id is None or not _owns_account(account_id):
        return False
    if _is_draining():
        return False
    existing = forwarding_tasks.get(account_id)
    if existing is not None and not existing.done():
        return True
    if existing is not None:
        forwarding_tasks.pop(account_id, None)
    # Re-check after pop (race with concurrent Start)
    existing = forwarding_tasks.get(account_id)
    if existing is not None and not existing.done():
        return True
    task = asyncio.create_task(supervise_forwarding(owner_id, account_id))
    forwarding_tasks[account_id] = task
    return True


def ensure_account_stopped(account_id):
    """Cancel the local supervisor for this account if present."""
    task = forwarding_tasks.get(account_id)
    if task is not None and not task.done():
        task.cancel()
    cur = forwarding_tasks.get(account_id)
    if cur is task or cur is None or (cur is not None and cur.done()):
        forwarding_tasks.pop(account_id, None)


async def _reconcile_once():
    """One pass: align locally-running supervisors with desired DB state."""
    try:
        desired = await db_call(lambda: list(
            accounts_col.find(
                {
                    'is_forwarding': True,
                    'auth_invalid': {'$ne': True},
                },
                {'_id': 1, 'owner_id': 1},
            )
        ))
    except Exception as e:
        print(f"[RECONCILE] Query failed: {e}")
        return
    desired_owned = {}
    for acc in desired:
        acc_id = acc['_id']
        if _owns_account(acc_id) and acc.get('owner_id') is not None:
            desired_owned[acc_id] = acc['owner_id']

    # Enforce the soft per-worker cap. If this worker's shard is assigned more
    # accounts than it can safely run, deterministically run only the first
    # MAX_ACCOUNTS_PER_WORKER (sorted by id) and warn so the manager scales up.
    if MAX_ACCOUNTS_PER_WORKER and len(desired_owned) > MAX_ACCOUNTS_PER_WORKER:
        over = len(desired_owned) - MAX_ACCOUNTS_PER_WORKER
        keep = sorted(desired_owned.keys(), key=lambda x: str(x))[:MAX_ACCOUNTS_PER_WORKER]
        keep_set = set(keep)
        desired_owned = {k: v for k, v in desired_owned.items() if k in keep_set}
        print(f"[RECONCILE] OVER CAPACITY: worker {WORKER_ID} assigned "
              f"{len(keep) + over} accounts but cap is {MAX_ACCOUNTS_PER_WORKER}; "
              f"{over} not started. Add more workers/proxies.")

    # Stop anything running locally that should no longer run (or got capped out).
    for acc_id in list(forwarding_tasks.keys()):
        if acc_id not in desired_owned:
            ensure_account_stopped(acc_id)

    # Start missing ones, capped per cycle so a big fleet ramps up smoothly.
    # Zero extra Mongo writes: only in-memory task table + existing is_forwarding query.
    started = 0
    for acc_id, owner_id in desired_owned.items():
        if _is_draining():
            break
        existing = forwarding_tasks.get(acc_id)
        if existing and not existing.done():
            # Do NOT restart on "activity stale" here.
            # Between rounds the loop sleeps (cycle gap / quiet hours) without
            # sending — that is normal and was falsely cancelling tasks → Round 1 loops.
            continue
        ensure_account_running(owner_id, acc_id)
        started += 1
        if started >= START_BATCH:
            break
        await asyncio.sleep(0.2)
    if started:
        if _fwd_verbose():
            print(f"[RECONCILE] Started {started} account(s) this cycle "
                  f"(worker {WORKER_ID}/{WORKER_COUNT}, role={BOT_ROLE})")


async def forwarding_reconciler():
    """Background loop that keeps local forwarding aligned with desired state."""
    if _fwd_verbose():
        print(f"[RECONCILE] Reconciler started (node {NODE_ID}/{NODE_COUNT}, "
              f"worker {WORKER_ID}/{WORKER_COUNT}, role={BOT_ROLE}, interval={RECONCILE_INTERVAL}s)")
    while True:
        try:
            await _reconcile_once()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[RECONCILE] Error: {e}")
        await asyncio.sleep(RECONCILE_INTERVAL)


BOT_START_TIME = time.time()



async def admin_alert(text: str):
    """Best-effort ops alert to ADMIN_ALERT_CHAT (or owner). Never raises / never blocks hot path."""
    try:
        chat = os.getenv('ADMIN_ALERT_CHAT', '').strip() or str(CONFIG.get('owner_id') or '')
        token = CONFIG.get('notification_bot_token') or CONFIG.get('bot_token')
        if not chat or not token:
            return
        msg = "<b>Ops alert</b>" + chr(10) + str(text)[:1500]
        await _tg_send_http(token, int(chat), msg)
    except Exception:
        pass


async def health_logger():
    """Periodically print a one-line health summary for ops/monitoring."""
    interval = int(os.getenv('HEALTH_INTERVAL', '1800'))  # default 30 min (was 5)
    while True:
        try:
            await asyncio.sleep(interval)
            active_local = sum(1 for t in forwarding_tasks.values() if not t.done())
            print(
                f"[HEALTH] role={BOT_ROLE} node={NODE_ID}/{NODE_COUNT} "
                f"worker={WORKER_ID}/{WORKER_COUNT} "
                f"local_active_accounts={active_local} proxies={len(RUNTIME_PROXIES)} "
                f"uptime={_format_duration(int(time.time() - BOT_START_TIME))}"
            )
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[HEALTH] {e}")


# Per-process health counters (reset each reporting window). Used by the manager
# to adapt accounts/worker when timeouts/flood spike.
_HEALTH = {'sends': 0, 'fails': 0, 'floods': 0, 'peerfloods': 0, 'timeouts': 0}


def _health_bump(key, n=1):
    try:
        _HEALTH[key] = _HEALTH.get(key, 0) + n
    except Exception:
        pass


async def health_reporter():
    """Write a per-worker health snapshot to Mongo so the manager can adapt the
    per-worker cap (e.g. shrink it when connection timeouts spike, alert on flood)."""
    interval = int(os.getenv('HEALTH_REPORT_INTERVAL', '30'))
    while True:
        try:
            await asyncio.sleep(interval)
            window = dict(_HEALTH)
            for k in _HEALTH:
                _HEALTH[k] = 0
            active_local = sum(1 for t in forwarding_tasks.values() if not t.done())
            # Globally-unique key per (node, worker) so multiple VPS nodes each
            # running a "worker 0" don't clobber each other's health doc.
            wkey = f"{NODE_ID}:{WORKER_ID}"
            doc = {
                'wkey': wkey,
                'node_id': NODE_ID,
                'worker_id': WORKER_ID,
                'role': BOT_ROLE,
                'updated_at': datetime.now(),
                'active_accounts': active_local,
                'window_seconds': interval,
                'sends': window.get('sends', 0),
                'fails': window.get('fails', 0),
                'floods': window.get('floods', 0),
                'peerfloods': window.get('peerfloods', 0),
                'timeouts': window.get('timeouts', 0),
            }
            await db_call(lambda: worker_health_col.update_one(
                {'wkey': wkey}, {'$set': doc}, upsert=True))
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[HEALTH] reporter error: {e}")


async def forward_message(client, to_entity, msg_id, from_peer, topic_id=None):
    random_id = random.randint(1, 2147483647)
    result = await client(ForwardMessagesRequest(
        from_peer=from_peer,
        id=[msg_id],
        random_id=[random_id],
        to_peer=to_entity,
        top_msg_id=topic_id
    ))
    if result.updates:
        for update in result.updates:
            if hasattr(update, 'message') and hasattr(update.message, 'id'):
                return update.message.id
    return None

def build_message_link(entity, msg_id, topic_id=None):
    username = getattr(entity, 'username', None)
    if username:
        base = f"https://t.me/{username}"
    else:
        chat_id = getattr(entity, 'id', None)
        if chat_id:
            base = f"https://t.me/c/{chat_id}"
        else:
            return None
    
    if topic_id:
        return f"{base}/{topic_id}/{msg_id}" if msg_id else f"{base}/{topic_id}"
    return f"{base}/{msg_id}" if msg_id else base


# ---- Group refresh (VPS-safe): one client at a time, cooldown, batches ----
REFRESH_COOLDOWN_SEC = int(os.getenv('REFRESH_COOLDOWN_SEC', '900'))   # skip if refreshed < 15 min
REFRESH_BATCH_MAX = int(os.getenv('REFRESH_BATCH_MAX', '5'))           # max accounts per tap
REFRESH_GAP_SEC = float(os.getenv('REFRESH_GAP_SEC', '0.6'))           # pause between accounts


async def _refresh_accounts_safe(account_docs, *, force: bool = False):
    """Refresh groups for a list of account docs.
    - One Telethon client at a time (connect → scan → disconnect)
    - Skips accounts refreshed within REFRESH_COOLDOWN_SEC (unless force)
    - Processes at most REFRESH_BATCH_MAX per call (caller can re-tap)
    Returns (result_lines: list[str], remaining: int)
    """
    results = []
    now = datetime.now()
    # Prefer least-recently refreshed first
    def _sort_key(a):
        ts = a.get('last_groups_refresh_at')
        if isinstance(ts, datetime):
            return ts
        return datetime(1970, 1, 1)

    ordered = sorted(list(account_docs or []), key=_sort_key)
    batch = ordered[: max(1, REFRESH_BATCH_MAX)]
    remaining = max(0, len(ordered) - len(batch))

    for acc in batch:
        account_id = str(acc.get('_id'))
        phone = (acc.get('phone') or '????')[-4:]
        client = None
        try:
            last = acc.get('last_groups_refresh_at')
            if (not force) and isinstance(last, datetime):
                age = (now - last).total_seconds()
                if age < REFRESH_COOLDOWN_SEC:
                    mins = max(1, int((REFRESH_COOLDOWN_SEC - age) / 60))
                    results.append(f"<code>{phone}</code>: skipped (refreshed recently, wait ~{mins}m)")
                    continue

            session = _load_account_session(account_id)
            if not session:
                session_enc = acc.get('session') or acc.get('session_string')
                if session_enc:
                    try:
                        session = cipher_suite.decrypt(
                            session_enc.encode() if isinstance(session_enc, str) else session_enc
                        ).decode()
                    except Exception:
                        session = None
            if not session:
                results.append(f"<code>{phone}</code>: Session not found — re-add account")
                continue

            client = make_account_client(session, account_id, receive_updates=False)
            await client.connect()
            if not await client.is_user_authorized():
                results.append(f"<code>{phone}</code>: Session expired — re-add account")
                continue

            before_count = await db_call(
                lambda aid=account_id: account_auto_groups_col.count_documents(
                    {'account_id': {'$in': _account_id_variants(aid)}}
                )
            )
            count = await refresh_account_groups(client, account_id)
            after_count = await db_call(
                lambda aid=account_id: account_auto_groups_col.count_documents(
                    {'account_id': {'$in': _account_id_variants(aid)}}
                )
            )

            # Stamp cooldown marker (best-effort)
            try:
                await db_call(
                    lambda aid=acc.get('_id'): accounts_col.update_one(
                        {'_id': aid},
                        {'$set': {'last_groups_refresh_at': datetime.now()}},
                    )
                )
                try:
                    invalidate_accounts_cache(acc.get('owner_id'))
                except Exception:
                    pass
            except Exception:
                pass

            if after_count > before_count:
                results.append(
                    f"<code>{phone}</code>: {before_count} → {after_count} (+{after_count - before_count})"
                )
            else:
                results.append(f"<code>{phone}</code>: {after_count} groups")
        except Exception as e:
            results.append(f"<code>{phone}</code>: Error - {str(e)[:40]}")
        finally:
            if client is not None:
                try:
                    await client.disconnect()
                except Exception:
                    pass
            try:
                await asyncio.sleep(REFRESH_GAP_SEC)
            except Exception:
                pass

    return results, remaining


async def refresh_account_groups(client, account_id):
    """Refresh groups for an account and return count of groups found."""
    try:
        dialogs = await client.get_dialogs(limit=int(os.getenv("REFRESH_DIALOGS_LIMIT", "300")))
        groups = []
        for d in dialogs:
            e = d.entity
            if isinstance(e, User):
                continue
            if not isinstance(e, (Channel, Chat)):
                continue
            if isinstance(e, Channel) and e.broadcast:
                continue
            title = getattr(e, 'title', 'Unknown')
            if title and title != 'Unknown':
                group_id = e.id
                access_hash = getattr(e, 'access_hash', None)
                username = getattr(e, 'username', None)
                is_channel = isinstance(e, Channel)
                
                if access_hash is None and is_channel:
                    try:
                        full_entity = await client.get_entity(e)
                        access_hash = getattr(full_entity, 'access_hash', None)
                    except Exception:
                        pass
                
                groups.append({
                    'account_id': str(account_id),
                    'group_id': group_id,
                    'title': title,
                    'access_hash': access_hash,
                    'username': username,
                    'is_channel': is_channel
                })
        
        # Save to database (update or insert)
        for g in groups:
            account_auto_groups_col.update_one(
                {'account_id': str(account_id), 'group_id': g['group_id']},
                {'$set': g},
                upsert=True
            )
        
        return len(groups)
    except Exception as e:
        print(f"[refresh_account_groups] Error: {e}")
        return 0


async def fetch_groups_for_account(client, account_id):
    """Compatibility wrapper used by the dashboard refresh action."""
    return await refresh_account_groups(client, account_id)


async def fetch_groups(client, account_id, phone):
    try:
        dialogs = await client.get_dialogs(limit=int(os.getenv("REFRESH_DIALOGS_LIMIT", "300")))
        groups = []
        for d in dialogs:
            e = d.entity
            if isinstance(e, User):
                continue
            if not isinstance(e, (Channel, Chat)):
                continue
            if isinstance(e, Channel) and e.broadcast:
                continue
            title = getattr(e, 'title', 'Unknown')
            if title and title != 'Unknown':
                group_id = e.id
                access_hash = getattr(e, 'access_hash', None)
                username = getattr(e, 'username', None)
                is_channel = isinstance(e, Channel)
                
                if access_hash is None and is_channel:
                    try:
                        full_entity = await client.get_entity(e)
                        access_hash = getattr(full_entity, 'access_hash', None)
                    except Exception:
                        pass
                
                groups.append({
                    # store account_id consistently as string (ObjectId -> str)
                    'account_id': str(account_id),
                    'phone': phone,
                    'group_id': group_id,
                    'title': title,
                    'username': username,
                    'access_hash': access_hash,
                    'is_channel': is_channel,
                    'added_at': datetime.now()
                })
        if groups:
            # Remove any older variants (ObjectId vs str)
            account_auto_groups_col.delete_many({'account_id': {'$in': _account_id_variants(account_id)}})
            account_auto_groups_col.insert_many(groups)
        return len(groups)
    except Exception as e:
        print(f"Fetch groups error: {e}")
        return 0

# ===================== UI Helpers =====================

def _h(s: str) -> str:
    """Basic HTML escape for user-provided strings."""
    try:
        return (
            str(s)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        )
    except Exception:
        return ""


def ui_title(title: str) -> str:
    return f"<b>{_h(title)}</b>"


def ui_kv(key: str, val: str) -> str:
    return f"<b>{_h(key)}:</b> {_h(val)}"


def ui_section(title: str, lines: list[str]) -> str:
    body = "\n".join(lines).strip()
    return f"<b>{_h(title)}</b>\n{body}" if body else f"<b>{_h(title)}</b>"


def ui_divider() -> str:
    return "\n\n"


async def respond_with_welcome(event, text: str, buttons=None, parse_mode: str = 'html'):
    welcome_image = MESSAGES.get('welcome_image', '')
    if welcome_image:
        await event.respond(file=welcome_image, message=text, parse_mode=parse_mode, buttons=buttons)
    else:
        await event.respond(text, parse_mode=parse_mode, buttons=buttons)


def render_plan_select_text() -> str:
    return (
        "<b>Choose Your Plan</b>\n\n"
        "Pick what fits your scale. You can upgrade anytime.\n\n"
        "Plans: Starter • Pro • Elite"
    )


def render_welcome_text() -> str:
    return (
        "Welcome to Jiren Ads Bot\n\n"
        "Automate Telegram promotions across groups and topics with clean controls and stable delivery.\n\n"
        "Tap Launch Ads to get started."
    )


def render_user_guide_text() -> str:
    """How-to-run-ads guide for all users."""
    return (
        "<b>📖 How to Run Ads</b>\n\n"
        "<b>Step 1 — Add an account</b>\n"
        "Home → <b>Accounts</b> → add your Telegram number, enter OTP (and 2FA if asked). "
        "This is the account that will send ads.\n\n"
        "<b>Step 2 — Prepare your ad</b>\n"
        "On that same Telegram account, open <b>Saved Messages</b> and save the post you want to promote "
        "(text, photo, or video).\n"
        "Or in <b>Settings → Ads Mode</b> choose Custom text or a Post link.\n\n"
        "<b>Step 3 — Groups or topics</b>\n"
        "Join groups with that account (or use Auto Group Join).\n"
        "Paid plans can use <b>Topics</b> mode as well.\n"
        "Set <b>Where to Send</b>: Groups only / Topics / Both.\n\n"
        "<b>Step 4 — Timing (recommended)</b>\n"
        "Open <b>Timing</b>:\n"
        "• Msg gap — wait between each group (Slow / Normal / Fast or custom)\n"
        "• Cycle gap — rest after a full round (10 / 20 / 30 min)\n"
        "Safer gaps = lower ban risk.\n\n"
        "<b>Step 5 — Start</b>\n"
        "Home → <b>Start / Manage Ads</b> → <b>Start Ads</b>.\n"
        "Watch logs if you enabled the logger bot.\n\n"
        "<b>Tips</b>\n"
        "• Don’t blast the same message too fast\n"
        "• Follow each group’s rules\n"
        "• We don’t promote spam — bans are your responsibility\n"
        "• Need more accounts / topics → <b>Plans & Pricing</b>"
    )


def render_privacy_policy_text() -> str:
    """Terms & privacy gate shown before the main dashboard."""
    return (
        "<b>📜 Terms & Privacy</b>\n\n"
        "Welcome to <b>Jiren Ads Bot</b>. Please read before continuing.\n\n"
        "<b>1. Responsible use</b>\n"
        "We do <b>not</b> encourage spam, scams, or abuse of Telegram. "
        "You must follow Telegram’s Terms of Service and the rules of every group or channel you post in.\n\n"
        "<b>2. Your responsibility</b>\n"
        "You alone control the accounts you connect and the content you send. "
        "You are responsible for how you use this bot.\n\n"
        "<b>3. Account limits & bans</b>\n"
        "Automated posting can trigger FloodWait limits or permanent bans. "
        "We are <b>not responsible</b> for any restricted, limited, or banned accounts, "
        "lost access, or other damages that may result from using this service.\n\n"
        "<b>4. Data we store</b>\n"
        "We store only what is needed to run the bot (e.g. session data, settings, plan status). "
        "We do not sell your data.\n\n"
        "<b>5. Agreement</b>\n"
        "By tapping <b>Accept & Continue</b>, you confirm that you understand these terms "
        "and accept all risk related to your own Telegram accounts."
    )


def privacy_policy_keyboard():
    return [
        [Button.inline("✅ Accept & Continue", b"accept_privacy")],
    ]


_dash_text_cache = {}  # uid -> (expires_monotonic, text)
_DASH_TEXT_TTL = float(os.getenv('DASH_TEXT_TTL', '5'))


def render_dashboard_text(uid: int) -> str:
    """Home dashboard body. Short TTL cache cuts repeat Home taps / rebuilds."""
    try:
        now = time.monotonic()
        hit = _dash_text_cache.get(int(uid))
        if hit and hit[0] > now:
            return hit[1]
    except Exception:
        pass
    text = _render_dashboard_text_uncached(uid)
    try:
        _dash_text_cache[int(uid)] = (time.monotonic() + _DASH_TEXT_TTL, text)
    except Exception:
        pass
    return text


def invalidate_dash_text(uid=None):
    try:
        if uid is None:
            _dash_text_cache.clear()
        else:
            _dash_text_cache.pop(int(uid), None)
    except Exception:
        pass


def _render_dashboard_text_uncached(uid: int) -> str:
    user = get_user(uid)
    max_acc = get_user_max_accounts(uid)
    
    # Determine plan name and expiry
    if is_admin(uid):
        plan_name = "Admin"
        max_acc = 999
        expiry_text = "999d"
    elif is_premium(uid):
        # Use stored plan_name if available, otherwise derive from max_accounts
        plan_name = get_display_plan_name(user)
        if plan_name == "No Plan":
            # Backward compatibility: derive from max_accounts
            if max_acc >= 15:
                plan_name = "Elite"
            elif max_acc >= 7:
                plan_name = "Pro"
            else:
                plan_name = "Starter"
        
        # Calculate expiry countdown
        expires_at = user.get('premium_expires_at')
        if expires_at and isinstance(expires_at, datetime):
            remaining = expires_at - datetime.now()
            if remaining.total_seconds() > 0:
                days_left = remaining.days
                expiry_text = f"{days_left}d"
            else:
                expiry_text = "Expired"
        else:
            expiry_text = "∞"  # Legacy users without expiry
    else:
        plan_name = "No Plan"
        expiry_text = "—"
    
    accounts = get_user_accounts(uid)
    active = sum(1 for a in accounts if a.get('is_forwarding'))
    
    # Fix mode display to show user-friendly text
    mode_raw = user.get('forwarding_mode', 'topics')
    if mode_raw == 'topics':
        mode_display = "Topics Only"
    elif mode_raw == 'auto':
        mode_display = "Groups Only"
    elif mode_raw == 'both':
        mode_display = "Topics & Groups"
    else:
        mode_display = mode_raw.capitalize()
    
    preset = user.get('interval_preset', 'medium')
    cycle_sec = int(get_cycle_interval_sec(user))
    cycle_min = max(1, cycle_sec // 60)
    if user.get('msg_delay_sec'):
        msg_d = int(user.get('msg_delay_sec') or 30)
        speed_lbl = 'Custom msg'
    elif preset == 'custom' and user.get('custom_interval'):
        custom = user.get('custom_interval') or {}
        msg_d = int(custom.get('msg_delay') or 30)
        speed_lbl = 'Custom'
    else:
        info = INTERVAL_PRESETS.get(preset) or INTERVAL_PRESETS.get('medium') or {}
        msg_d = int(info.get('msg_delay') or 30)
        speed_lbl = {'slow': 'Slow', 'medium': 'Normal', 'fast': 'Fast'}.get(
            str(preset), str(preset).capitalize()
        )
    try:
        msg_d = max(int(MIN_MSG_DELAY), int(msg_d))
    except Exception:
        msg_d = 5
    quiet_lbl = _quiet_hours_label_from_doc(user)
    freq = get_user_freq_per_hour(user)
    freq_lbl = f"{freq}/hr" if freq else "OFF"
    ar_on = bool(user.get('autoreply_enabled'))
    kw_n = len(user.get('keyword_replies') or [])
    kw_note = f" ({kw_n} keywords)" if kw_n else ""

    return (
        "<b>Dashboard</b>\n\n"
        "<b>━━━━━━━━━━━━━━━━━</b>\n\n"
        "<b>Status:</b>\n"
        f"├ <b>Plan:</b> <code>{plan_name} ({expiry_text})</code>\n"
        f"├ <b>Accounts:</b> <code>{len(accounts)}/{max_acc}</code> (Active: <code>{active}</code>)\n"
        f"├ <b>Mode:</b> <code>{mode_display}</code>\n"
        f"├ <b>Msg speed:</b> <code>{speed_lbl}</code> (<code>{msg_d}s</code> gap)\n"
        f"├ <b>Cycle gap:</b> <code>{cycle_sec}s</code> (<code>{cycle_min} min</code>)\n"
        f"├ <b>Freq cap:</b> <code>{freq_lbl}</code>\n"
        f"├ <b>Quiet hours:</b> <code>{quiet_lbl}</code>\n"
        f"└ <b>Auto-reply:</b> <code>{'ON' if ar_on else 'OFF'}</code>{kw_note}\n\n"
        "<b>━━━━━━━━━━━━━━━━━</b>\n\n"
        "<i>Tip: Open <b>Start / Manage Ads</b> to run ads, set timing, and choose groups or topics.</i>"
    )


# ===================== Keyboards =====================

def new_welcome_keyboard():
    """New welcome screen with single Launch Ads button."""
    return [
        [Button.inline("Launch Ads", b"adsye_now")],
        [Button.url("Support", MESSAGES['support_link']), Button.url("Updates", MESSAGES['updates_link'])]
    ]

def plan_select_keyboard(user_id=None, user=None):
    """Plan selection: Starter, Pro, Elite (2x2 grid layout).

    Prefer passing `user` already loaded via await db_call so async handlers
    never block the event loop on Mongo. Sync get_user only if user is omitted.
    """
    if user is None and user_id is not None:
        user = get_user(user_id)
    user_plan = normalize_plan_key(user.get('plan') or user.get('plan_name')) if user else ""
    is_prem = False
    if user:
        expires_at = user.get('premium_expires_at') or user.get('premium_expiry') or user.get('plan_expiry')
        if user.get('is_premium') or user.get('premium') or (user_plan in PLANS):
            is_prem = True
        if expires_at and isinstance(expires_at, datetime):
            if expires_at < datetime.now():
                is_prem = False
                user_plan = ""
            else:
                is_prem = True
    elif user_id is not None:
        is_prem = is_premium(user_id)

    buttons = []

    # First row: Starter
    row1 = []
    grow_label = "✓ Starter (Active)" if user_plan == 'grow' and is_prem else f"Starter ({PLANS['grow']['price_display']})"
    row1.append(Button.inline(grow_label, b"plan_grow"))
    buttons.append(row1)

    # Second row: Pro + Elite
    prime_label = "✓ Pro (Active)" if user_plan == 'prime' and is_prem else f"Pro ({PLANS['prime']['price_display']})"
    dominion_label = "✓ Elite (Active)" if user_plan == 'dominion' and is_prem else f"Elite ({PLANS['dominion']['price_display']})"
    buttons.append([
        Button.inline(prime_label, b"plan_prime"),
        Button.inline(dominion_label, b"plan_dominion")
    ])

    # Dashboard button
    buttons.append([Button.inline("🏠 Dashboard", b"enter_dashboard")])

    return buttons


async def _safe_cb_edit(event, text, buttons=None, file=None, parse_mode='html'):
    """Edit a callback message safely.

    Telegram often rejects edit-with-file when the existing message has no media
    (or different media). That exception was swallowed after event.answer() so
    plan/UPI buttons looked dead. Strategy:
      1) text-only edit when no file
      2) try edit with file when provided
      3) on failure: delete old message and send a fresh one
    """
    if isinstance(file, str):
        file = file.strip() or None
    uid = event.sender_id
    try:
        if file:
            await event.edit(text, parse_mode=parse_mode, buttons=buttons, file=file)
        else:
            await event.edit(text, parse_mode=parse_mode, buttons=buttons)
        return
    except MessageNotModifiedError:
        return
    except Exception as e:
        print(f"[UI] event.edit failed ({e}); falling back to send")
    try:
        try:
            await event.delete()
        except Exception:
            pass
        if file:
            await main_bot.send_file(uid, file, caption=text, parse_mode=parse_mode, buttons=buttons)
        else:
            await main_bot.send_message(uid, text, parse_mode=parse_mode, buttons=buttons)
    except Exception as e2:
        print(f"[UI] fallback send failed: {e2}")
        try:
            await main_bot.send_message(uid, text, parse_mode=parse_mode, buttons=buttons)
        except Exception as e3:
            print(f"[UI] text-only fallback failed: {e3}")

def tier_selection_keyboard():
    return [
        [Button.inline("See Pricing", b"tier_premium")],
        [Button.inline("Home", b"back_start")]
    ]

def main_dashboard_keyboard(user_id, *, viewer_id=None):
    viewer = int(viewer_id) if viewer_id is not None else int(user_id)
    target = int(user_id)
    buttons = [
        [Button.inline("📢 Start / Manage Ads", b"menu_broadcast")],
        [Button.inline("📱 Accounts", b"menu_account"), Button.inline("👤 Profile", b"my_profile")],
        [Button.inline("💎 Plans & Pricing", b"back_plans"), Button.inline("📖 Guide", b"menu_guide")],
        [Button.inline("ℹ️ Status", b"menu_status")],
    ]
    if is_admin(viewer) and is_impersonating(viewer):
        buttons.append([Button.inline("↩️ Exit User View", b"stop_impersonate")])
    elif is_admin(viewer):
        buttons.append([Button.inline("🛠 Admin Panel", b"admin_panel")])
    elif not is_premium(target):
        buttons.append([Button.url("🎁 Free Trial", "https://t.me/jirenog")])
    return buttons

def broadcast_menu_keyboard(user_id):
    # Light query only (avoid loading full account docs for a boolean)
    try:
        has_active = accounts_col.count_documents(
            {'owner_id': int(user_id), 'is_forwarding': True}, limit=1
        ) > 0
    except Exception:
        accounts = get_user_accounts(user_id)
        has_active = any(acc.get('is_forwarding') for acc in accounts)
    ads_btn = "⏹ Stop Ads" if has_active else "▶️ Start Ads"
    ads_data = b"stop_all_ads" if has_active else b"start_all_ads"
    rows = [
        [Button.inline(ads_btn, ads_data)],
        [Button.inline("⏱ Timing", b"menu_interval"), Button.inline("🎯 Where to Send", b"menu_fwd_mode")],
        [Button.inline("⚙️ Settings", b"menu_settings"), Button.inline("📊 Stats", b"menu_analytics")],
    ]
    if is_admin(user_id):
        rows.append([Button.inline("🔗 Click Stats", b"menu_results")])
    rows.append([Button.inline("🏠 Home", b"enter_dashboard")])
    return rows

def account_list_keyboard(user_id, page=0):
    accounts = get_user_accounts(user_id)
    max_accounts = get_user_max_accounts(user_id)
    total = len(accounts)
    pages = max(1, (total + ACCOUNTS_PER_PAGE - 1) // ACCOUNTS_PER_PAGE)
    
    start = page * ACCOUNTS_PER_PAGE
    end = min(start + ACCOUNTS_PER_PAGE, total)
    page_accounts = accounts[start:end]
    
    buttons = []
    for i, acc in enumerate(page_accounts):
        idx = start + i + 1
        name = acc.get('name', 'Unknown')
        status_emoji, status_text = _status_label_for_account(acc)
        buttons.append([Button.inline(
            f"{status_emoji} {status_text} #{idx} - {name}",
            f"acc_{acc['_id']}",
        )])
    
    nav = []
    if page > 0:
        nav.append(Button.inline("⬅️ Prev", f"accpage_{page-1}"))
    if page < pages - 1:
        nav.append(Button.inline("➡️ Next", f"accpage_{page+1}"))
    if nav:
        buttons.append(nav)
    
    if total >= max_accounts:
        buttons.append([Button.inline("Add Account (limit)", b"account_limit_reached"), Button.inline("Remove", b"delete_account_menu")])
    else:
        buttons.append([Button.inline("Add Account", b"add_account"), Button.inline("Remove", b"delete_account_menu")])
    buttons.append([Button.inline("Home", b"enter_dashboard")])
    
    return buttons

def settings_menu_keyboard(uid):
    return [
        [Button.inline("🤖 Automation", b"menu_settings_automation")],
        [Button.inline("💬 Messages & Logs", b"menu_settings_content")],
        [Button.inline("⬅️ Back", b"menu_broadcast")],
    ]

def settings_automation_keyboard(uid):
    buttons = []
    user_doc = get_user(uid)

    # Premium-only features (show locked for free users)
    if is_premium(uid):
        buttons.append([Button.inline("\U0001F504 Smart Rotation", b"menu_smart_rotation")])  # 🔄
        buttons.append([Button.inline("\U0001F465 Auto Group Join", b"menu_auto_group_join")])  # 👥
    else:
        buttons.append([Button.inline("\U0001F504 Smart Rotation 🔒", b"locked_smart_rotation")])
        buttons.append([Button.inline("\U0001F465 Auto Group Join 🔒", b"locked_auto_group_join")])

    quiet_label = _quiet_hours_label_from_doc(user_doc)
    buttons.append([Button.inline(f"Quiet Hours: {quiet_label}", b"menu_quiet_hours")])

    # Refresh All Groups - free for everyone
    buttons.append([Button.inline("🔄 Refresh All Groups", b"refresh_all_groups")])

    # Auto Leave Failed Groups toggle
    auto_leave_enabled = user_doc.get('auto_leave_groups', True)
    leave_status = "✅ ON" if auto_leave_enabled else "❌ OFF"
    buttons.append([Button.inline(f"Auto Leave Failed: {leave_status}", b"toggle_auto_leave")])

    # Drop Toxic Groups toggle (default ON): stop sending to admin-only /
    # ban-on-post / heavy slow-mode groups that burn the account.
    prune_enabled = user_doc.get('toxic_prune', TOXIC_PRUNE_DEFAULT)
    prune_status = "\u2705 ON" if prune_enabled else "\u274C OFF"
    buttons.append([Button.inline(f"\U0001F6E1\uFE0F Drop Toxic Groups: {prune_status}", b"toggle_toxic_prune")])
    buttons.append([Button.inline("\U0001F6E1\uFE0F View Toxic Groups", b"view_toxic_groups")])

    buttons.append([Button.inline("\u2190 Back", b"menu_settings")])
    return buttons

def quiet_hours_menu(uid):
    user_doc = get_user(uid)
    q = user_doc.get('quiet_hours') or {}
    start = _parse_time_24h(q.get('start'))
    end = _parse_time_24h(q.get('end'))
    current = f"{start}-{end}" if q.get('enabled') and start and end else "Off"

    def mark(s, e):
        if q.get('enabled') and start == s and end == e:
            return " (Active)"
        return ""

    off_mark = " (Active)" if not q.get('enabled') else ""
    buttons = [
        [Button.inline(f"Off{off_mark}", b"quiet_off")],
        [Button.inline(f"01:00 - 07:00{mark('01:00', '07:00')}", b"quiet_preset_0100_0700")],
        [Button.inline(f"00:00 - 06:00{mark('00:00', '06:00')}", b"quiet_preset_0000_0600")],
        [Button.inline(f"00:00 - 07:00{mark('00:00', '07:00')}", b"quiet_preset_0000_0700")],
        [Button.inline("Custom Interval", b"quiet_custom")],
        [Button.inline("Back", b"menu_settings_automation")],
    ]

    text = (
        "<b>Quiet Hours</b>\n\n"
        "Pause broadcasts during the selected hours.\nChoose <b>Off</b> for 24/7.\n\n"
        f"<b>Current:</b> <code>{current}</code>"
    )
    return text, buttons

def settings_content_keyboard(uid):
    buttons = []

    # Auto Reply - Show locked for free users
    if can_use_private_autoreply(uid):
        buttons.append([Button.inline("\U0001F4AC Auto Reply", b"menu_autoreply")])  # 💬
    else:
        buttons.append([Button.inline("\U0001F4AC Auto Reply 🔒", b"locked_autoreply")])  # 💬🔒

    # Topics - Show locked for free users
    if is_premium(uid):
        buttons.append([Button.inline("\U0001F4C2 Topics", b"menu_topics")])  # 📂
    else:
        buttons.append([Button.inline("\U0001F4C2 Topics 🔒", b"locked_topics")])  # 📂🔒

    buttons.extend([
        [Button.inline("\U0001F4DD Logs", b"menu_logs")],            # 📝
        [Button.inline("\U0001F4E3 Ads Mode", b"menu_ads_mode")],     # 📣
    ])

    buttons.append([Button.inline("\u2190 Back", b"menu_settings")])
    return buttons

def _admin_user_detail_callback(target_id: int, source: str) -> str:
    if source == 'all':
        return f"admin_user_detail_all_{target_id}"
    return f"admin_user_detail_{target_id}"

def admin_settings_menu(target_id: int, source: str):
    user = get_user(target_id)
    mode = user.get('forwarding_mode', 'auto')
    ads_mode = user.get('ads_mode', 'saved')
    preset = user.get('interval_preset', 'medium')
    cycle_sec = get_cycle_interval_sec(user)
    if user.get('msg_delay_sec'):
        interval_display = f"Custom msg ({int(user['msg_delay_sec'])}s / {cycle_sec}s cycle)"
    elif preset == 'custom' and user.get('custom_interval'):
        custom = user.get('custom_interval', {})
        interval_display = f"Custom ({custom.get('msg_delay', 30)}s / {cycle_sec}s cycle)"
    else:
        preset_info = INTERVAL_PRESETS.get(preset, INTERVAL_PRESETS['medium'])
        interval_display = f"{preset.capitalize()} ({preset_info['msg_delay']}s msg / {cycle_sec}s cycle)"

    text = (
        "<b>Admin: User Settings</b>\n\n"
        f"<b>User ID:</b> <code>{target_id}</code>\n"
        f"<b>Mode:</b> <code>{mode}</code>\n"
        f"<b>Intervals:</b> <code>{interval_display}</code>\n"
        f"<b>Ads Mode:</b> <code>{ads_mode}</code>\n\n"
        "<i>Choose what to update for this user.</i>"
    )
    buttons = [
        [Button.inline("Mode", f"admin_settings_mode_{target_id}_{source}")],
        [Button.inline("Intervals", f"admin_settings_interval_{target_id}_{source}")],
        [Button.inline("Ads Mode", f"admin_settings_ads_{target_id}_{source}")],
        [Button.inline("Back", _admin_user_detail_callback(target_id, source))]
    ]
    return text, buttons

def admin_automation_menu(target_id: int, source: str):
    user_doc = get_user(target_id)
    is_prem = is_premium(target_id)
    quiet_label = _quiet_hours_label_from_doc(user_doc)
    rotation_on = user_doc.get('smart_rotation', True)
    auto_leave_on = user_doc.get('auto_leave_groups', True)

    text = (
        "<b>Admin: Automation Tools</b>\n\n"
        f"<b>User ID:</b> <code>{target_id}</code>\n\n"
        "Manage rotation, group join, quiet hours, refresh, and auto leave."
    )

    buttons = []
    if is_prem:
        buttons.append([Button.inline(f"Smart Rotation: {'ON' if rotation_on else 'OFF'}", f"admin_toggle_smart_rotation_{target_id}_{source}")])
        buttons.append([Button.inline("Auto Group Join", f"admin_auto_group_join_{target_id}_{source}")])
    else:
        buttons.append([Button.inline("Smart Rotation 🔒", f"admin_locked_smart_rotation_{target_id}_{source}")])
        buttons.append([Button.inline("Auto Group Join 🔒", f"admin_locked_auto_group_join_{target_id}_{source}")])

    buttons.append([Button.inline(f"Quiet Hours: {quiet_label}", f"admin_quiet_hours_{target_id}_{source}")])
    buttons.append([Button.inline("🔄 Refresh All Groups", f"admin_refresh_all_{target_id}_{source}")])
    buttons.append([Button.inline(f"Auto Leave Failed: {'✅ ON' if auto_leave_on else '❌ OFF'}", f"admin_toggle_auto_leave_{target_id}_{source}")])
    buttons.append([Button.inline("Back", _admin_user_detail_callback(target_id, source))])
    return text, buttons

def admin_content_menu(target_id: int, source: str):
    user_doc = get_user(target_id)
    is_prem = is_premium(target_id)
    auto_reply_on = user_doc.get('autoreply_enabled', False)
    logs_enabled = bool(user_doc.get('logs_chat_id'))
    ads_mode = user_doc.get('ads_mode', 'saved')

    text = (
        "<b>Admin: Messaging & Logs</b>\n\n"
        f"<b>User ID:</b> <code>{target_id}</code>\n"
        f"<b>Auto Reply:</b> <code>{'ON' if auto_reply_on else 'OFF'}</code>\n"
        f"<b>Logs:</b> <code>{'Enabled' if logs_enabled else 'Disabled'}</code>\n"
        f"<b>Ads Mode:</b> <code>{ads_mode}</code>\n\n"
        "<i>Choose what to update for this user.</i>"
    )
    buttons = []
    if is_prem:
        buttons.append([Button.inline("Auto Reply", f"admin_menu_autoreply_{target_id}_{source}")])
        buttons.append([Button.inline("Topics", f"admin_menu_topics_{target_id}_{source}")])
    else:
        buttons.append([Button.inline("Auto Reply 🔒", f"admin_locked_autoreply_{target_id}_{source}")])
        buttons.append([Button.inline("Topics 🔒", f"admin_locked_topics_{target_id}_{source}")])
    buttons.append([Button.inline("Logs", f"admin_menu_logs_{target_id}_{source}")])
    buttons.append([Button.inline("Ads Mode", f"admin_settings_ads_{target_id}_{source}")])
    buttons.append([Button.inline("Back", _admin_user_detail_callback(target_id, source))])
    return text, buttons

def admin_autoreply_menu(target_id: int, source: str):
    user_doc = get_user(target_id)
    enabled = user_doc.get('autoreply_enabled', False)
    accounts = get_user_accounts(target_id)
    has_custom = False
    if accounts:
        _ids = [str(acc['_id']) for acc in accounts]
        has_custom = account_settings_col.count_documents(
            {'account_id': {'$in': _ids}, 'auto_reply': {'$nin': [None, '']}}
        ) > 0

    text = (
        "<b>Admin: Auto Reply</b>\n\n"
        f"<b>User ID:</b> <code>{target_id}</code>\n"
        f"<b>Status:</b> <code>{'ON' if enabled else 'OFF'}</code>\n"
        f"<b>Custom Reply:</b> <code>{'Set' if has_custom else 'Not Set'}</code>"
    )
    buttons = [
        [Button.inline("Toggle Auto Reply", f"admin_autoreply_toggle_{target_id}_{source}")],
        [Button.inline("Set Message", f"admin_autoreply_set_{target_id}_{source}")],
        [Button.inline("View Current", f"admin_autoreply_view_{target_id}_{source}")],
        [Button.inline("Back", f"admin_menu_content_{target_id}_{source}")],
    ]
    return text, buttons

def admin_logs_menu(target_id: int, source: str):
    user_doc = get_user(target_id)
    enabled = bool(user_doc.get('logs_chat_id'))
    status = "✅ Enabled" if enabled else "❌ Disabled"
    buttons = []
    if enabled:
        buttons.append([Button.inline("Disable Logs", f"admin_logs_disable_{target_id}_{source}")])
    else:
        buttons.append([Button.inline("Enable Logs", f"admin_logs_enable_{target_id}_{source}")])
    buttons.append([Button.inline("Back", f"admin_menu_content_{target_id}_{source}")])
    text = (
        "<b>Admin: Logs</b>\n\n"
        f"<b>User ID:</b> <code>{target_id}</code>\n"
        f"<b>Status:</b> <code>{status}</code>\n\n"
        "<i>Logs are sent to the user's logger bot chat.</i>"
    )
    return text, buttons

def admin_quiet_hours_menu(target_id: int, source: str):
    user_doc = get_user(target_id)
    q = user_doc.get('quiet_hours') or {}
    start = _parse_time_24h(q.get('start'))
    end = _parse_time_24h(q.get('end'))
    current = f"{start}-{end}" if q.get('enabled') and start and end else "Off"

    def mark(s, e):
        if q.get('enabled') and start == s and end == e:
            return " (Active)"
        return ""

    off_mark = " (Active)" if not q.get('enabled') else ""
    buttons = [
        [Button.inline(f"Off{off_mark}", f"admin_quiet_off_{target_id}_{source}")],
        [Button.inline(f"01:00 - 07:00{mark('01:00', '07:00')}", f"admin_quiet_preset_{target_id}_0100_0700_{source}")],
        [Button.inline(f"00:00 - 06:00{mark('00:00', '06:00')}", f"admin_quiet_preset_{target_id}_0000_0600_{source}")],
        [Button.inline(f"00:00 - 07:00{mark('00:00', '07:00')}", f"admin_quiet_preset_{target_id}_0000_0700_{source}")],
        [Button.inline("Custom Interval", f"admin_quiet_custom_{target_id}_{source}")],
        [Button.inline("Back", f"admin_settings_automation_{target_id}_{source}")],
    ]
    text = (
        "<b>Admin: Quiet Hours</b>\n\n"
        f"<b>User ID:</b> <code>{target_id}</code>\n\n"
        f"<b>Current:</b> <code>{current}</code>"
    )
    return text, buttons
def admin_mode_menu(target_id: int, source: str):
    user = get_user(target_id)
    current = user.get('forwarding_mode', 'auto')
    modes = {
        'topics': 'Forward to Topics Only',
        'auto': 'Forward to Groups Only',
        'both': 'Forward to Both (Topics first, then Groups)'
    }
    buttons = []
    for mode, label in modes.items():
        mark = " ✓" if mode == current else ""
        buttons.append([Button.inline(f"{label}{mark}", f"admin_set_mode_{target_id}_{mode}_{source}")])
    buttons.append([Button.inline("Back", f"admin_set_settings_{target_id}_{source}")])
    text = (
        "<b>Admin: Set Mode</b>\n\n"
        f"<b>User ID:</b> <code>{target_id}</code>\n\n"
        "Select how ads should be forwarded for this user."
    )
    return text, buttons

def admin_interval_menu(target_id: int, source: str):
    user = get_user(target_id) or {}
    cur_sec = get_cycle_interval_sec(user)
    def mark_sec(sec: int) -> str:
        return " ✓" if int(cur_sec) == int(sec) else ""
    preset = user.get('interval_preset', 'medium')
    def mark_p(key: str) -> str:
        return " ✓" if preset == key and not user.get('msg_delay_sec') else ""
    if user.get('msg_delay_sec'):
        msg_lbl = f"{int(user['msg_delay_sec'])}s (custom)"
    elif preset == 'custom' and user.get('custom_interval'):
        msg_lbl = f"{int((user.get('custom_interval') or {}).get('msg_delay') or 30)}s (custom)"
    else:
        info = INTERVAL_PRESETS.get(preset) or INTERVAL_PRESETS.get('medium') or {}
        msg_lbl = f"{int(info.get('msg_delay') or 30)}s ({preset})"
    freq = get_user_freq_per_hour(user)
    freq_lbl = f"{freq}/hr" if freq else "OFF"
    buttons = [
        [Button.inline(f"Slow{mark_p('slow')}", f"admin_msg_preset_{target_id}_slow_{source}"),
         Button.inline(f"Medium{mark_p('medium')}", f"admin_msg_preset_{target_id}_medium_{source}"),
         Button.inline(f"Fast{mark_p('fast')}", f"admin_msg_preset_{target_id}_fast_{source}")],
        [Button.inline("Custom msg delay", f"admin_msg_custom_{target_id}_{source}")],
        [Button.inline(f"10 min{mark_sec(600)}", f"admin_cycle_{target_id}_600_{source}"),
         Button.inline(f"20 min{mark_sec(1200)}", f"admin_cycle_{target_id}_1200_{source}")],
        [Button.inline(f"30 min{mark_sec(1800)}", f"admin_cycle_{target_id}_1800_{source}"),
         Button.inline("Custom cycle", f"admin_cycle_custom_{target_id}_{source}")],
        [Button.inline("Clear cycle override", f"admin_cycle_clear_{target_id}_{source}")],
        [Button.inline(f"Freq: {freq_lbl}", f"admin_user_freq_{target_id}_{source}"),
         Button.inline("Freq OFF", f"admin_user_freq_off_{target_id}_{source}")],
        [Button.inline("Back", f"admin_set_settings_{target_id}_{source}")],
    ]
    msg = (
        f"<b>Admin: Intervals for user</b>" + chr(10)*2
        + f"<b>User ID:</b> <code>{target_id}</code>" + chr(10)
        + f"<b>Msg gap:</b> <code>{msg_lbl}</code>" + chr(10)
        + f"<b>Cycle gap:</b> <code>{cur_sec}s</code> ({cur_sec // 60} min)" + chr(10)
        + f"<b>Frequency cap:</b> <code>{freq_lbl}</code>" + chr(10)*2
        + "Slow/Med/Fast/Custom msg = message gap." + chr(10)
        + "10/20/30/Custom cycle = cycle gap." + chr(10)
        + "Freq = max cycles/hour (never shortens cycle gap)."
    )
    return msg, buttons


def admin_ads_mode_menu(target_id: int, source: str):
    user = get_user(target_id)
    mode = user.get('ads_mode', 'saved')
    buttons = [
        [Button.inline("Saved Message" + (" ✓" if mode == 'saved' else ""), f"admin_set_ads_{target_id}_saved_{source}")],
        [Button.inline("Custom Message" + (" ✓" if mode == 'custom' else ""), f"admin_set_ads_{target_id}_custom_{source}")],
        [Button.inline("Post Link" + (" ✓" if mode == 'post' else ""), f"admin_set_ads_{target_id}_post_{source}")],
        [Button.inline("Back", f"admin_set_settings_{target_id}_{source}")],
    ]
    text = (
        "<b>Admin: Set Ads Mode</b>\n\n"
        f"<b>User ID:</b> <code>{target_id}</code>\n\n"
        "<i>Note: Custom/Post modes require the user to have set a message/link.</i>"
    )
    return text, buttons

def render_interval_settings_text(user) -> str:
    """Human-readable interval panel (msg gap + real cycle gap + freq)."""
    preset = (user or {}).get('interval_preset', 'medium')
    cycle_sec = int(get_cycle_interval_sec(user))
    cycle_min = max(1, cycle_sec // 60)
    if (user or {}).get('msg_delay_sec'):
        msg_d = int(user.get('msg_delay_sec') or 30)
        mode = 'Custom msg'
    elif preset == 'custom' and (user or {}).get('custom_interval'):
        custom = user.get('custom_interval') or {}
        msg_d = int(custom.get('msg_delay') or 30)
        mode = 'Custom'
    else:
        info = INTERVAL_PRESETS.get(preset) or INTERVAL_PRESETS.get('medium') or {}
        msg_d = int(info.get('msg_delay') or 30)
        mode = {'slow':'Slow','medium':'Normal','fast':'Fast'}.get(str(preset), str(preset).capitalize())
    try:
        msg_d = max(int(MIN_MSG_DELAY), int(msg_d))
    except Exception:
        msg_d = 5
    freq = get_user_freq_per_hour(user)
    freq_lbl = f"~{freq}/hr" if freq else "OFF (cycle gap only)"
    nl = chr(10)
    return (
        "<b>Interval Settings</b>" + nl + nl
        + "<b>Current Configuration:</b>" + nl
        + f"├ <b>Msg speed:</b> <code>{mode}</code>" + nl
        + f"├ <b>Msg gap:</b> <code>{msg_d}s</code> between groups" + nl
        + f"└ <b>Cycle gap:</b> <code>{cycle_sec}s</code> (<code>{cycle_min} min</code>)" + nl + nl
        + f"Frequency cap: <code>{freq_lbl}</code> (max cycles/hour; never shortens cycle gap)"
    )

def interval_menu_keyboard(user_id, viewer_id=None):
    """Cycle-interval picker. Live logs only for admin while impersonating."""
    user = get_user(user_id)
    cur_sec = get_cycle_interval_sec(user)
    viewer = int(viewer_id) if viewer_id is not None else int(user_id)

    def mark_sec(sec: int) -> str:
        return " ✅" if int(cur_sec) == int(sec) else ""

    rows = [
        [Button.inline(f"Cycle 10m{mark_sec(600)}", b"cycle_interval_600"),
         Button.inline(f"Cycle 20m{mark_sec(1200)}", b"cycle_interval_1200")],
        [Button.inline(f"Cycle 30m{mark_sec(1800)}", b"cycle_interval_1800"),
         Button.inline("Custom cycle", b"cycle_interval_custom")],
    ]
    current = user.get('interval_preset', 'medium')
    def mark_for(key: str) -> str:
        if user.get('msg_delay_sec'):
            return ""
        return " ✓" if key == current else ""
    rows.append([
        Button.inline(f"Slow{mark_for('slow')}", b"interval_slow"),
        Button.inline(f"Normal{mark_for('medium')}", b"interval_medium"),
        Button.inline(f"Fast{mark_for('fast')}", b"interval_fast"),
    ])
    rows.append([Button.inline("Custom gap", b"interval_msg_custom")])
    if is_admin(viewer) and is_impersonating(viewer):
        rows.append([Button.inline(f"🎯 Global freq default: {get_effective_target_per_hour()}/hr", b"interval_freq")])
        _ll = "✅ ON" if live_logs_enabled() else "❌ OFF"
        rows.append([Button.inline(f"📝 Live Send Logs: {_ll}", b"toggle_live_logs")])
    rows.append([Button.inline("Back", b"menu_broadcast")])
    return rows


def autoreply_menu_keyboard(user_id):
    """Private + group auto-reply controls (premium)."""
    if is_premium(user_id) or is_admin(user_id):
        user = get_user(user_id)
        priv_on = bool(user.get('autoreply_enabled', False))
        grp_on = bool(user.get('group_autoreply_enabled', False))
        accounts = get_user_accounts(user_id)
        has_custom = False
        if accounts:
            _ids = [str(acc['_id']) for acc in accounts]
            has_custom = account_settings_col.count_documents(
                {'account_id': {'$in': _ids}, 'auto_reply': {'$nin': [None, '']}}
            ) > 0
        has_grp_msg = bool((user.get('group_auto_reply') or '').strip())
        kw_n = len(user.get('keyword_replies') or [])

        buttons = [
            [Button.inline(
                f"Private AR: {'ON ✅' if priv_on else 'OFF'}",
                b"autoreply_toggle",
            )],
            [Button.inline("🔑 Keywords", b"autoreply_list_keywords"),
             Button.inline("➕ Add Keyword", b"autoreply_add_keyword")],
            [Button.inline("Set Private Reply", b"autoreply_custom")],
        ]
        if has_custom:
            buttons.append([Button.inline("View Private Reply", b"autoreply_view")])
        if can_use_group_autoreply(user_id):
            buttons.append([Button.inline(
                f"Group AR: {'ON ✅' if grp_on else 'OFF'}",
                b"group_autoreply_toggle",
            )])
            buttons.append([Button.inline("Set Group Reply", b"group_autoreply_set")])
            if has_grp_msg:
                buttons.append([Button.inline("View Group Reply", b"group_autoreply_view")])
        else:
            buttons.append([Button.inline("Group AR 🔒 Elite", b"group_autoreply_locked")])
        buttons.append([Button.inline("← Back", b"menu_settings_content")])
    else:
        buttons = [
            [Button.inline("Unlock Auto Reply", b"go_premium")],
            [Button.inline("← Back", b"menu_settings_content")],
        ]
    return buttons


def delete_account_list_keyboard(user_id):
    accounts = get_user_accounts(user_id)
    buttons = []
    for acc in accounts:
        phone = acc['phone']
        name = acc.get('name', 'Unknown')[:12]
        buttons.append([Button.inline(f"Delete: {phone[-4:]} - {name}", f"confirm_del_{acc['_id']}")])
    buttons.append([Button.inline("Back", b"menu_account")])
    return buttons

def premium_contact_keyboard():
    return [
        [Button.url("Contact Admin", MESSAGES['support_link'])],
        [Button.inline("Back", b"enter_dashboard")]
    ]


async def apply_account_profile_templates(user_id: int):
    """Update all added accounts' profile last name + bio using templates from config.

    - First name is kept as-is
    - Last name forced to MESSAGES['account_last_name_tag']
    - Bio forced to MESSAGES['account_bio']
    """
    try:
        last_name = MESSAGES.get('account_last_name_tag', '')
        about = MESSAGES.get('account_bio', '')
        if not last_name and not about:
            return

        accounts = list(accounts_col.find({'owner_id': int(user_id)}))
        for acc in accounts:
            session = acc.get('session')
            if not session:
                continue

            # DECRYPT session before using it
            try:
                decrypted_session = cipher_suite.decrypt(session.encode()).decode()
            except Exception:
                continue

            client = TelegramClient(StringSession(decrypted_session), CONFIG['api_id'], CONFIG['api_hash'])
            try:
                await client.connect()
                me = await client.get_me()
                first_name = me.first_name or ''

                await client(UpdateProfileRequest(
                    first_name=first_name,
                    last_name=last_name,
                    about=about,
                ))
            except Exception:
                pass
            finally:
                try:
                    await client.disconnect()
                except Exception:
                    pass
    except Exception:
        return

def admin_panel_keyboard():
    return [
        [Button.inline("👥 Users", b"admin_all_users"), Button.inline("💎 Paid Users", b"admin_premium")],
        [Button.inline("📈 Overview", b"admin_users"), Button.inline("🎁 Give Plan", b"admin_grant_premium")],
        [Button.inline("📱 Accounts", b"admin_manage_accounts"), Button.inline("🚫 Banned", b"admin_banned_users")],
        [Button.inline("🔎 Find User", b"admin_find_user"), Button.inline("📣 Announce", b"admin_broadcast")],
        [Button.inline(f"🎯 Freq limit: {get_effective_target_per_hour()}/hr", b"interval_freq")],
        [Button.inline(f"📝 Live logs: {'ON' if live_logs_enabled() else 'OFF'}", b"toggle_live_logs")],
        [Button.inline("⏹ Stop everyone", b"admin_stop_all_broadcasts")],
        [Button.inline("👔 Staff", b"admin_admins")],
        [Button.inline("🏠 Home", b"enter_dashboard")],
    ]

def account_menu_keyboard(account_id, acc, user_id):
    fwd = acc.get('is_forwarding', False)
    # Start button removed per user request
    # Topics button removed per user request
    # Stats and Delete in same row
    buttons = [
        [Button.inline("Stats", f"stats_{account_id}"), Button.inline("Delete", f"delete_{account_id}")],
    ]
    
    if fwd:
        # Only show Stop button if account is currently running
        buttons.append([Button.inline("Stop", f"stop_{account_id}")])
    
    buttons.append([Button.inline("Back", b"enter_dashboard")])
    
    return buttons

def topics_menu_keyboard(account_id, user_id):
    tier_settings = get_user_tier_settings(user_id)
    max_topics = tier_settings.get('max_topics', 3)
    
    buttons = []
    row = []
    for i, t in enumerate(TOPICS[:max_topics]):
        count = account_topics_col.count_documents({'account_id': account_id, 'topic': t})
        row.append(Button.inline(f"{t.capitalize()} ({count})", f"topic_{account_id}_{t}"))
        
        # Add row when we have 3 buttons or it's the last topic
        if len(row) == 3 or i == max_topics - 1:
            buttons.append(row)
            row = []
    
    auto = account_auto_groups_col.count_documents({'account_id': account_id})
    buttons.append([Button.inline(f"Auto Groups ({auto})", f"auto_{account_id}")])
    buttons.append([Button.inline("Back", f"acc_{account_id}")])
    return buttons

def forwarding_select_keyboard(account_id, user_id):
    tier_settings = get_user_tier_settings(user_id)
    max_topics = tier_settings.get('max_topics', 3)
    
    buttons = []
    for t in TOPICS[:max_topics]:
        count = account_topics_col.count_documents({'account_id': account_id, 'topic': t})
        if count > 0:
            buttons.append([Button.inline(f"{t.capitalize()} ({count})", f"startfwd_{account_id}_{t}")])
    buttons.append([Button.inline("All Groups Only", f"startfwd_{account_id}_all")])
    buttons.append([Button.inline("Cancel", f"acc_{account_id}")])
    return buttons

def settings_keyboard(account_id, user_id):
    # Auto-reply button removed per user request
    buttons = [
        [Button.inline("Clear Failed", f"clearfailed_{account_id}")],
        [Button.inline("Back", f"acc_{account_id}")]
    ]
    return buttons

def otp_keyboard():
    return [
        [Button.inline("1", b"otp_1"), Button.inline("2", b"otp_2"), Button.inline("3", b"otp_3")],
        [Button.inline("4", b"otp_4"), Button.inline("5", b"otp_5"), Button.inline("6", b"otp_6")],
        [Button.inline("7", b"otp_7"), Button.inline("8", b"otp_8"), Button.inline("9", b"otp_9")],
        [Button.inline("Del", b"otp_back"), Button.inline("0", b"otp_0"), Button.inline("X", b"otp_cancel")],
        [Button.url("Get Code", "tg://openmessage?user_id=777000")]
    ]


@main_bot.on(events.NewMessage(pattern=r'^/help(?:@[\w_]+)?(?:\s|$)'))
async def cmd_help(event):
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        await event.respond("Admin only.")
        return
    text = "<b>Admin commands</b>\n\n<b>Users / access</b>\n<code>/users</code> — list users\n<code>/ban id reason</code> — ban user\n<code>/addadmin id</code> — add admin\n<code>/rmadmin id</code> — remove admin\n<code>/clearusers</code> — clear users (danger)\n\n<b>Plans</b>\n<code>/starter @user days</code> — grant Starter\n<code>/pro @user days</code> — grant Pro\n<code>/elite @user days</code> — grant Elite\n<code>/rmprm id</code> — remove premium\n<code>/seepremium</code> — list premium\n\n<b>Frequency / cycle</b>\n<code>/freq N</code> — global max cycles/hour\n<code>/freq @user N</code> — per-user cap\n<code>/freq @user no</code> — disable freq for user\n<code>/cyclegap @user minutes</code> — set cycle gap\n<code>/cycleinterval @user clear</code> — clear cycle override\n\n<b>Accounts</b>\n<code>/addaccount @user tg_id</code> — attach account\n<code>/removeacc @user phone</code> — remove account\n\n<b>Ops</b>\n<code>/health</code> — cluster health\n<code>/manager text</code> — ops chat\n<code>/endmanager</code> — end ops chat\n<code>/setcap N</code> — accounts/worker\n<code>/setproxycap N</code> — per-IP cap\n<code>/setworkers min max</code> — worker bounds\n<code>/nowarmup [@user]</code> — skip warmup\n<code>/warmup [@user]</code> — enable warmup\n<code>/broadcast msg</code> — message all users\n<code>/logmode</code> — detailed logs\n<code>/reboot</code> — maintenance\n<code>/help</code> — this list"
    await event.respond(text, parse_mode='html')


@main_bot.on(events.NewMessage(pattern=r'^/start(?:@[\w_]+)?(?:\s|$)'))
async def cmd_start(event):
    uid = event.sender_id
    try:
        # Offload sync Mongo — critical for UI latency under concurrent users
        is_admin_user = await db_call(is_admin, uid)
        user = await db_call(get_user, uid)
        if not is_admin_user:
            if user.get('banned'):
                reason = user.get('ban_reason', 'No reason provided')
                await event.respond(
                    f"<b>🚫 You Are Banned</b>\n\n"
                    f"<b>Reason:</b> <code>{reason}</code>\n\n"
                    f"<i>You can no longer use this bot. Contact admin if you think this is a mistake.</i>",
                    parse_mode='html'
                )
                return

            # Check if this is a new user and send notification
            if user.get('_is_new_user'):
                try:
                    sender = await event.get_sender()
                    _spawn_bg(notify_new_user(
                        uid,
                        sender.username,
                        sender.first_name or "Unknown",
                        sender.last_name or "",
                        getattr(sender, 'phone', None)
                    ))
                    # Remove flag
                    await db_call(uupdate, {'user_id': int(uid)}, {'$unset': {'_is_new_user': ''}})
                except Exception as e:
                    print(f"[NOTIFICATION] Error sending new user notification: {e}")

        # Force-join gate (admin bypass)
        if not await enforce_forcejoin_or_prompt(event):
            return

        approved = is_admin_user or user.get('approved', False)
        if not approved:
            await db_call(approve_user, uid)
            approved = True

        # Privacy / Terms gate (once) before dashboard
        if not is_admin_user and not user.get('privacy_accepted'):
            await event.respond(
                render_privacy_policy_text(),
                parse_mode='html',
                buttons=privacy_policy_keyboard(),
            )
            return

        dashboard_text = await db_call(render_dashboard_text, uid)
        dashboard_buttons = main_dashboard_keyboard(uid, viewer_id=uid)
        welcome_image = MESSAGES.get('welcome_image', '')

        if welcome_image:
            await event.respond(file=welcome_image, message=dashboard_text, parse_mode='html', buttons=dashboard_buttons)
        else:
            await event.respond(dashboard_text, parse_mode='html', buttons=dashboard_buttons)

        try:
            u2 = await db_call(get_user, uid)
            if u2 and not u2.get('onboarding_sent'):
                guide = (
                    "<b>👋 Quick start</b>\n\n"
                    "1. <b>Accounts</b> — add the Telegram account that will send ads\n"
                    "2. Put your ad in that account's <b>Saved Messages</b> (or set Ads Mode)\n"
                    "3. Join / add <b>groups</b> (or topics if on a paid plan)\n"
                    "4. Open <b>Start / Manage Ads</b> → <b>Start Ads</b>\n\n"
                    "<b>Useful:</b>\n"
                    "• <b>Timing</b> — speed between groups & rest between rounds\n"
                    "• <b>Where to Send</b> — groups, topics, or both\n"
                    "• <b>Plans & Pricing</b> — unlock more accounts & features\n\n"
                    "<i>Need help? Use Support from the menu.</i>"
                )
                await event.respond(guide, parse_mode='html')
                await db_call(uupdate, {'user_id': int(uid)}, {'$set': {'onboarding_sent': True}}, upsert=True)
        except Exception as _ob:
            print(f"[START] onboarding note skipped: {_ob}")
    except Exception as e:
        print(f"[START] cmd_start failed for {uid}: {e}")
        import traceback
        traceback.print_exc()
        try:
            await event.respond("⚠️ Temporary error opening the menu. Please try /start again in a moment.")
        except Exception:
            pass

@main_bot.on(events.NewMessage(pattern=r'^/startbroadcast(?:@[\w_]+)?(?:\s|$)'))
async def cmd_startbroadcast(event):
    uid = event.sender_id
    if not await db_call(is_approved, uid):
        await event.respond("Your access is not approved yet.")
        return
    started = await start_broadcast_for_user(uid)
    if started:
        await event.respond(f"✅ Broadcast started for {started} account(s).")
    else:
        await event.respond("No accounts to start. Add an account first.")

@main_bot.on(events.NewMessage(pattern=r'^/stopbroadcast(?:@[\w_]+)?(?:\s|$)'))
async def cmd_stopbroadcast(event):
    uid = event.sender_id
    stopped = await stop_broadcast_for_user(uid)
    if stopped:
        await event.respond(f"⏹️ Broadcast stopped for {stopped} account(s).")
    else:
        await event.respond("No active broadcasts were running.")

# /ban command - Admin only: Ban a user with reason
@main_bot.on(events.NewMessage(pattern=r'^/ban\s+(\d+)\s+(.+)'))
async def cmd_ban(event):
    if not await db_call(is_admin, event.sender_id):
        return
    
    target_id = int(event.pattern_match.group(1))
    reason = event.pattern_match.group(2).strip()
    
    # Ban the user
    await db_call(uupdate, 
        {'user_id': target_id},
        {'$set': {
            'banned': True,
            'ban_reason': reason,
            'banned_at': datetime.now(),
            'banned_by': event.sender_id
        }},
        upsert=True
    )
    
    # Notify the banned user
    try:
        await main_bot.send_message(
            target_id,
            f"<b>🚫 You Are Banned</b>\n\n"
            f"<b>Reason:</b> <code>{reason}</code>\n\n"
            f"<i>You can no longer use this bot. Contact admin if you think this is a mistake.</i>",
            parse_mode='html'
        )
    except Exception:
        pass
    
    await event.respond(f"✅ User {target_id} has been banned.\n\nReason: {reason}")

# /access command removed - no password required anymore
# /admin command removed per user request (use admin panel button from dashboard)
# /help command removed per user request

@main_bot.on(events.NewMessage(pattern=r'^/rmprm(?:@[\w_]+)?\s+(\d+)$'))
async def cmd_rmprm(event):
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        await event.respond("Admin only!")
        return
    
    target_id = int(event.pattern_match.group(1))
    await db_call(remove_user_premium, target_id)
    try:
        await db_call(_write_audit, admin_audit_col, uid, 'revoke_premium', target_id, 'cmd_rmprm')
    except Exception:
        pass
    await event.respond(f"Premium removed from {target_id}")

@main_bot.on(events.NewMessage(pattern=r'^/users(?:@[\w_]+)?(?:\s|$)'))
async def cmd_users(event):
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    
    users = get_all_users()
    if not users:
        await event.respond("No users.")
        return
    
    text = "**All Users**\n\n"
    for u in users[:50]:
        user_id = u.get('user_id')
        tier = u.get('tier', 'free')
        tier_icon = "P" if tier == 'premium' else "F"
        max_acc = get_plan_max_accounts(u)
        accounts = accounts_col.count_documents({'owner_id': user_id})
        is_owner = " (Admin)" if user_id == CONFIG['owner_id'] else ""
        text += f"[{tier_icon}] `{user_id}` - {accounts}/{max_acc} acc{is_owner}\n"
    
    if len(users) > 50:
        text += f"\n...+{len(users)-50} more"
    
    await event.respond(text)

@main_bot.on(events.NewMessage(pattern=r'^/clearusers(?:@[\w_]+)?(?:\s|$)'))
async def cmd_clearusers(event):
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    
    result = users_col.delete_many({'user_id': {'$ne': int(uid)}})
    approve_user(uid)
    
    await event.respond(f"Cleared {result.deleted_count} users!")

# /ping command removed per user request

@main_bot.on(events.NewMessage(pattern=r'^/reboot(?:@[\w_]+)?(?:\s|$)'))
async def cmd_reboot(event):
    """Admin: Reboot the bot (restart process)."""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    
    await event.respond("🔄 Rebooting bot...")
    
    # Restart the process
    os.execv(sys.executable, ['python'] + sys.argv)

@main_bot.on(events.NewMessage(pattern=r'^/addadmin(?:@[\w_]+)?\s+(\d+)$'))
async def cmd_addadmin(event):
    """Admin: Add admin."""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    
    target_uid = int(event.pattern_match.group(1))
    
    # Check if already admin
    if admins_col.find_one({'user_id': target_uid}):
        await event.respond(f"`{target_uid}` is already an admin!")
        return
    
    # Add to admins
    admins_col.insert_one({'user_id': target_uid, 'added_at': datetime.now(), 'added_by': uid})
    invalidate_admin_cache(target_uid)
    
    # Notify
    try:
        await main_bot.send_message(target_uid, "🎉 You've been granted admin access!")
    except Exception:
        pass
    
    await event.respond(f"✅ Added `{target_uid}` as admin!")

@main_bot.on(events.NewMessage(pattern=r'^/rmadmin(?:@[\w_]+)?\s+(\d+)$'))
async def cmd_rmadmin(event):
    """Admin: Remove admin."""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    
    target_uid = int(event.pattern_match.group(1))
    
    # Cannot remove owner
    if target_uid == CONFIG['owner_id']:
        await event.respond("Cannot remove owner!")
        return
    
    # Remove from admins
    result = admins_col.delete_one({'user_id': target_uid})
    invalidate_admin_cache(target_uid)
    
    if result.deleted_count > 0:
        # Notify
        try:
            await main_bot.send_message(target_uid, "❌ Your admin access has been revoked.")
        except Exception:
            pass
        
        await event.respond(f"✅ Removed `{target_uid}` from admins!")
    else:
        await event.respond(f"`{target_uid}` is not an admin!")

# /go command removed per user request (use Start button from dashboard)


# /run, /status, /me, /stats, /finduser, /stop commands removed per user request

@main_bot.on(events.NewMessage(pattern=r'^/mystats(?:@[\w_]+)?(?:\s|$)'))
async def cmd_mystats(event):
    """User: Show personal stats."""
    uid = event.sender_id
    
    if not await enforce_forcejoin_or_prompt(event):
        return
    
    user = await db_call(get_user, uid)
    accounts = await db_call(get_user_accounts, uid)
    tier = "Premium" if await db_call(is_premium, uid) else "No Plan"
    
    acc_ids = [str(acc['_id']) for acc in accounts]
    stats_docs = await db_call(lambda: list(
        account_stats_col.find({'account_id': {'$in': acc_ids}}, {'total_sent': 1, 'total_failed': 1})
    )) if acc_ids else []
    total_sent = sum(s.get('total_sent', 0) for s in stats_docs)
    total_failed = sum(s.get('total_failed', 0) for s in stats_docs)
    active = sum(1 for acc in accounts if acc.get('is_forwarding'))
    
    text = (
        f"📊 **Your Stats**\n\n"
        f"Tier: {tier}\n"
        f"Accounts: {len(accounts)}\n"
        f"Active: {active}\n\n"
        f"Total Sent: {total_sent}\n"
        f"Total Failed: {total_failed}\n"
    )
    
    await event.respond(text)

@main_bot.on(events.NewMessage(pattern=r'^/see\s+premium(?:@[\w_]+)?(?:\s|$)'))
@main_bot.on(events.NewMessage(pattern=r'^/seepremium(?:@[\w_]+)?(?:\s|$)'))
async def cmd_see_premium(event):
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return

    premium_users = list(users_col.find({'tier': 'premium'}))
    if not premium_users:
        await event.respond("No premium users.")
        return

    lines = []
    for u in premium_users:
        user_id = int(u.get('user_id'))
        username = u.get('username') or 'NoUsername'
        plan = get_display_plan_name(u)
        is_running = accounts_col.count_documents({'owner_id': user_id, 'is_forwarding': True}) > 0
        status = "running" if is_running else "stopped"
        lines.append(f"{user_id} | @{username} | {plan} | {status}")

    text = "**Premium Users**\n\n" + "\n".join(lines)
    await event.respond(text)

@main_bot.on(events.NewMessage(pattern=r'^/gpreply(?:@[\w_]+)?(?:\s+(.+))?$'))
async def cmd_gpreply(event):
    """Admin: allow or revoke Group Auto-Reply for a user (Elite feature grant)."""
    real_uid = event.sender_id
    if not await db_call(is_admin, real_uid):
        return
    arg = (event.pattern_match.group(1) or '').strip()
    if not arg:
        await event.respond(
            "Usage:\n"
            "<code>/gpreply &lt;user_id|@username&gt;</code> — allow Group AR\n"
            "<code>/gpreply &lt;user&gt; off</code> — revoke\n\n"
            "Elite plan users already have this. Grant is for Starter/Pro.",
            parse_mode='html',
        )
        return
    parts = arg.split()
    raw_user = parts[0]
    off = len(parts) > 1 and parts[1].lower() in ('off', 'no', '0', 'revoke', 'disable')
    target_id = await resolve_target_user_id(raw_user, event.client)
    if not target_id:
        await event.respond("❌ User not found.")
        return
    if off:
        await db_call(
            uupdate,
            {'user_id': int(target_id)},
            {'$set': {'group_autoreply_allowed': False, 'group_autoreply_enabled': False}},
            upsert=True,
        )
        await event.respond(
            f"✅ Group auto-reply <b>revoked</b> for <code>{target_id}</code>.",
            parse_mode='html',
        )
    else:
        await db_call(
            uupdate,
            {'user_id': int(target_id)},
            {'$set': {'group_autoreply_allowed': True}},
            upsert=True,
        )
        await event.respond(
            f"✅ Group auto-reply <b>allowed</b> for <code>{target_id}</code>.\n"
            f"They will see Group AR buttons under Auto Reply.",
            parse_mode='html',
        )


@main_bot.on(events.NewMessage(pattern=r'^/implogmode(?:@[\w_]+)?(?:\s+(.+))?$'))
async def cmd_implogmode(event):
    """Admin: 1-min LogMode for a user + mirror live send logs to admin."""
    real_uid = event.sender_id
    if not await db_call(is_admin, real_uid):
        return
    arg = (event.pattern_match.group(1) or '').strip()
    if not arg:
        await event.respond(
            "Usage: <code>/implogmode &lt;user_id|@username&gt;</code>\n"
            "Enables LogMode for 1 minute and mirrors live send logs to you.",
            parse_mode='html',
        )
        return
    target_id = await resolve_target_user_id(arg, event.client)
    if not target_id:
        await event.respond("❌ User not found.")
        return
    until = datetime.now() + timedelta(minutes=1)
    await db_call(
        uupdate,
        {'user_id': int(target_id)},
        {'$set': {'logmode_until': until}},
        upsert=True,
    )
    _logmode_mirrors[int(target_id)] = (int(real_uid), until)
    user = await db_call(get_user, int(target_id))
    if not user.get('logs_chat_id'):
        await db_call(
            uupdate,
            {'user_id': int(target_id)},
            {'$set': {'logs_chat_id': int(target_id)}},
            upsert=True,
        )
        try:
            invalidate_logs_cache()
        except Exception:
            pass
    await event.respond(
        f"✅ Impersonation LogMode for <code>{target_id}</code> — <b>1 minute</b>.\n"
        f"Live send logs for their accounts will also be mirrored to you.\n"
        f"<i>Enable Live Send Logs from Timing while View-as-user if needed "
        f"(requires LIVE_SEND_LOGS=1 in .env).</i>",
        parse_mode='html',
    )


@main_bot.on(events.NewMessage(pattern=r'^/logmode(?:@[\w_]+)?(?:\s|$)'))
async def cmd_logmode(event):
    uid = event.sender_id
    if await db_call(is_admin, uid):
        await event.respond("Admin already has view links enabled.")
        return
    if not await db_call(is_premium, uid):
        await event.respond("LogMode is available for premium users only.")
        return

    user = await db_call(get_user, uid)
    today = datetime.now().date().isoformat()
    last_used = user.get('logmode_last_used')
    if isinstance(last_used, datetime):
        last_used = last_used.date().isoformat()
    if str(last_used or "") == today:
        await event.respond("LogMode already used today. Try again tomorrow.")
        return

    until = datetime.now() + timedelta(minutes=1)
    await db_call(uupdate, 
        {'user_id': uid},
        {'$set': {'logmode_until': until, 'logmode_last_used': today}},
        upsert=True
    )
    await event.respond("LogMode enabled for 1 minute. View Message buttons will appear on new logs.")

@main_bot.on(events.NewMessage(pattern=r'^/upgrade(?:@[\w_]+)?(?:\s|$)'))
async def cmd_upgrade(event):
    """User: Show upgrade options."""
    uid = event.sender_id
    
    if not await enforce_forcejoin_or_prompt(event):
        return
    
    # Show plan selection
    plan_msg = (
        "**Choose Your Plan**\n\n"
        "Pick what fits your scale. You can upgrade anytime.\n\n"
        "• Starter — 2 accounts (₹199)\n"
        "• Pro — 3 accounts (₹299)\n"
        "• Elite — 4 accounts (₹399)"
    )
    
    welcome_image = MESSAGES.get('welcome_image', '')
    if welcome_image:
        await main_bot.send_file(uid, welcome_image, caption=plan_msg, buttons=plan_select_keyboard(uid))
    else:
        await event.respond(plan_msg, buttons=plan_select_keyboard(uid))

@main_bot.on(events.NewMessage(pattern=r'^/bd(?:@[\w_]+)?$', func=lambda e: e.is_reply))
async def cmd_bd_broadcast(event):
    """Admin: Broadcast by replying to a message with /bd - forwards with sender name, media, buttons"""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    
    # Get the replied message
    replied_msg = await event.get_reply_message()
    if not replied_msg:
        await event.respond("Reply to a message with /bd to broadcast it!")
        return
    
    users = get_all_users()
    total = len(users)
    
    # Get sender info
    sender = await replied_msg.get_sender()
    sender_name = getattr(sender, 'first_name', 'Unknown')
    sender_username = getattr(sender, 'username', None)
    sender_display = f"@{sender_username}" if sender_username else sender_name
    
    _spawn_bg(_run_forward_broadcast(event.chat_id, replied_msg, sender_display))
    await event.respond(f"📢 Broadcasting from {sender_display} in the background. A summary will follow here.")

async def _run_forward_broadcast(admin_chat_id, replied_msg, sender_display):
    """Paced, FloodWait-safe forward-broadcast (preserves media/buttons/formatting).
    Runs as a background task so the command handler is never blocked."""
    users = await db_call(lambda: list(users_col.find({}, {'user_id': 1})))
    total = len(users)
    sent = failed = 0
    delay = float(os.getenv('BROADCAST_DELAY', '0.1'))
    status = None
    try:
        status = await main_bot.send_message(admin_chat_id, f"\U0001F4E2 Broadcasting from {sender_display}: 0/{total}")
    except Exception:
        pass
    for i, u in enumerate(users):
        target = u.get('user_id')
        if target is None:
            continue
        while True:
            try:
                await main_bot.forward_messages(target, replied_msg, from_peer=admin_chat_id)
                sent += 1
                break
            except FloodWaitError as e:
                await asyncio.sleep(min(int(getattr(e, 'seconds', 5)) + 1, 300))
                continue
            except Exception:
                failed += 1
                break
        if status and ((i + 1) % 25 == 0 or (i + 1) == total):
            try:
                await status.edit(f"\U0001F4E2 Broadcasting from {sender_display}...\n{i + 1}/{total}\n\u2705 {sent}  \u274C {failed}")
            except Exception:
                pass
        await asyncio.sleep(delay)
    try:
        await main_bot.send_message(admin_chat_id, f"\u2705 Forward-broadcast complete\nFrom: {sender_display}\nTotal: {total}\nSent: {sent}\nFailed: {failed}")
    except Exception:
        pass


async def _run_text_broadcast(admin_chat_id, msg):
    """Paced, FloodWait-safe broadcast of a text announcement to all users.
    Runs as a background task so the command handler is never blocked."""
    users = await db_call(lambda: list(users_col.find({}, {'user_id': 1})))
    total = len(users)
    sent = failed = 0
    delay = float(os.getenv('BROADCAST_DELAY', '0.1'))
    status = None
    try:
        status = await main_bot.send_message(admin_chat_id, f"📢 Broadcast started: 0/{total}")
    except Exception:
        pass
    for i, u in enumerate(users):
        target = u.get('user_id')
        if target is None:
            continue
        while True:
            try:
                await main_bot.send_message(target, f"**Announcement**\n\n{msg}")
                sent += 1
                break
            except FloodWaitError as e:
                await asyncio.sleep(min(int(getattr(e, 'seconds', 5)) + 1, 300))
                continue
            except Exception:
                failed += 1
                break
        if status and ((i + 1) % 25 == 0 or (i + 1) == total):
            try:
                await status.edit(f"📢 Broadcasting...\n{i + 1}/{total}\n✅ {sent}  ❌ {failed}")
            except Exception:
                pass
        await asyncio.sleep(delay)
    try:
        await main_bot.send_message(admin_chat_id, f"✅ Broadcast complete\nTotal: {total}\nSent: {sent}\nFailed: {failed}")
    except Exception:
        pass


@main_bot.on(events.NewMessage(pattern=r'^/broadcast(?:@[\w_]+)?\s+(.+)$', func=lambda e: not e.is_reply))
async def cmd_broadcast(event):
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return

    msg = event.pattern_match.group(1)
    _spawn_bg(_run_text_broadcast(event.chat_id, msg))
    await event.respond("📢 Broadcast started in the background. I'll send a summary here when it finishes.")

# NOTE: /health is defined once, in the OPS MANAGER section (cluster-wide report).
# The old per-process snapshot handler was removed to avoid a duplicate double-reply.


@main_bot.on(events.NewMessage(pattern=r'^/freq(?:@[\w_]+)?\s+(\d+)$'))
async def cmd_freq(event):
    """ADMIN ONLY. Set the GLOBAL DEFAULT per-group send frequency (times/hour) for
    users WITHOUT a per-user override. Range 1..HARD_MAX_TARGET_PER_HOUR.
    Per-user override: /frequency <userid|@username> <n>."""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        await event.respond("Frequency is managed by admin.")
        return
    val = int(event.pattern_match.group(1))
    if val < 1 or val > HARD_MAX_TARGET_PER_HOUR:
        await event.respond(f"Usage: /freq <1-{HARD_MAX_TARGET_PER_HOUR}>  (global times/hour per group)")
        return
    set_global_setting('target_per_hour', val)
    await event.respond(
        f"🎯 GLOBAL frequency cap: max ~{val} cycles/hour (default).\n\n"
        "Ceiling only — never shortens cycle gap (10/20/30/custom). "
        "Takes effect within ~30s + the current round."
    )



@main_bot.on(events.NewMessage(pattern=r'^/frequency(?:@[\w_]+)?\s+(@?\w+)\s+(no|off|reset)$'))
@main_bot.on(events.NewMessage(pattern=r'^/freq(?:@[\w_]+)?\s+(@?\w+)\s+(no|off|reset)$'))
async def cmd_frequency_off(event):
    """ADMIN: /freq <user> no  — disable frequency cap; only cycle interval applies."""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        await event.respond("Frequency is managed by admin.")
        return
    raw_target = event.pattern_match.group(1)
    target_id = await resolve_target_user_id(raw_target, event.client)
    if not target_id:
        await event.respond("❌ User not found.")
        return
    await db_call(uupdate, {'user_id': int(target_id)}, {
        '$set': {'freq_disabled': True},
        '$unset': {'freq_per_hour': ''},
    })
    await event.respond(
        f"🎯 Frequency for <code>{target_id}</code> is <b>OFF</b>.\n"
        "Only their cycle interval will be used (gap never shortened).",
        parse_mode='html',
    )


@main_bot.on(events.NewMessage(pattern=r'^/freq(?:@[\w_]+)?\s+(@?\w+)\s+(\d+)$'))
async def cmd_freq_user(event):
    """ADMIN: /freq <user> <n> — set per-user cycle frequency cap."""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        await event.respond("Frequency is managed by admin.")
        return
    raw_target = event.pattern_match.group(1)
    val = int(event.pattern_match.group(2))
    if val < 1 or val > HARD_MAX_TARGET_PER_HOUR:
        await event.respond(f"Usage: /freq <user> <1-{HARD_MAX_TARGET_PER_HOUR}> or /freq <user> no")
        return
    target_id = await resolve_target_user_id(raw_target, event.client)
    if not target_id:
        await event.respond("❌ User not found.")
        return
    await db_call(uupdate, {'user_id': int(target_id)}, {
        '$set': {'freq_per_hour': val, 'freq_disabled': False},
    })
    await event.respond(
        f"🎯 Frequency for <code>{target_id}</code> set to max <b>{val}</b> cycles/hour.\n"
        "Cycle interval is never shortened — waits only increase if needed.",
        parse_mode='html',
    )


@main_bot.on(events.NewMessage(pattern=r'^/frequency(?:@[\w_]+)?\s+(@?\w+)\s+(\d+)$'))

@main_bot.on(events.NewMessage(pattern=r'^/cycleinterval(?:@[\w_]+)?\s+(@?\w+)\s+(\d+)$'))
@main_bot.on(events.NewMessage(pattern=r'^/cyclegap(?:@[\w_]+)?\s+(@?\w+)\s+(\d+)$'))
async def cmd_cycleinterval(event):
    """ADMIN: /cycleinterval <user> <minutes>
    Sets that user's minimum gap after each cycle (never shortened by frequency).
    Accepts minutes 1–1440 (e.g. 10, 20, 30, 45)."""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        await event.respond("Cycle interval for others is admin-only. Use Intervals in the bot menu for yourself.")
        return
    raw_target = event.pattern_match.group(1)
    try:
        minutes = int(event.pattern_match.group(2))
    except Exception:
        await event.respond("Usage: /cycleinterval <user|@username> <minutes>\nExample: /cycleinterval @user 20")
        return
    if minutes < 1 or minutes > 1440:
        await event.respond("Minutes must be between 1 and 1440.")
        return
    target_id = await resolve_target_user_id(raw_target, event.client)
    if not target_id:
        await event.respond("❌ User not found. Use numeric id or @username.")
        return
    sec = minutes * 60
    await db_call(uupdate, {'user_id': int(target_id)}, {'$set': {'cycle_interval_sec': sec}})
    await event.respond(
        f"⏱️ Cycle interval for <code>{target_id}</code> set to <b>{minutes} min</b> ({sec}s).\n"
        f"Frequency is only a <b>max</b> cycles/hour cap — it will not shorten this gap.",
        parse_mode='html',
    )


@main_bot.on(events.NewMessage(pattern=r'^/cycleinterval(?:@[\w_]+)?\s+(@?\w+)\s+(clear|default|reset)$'))
async def cmd_cycleinterval_clear(event):
    """ADMIN: /cycleinterval <user> clear — remove dedicated gap; fall back to preset/custom."""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    raw_target = event.pattern_match.group(1)
    target_id = await resolve_target_user_id(raw_target, event.client)
    if not target_id:
        await event.respond("❌ User not found.")
        return
    await db_call(uupdate, {'user_id': int(target_id)}, {'$unset': {'cycle_interval_sec': ''}})
    await event.respond(
        f"⏱️ Cycle interval override cleared for <code>{target_id}</code>. "
        f"Using their preset/custom interval again.",
        parse_mode='html',
    )


async def cmd_frequency(event):
    """ADMIN ONLY. Set a SPECIFIC user's per-group send frequency (times/hour),
    overriding the global default for that user's accounts only.
      /frequency 123456 5     -> that user's groups get ~5/hr
      /frequency @user 0      -> reset that user back to the global default
    Applies within ~1 round (no restart)."""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        await event.respond("Frequency is managed by admin.")
        return
    raw_target = event.pattern_match.group(1)
    val = int(event.pattern_match.group(2))
    if val != 0 and (val < 1 or val > HARD_MAX_TARGET_PER_HOUR):
        await event.respond(f"Usage: /frequency <userid|@username> <1-{HARD_MAX_TARGET_PER_HOUR}>  "
                            "(or 0 to reset to the global default)")
        return
    target_id = await resolve_target_user_id(raw_target, event.client)
    if not target_id:
        await event.respond("❌ User not found. Use a numeric id or @username.")
        return
    if val == 0:
        await db_call(uupdate, {'user_id': int(target_id)}, {'$unset': {'freq_per_hour': ''}})
        await event.respond(f"🎯 Frequency for <code>{target_id}</code> reset to the global default "
                            f"({get_effective_target_per_hour()}/hr).", parse_mode='html')
        return
    await db_call(uupdate, {'user_id': int(target_id)}, {'$set': {'freq_per_hour': val, 'freq_disabled': False}}, upsert=True)
    await event.respond(
        f"🎯 Frequency for <code>{target_id}</code> set to ~{val}/hour per group "
        "(this user only).\n\n<i>Applies to their accounts within ~1 round. "
        "Global default (/freq) is unchanged.</i>",
        parse_mode='html')


# /add command removed per user request (use dashboard Add Account button)

@main_bot.on(events.NewMessage(pattern=r'^/list(?:@[\w_]+)?(?:\s|$)'))
async def cmd_list(event):
    uid = event.sender_id

    if not await enforce_forcejoin_or_prompt(event):
        return

    if not await db_call(is_approved, uid):
        approve_user(uid)
    
    accounts = await db_call(get_user_accounts, uid)
    if not accounts:
        await event.respond("No accounts. Use /add")
        return
    
    tier = "Premium" if await db_call(is_premium, uid) else "No Plan"
    max_acc = await db_call(get_user_max_accounts, uid)
    
    text = f"**Your Accounts** ({tier})\n\n"
    for i, acc in enumerate(accounts, 1):
        status = "Active" if acc.get('is_forwarding') else "Inactive"
        text += f"{status} #{i} - {acc['phone']} ({acc.get('name', 'Unknown')})\n"
    text += f"\nUsing: {len(accounts)}/{max_acc}"
    
    await event.respond(text)

@main_bot.on(events.CallbackQuery)
async def callback(event):
    real_uid = event.sender_id
    if not _rate_allow_user(real_uid, 'cb', max_hits=40, window_sec=60):
        try:
            await event.answer("Slow down — try again in a moment.", alert=True)
        except Exception:
            pass
        return
    data = event.data.decode()

    # Answer immediately so Telegram UI never feels stuck while DB runs.
    try:
        await event.answer()
    except Exception:
        pass

    # Ban check + admin flag always use REAL sender
    _is_adm = await db_call(is_admin, real_uid)
    if not _is_adm:
        user = await db_call(get_user, real_uid)
        if user and user.get('banned'):
            reason = user.get('ban_reason', 'No reason provided')
            try:
                await event.answer(
                    f"🚫 You are banned!\n\nReason: {reason}",
                    alert=True
                )
            except Exception:
                pass
            return

    if data == "stop_impersonate" or data.startswith("admin"):
        uid = real_uid
    else:
        uid = acting_uid(real_uid)

    # Fast UI acknowledgment for navigation buttons
    if (
        data == "enter_dashboard"
        or data == "my_profile"
        or (data.startswith("menu_") and data != "menu_refresh")
        or data.startswith("back_")
        or data.startswith("accpage_")
        or data in {
            "admin_panel",
            "admin_all_users",
            "admin_premium",
            "admin_banned_users",
            "admin_admins",
            "admin_users",
            "admin_manage_accounts",
            "admin_broadcast",
            "admin_grant_premium",
        }
        or data.startswith("admin_all_users_page_")
        or data.startswith("admin_user_detail_")
        or data.startswith("admin_user_detail_all_")
        or data.startswith("admin_user_accounts_")
        or data.startswith("banned_page_")
    ):
        try:
            await event.answer("Opening...", cache_time=0)
        except Exception:
            pass

    # Force-join gate for interactive UI (admin bypass).
    # Allow verify button itself.
    if data != "force_verify":
        if not await enforce_forcejoin_or_prompt(event, edit=True):
            return
    
    try:
        if data == "force_verify":
            # User claims they joined; re-validate.
            if await is_user_passed_forcejoin(uid):
                try:
                    await event.answer("Verified ✅", cache_time=0)
                except Exception:
                    pass
                # Delete the force-join message
                try:
                    await event.delete()
                except Exception:
                    pass

                # Approve new users so dashboard/access is unlocked
                if not await db_call(is_approved, uid):
                    await db_call(approve_user, uid)

                # Privacy gate after verify
                _vu = await db_call(get_user, uid)
                if not await db_call(is_admin, real_uid) and not (_vu or {}).get('privacy_accepted'):
                    try:
                        await main_bot.send_message(
                            uid,
                            render_privacy_policy_text(),
                            parse_mode='html',
                            buttons=privacy_policy_keyboard(),
                        )
                    except Exception as e:
                        print(f"[FORCE_JOIN] privacy prompt failed: {e}")
                    return

                # Open dashboard immediately after successful verification
                dashboard_text = await db_call(render_dashboard_text, uid)
                dashboard_buttons = main_dashboard_keyboard(uid, viewer_id=real_uid)
                welcome_image = MESSAGES.get('welcome_image', '')
                try:
                    if welcome_image:
                        await main_bot.send_file(
                            uid,
                            welcome_image,
                            caption=dashboard_text,
                            parse_mode='html',
                            buttons=dashboard_buttons,
                        )
                    else:
                        await main_bot.send_message(
                            uid,
                            dashboard_text,
                            parse_mode='html',
                            buttons=dashboard_buttons,
                        )
                except Exception as e:
                    print(f"[FORCE_JOIN] Failed to open dashboard after verify for {uid}: {e}")
                    try:
                        await main_bot.send_message(
                            uid,
                            dashboard_text,
                            parse_mode='html',
                            buttons=dashboard_buttons,
                        )
                    except Exception as e2:
                        print(f"[FORCE_JOIN] Fallback dashboard send failed for {uid}: {e2}")
            else:
                await event.answer("Not joined yet. Please join the Channel, then tap Verify again.", alert=True)
            return
        
        # Stop button for Auto Group Join
        if data == "auto_join_cancel":
            auto_join_cancel[uid] = True
            await event.answer("⏸ Stopping join process...", alert=False)
            return
        
        if data == "accept_privacy":
            await db_call(
                uupdate,
                {'user_id': int(uid)},
                {'$set': {'privacy_accepted': True, 'privacy_accepted_at': datetime.now()}},
                upsert=True,
            )
            if not await db_call(is_approved, uid):
                await db_call(approve_user, uid)

            dashboard_text = await db_call(render_dashboard_text, uid)
            dashboard_buttons = main_dashboard_keyboard(uid, viewer_id=real_uid)
            welcome_image = MESSAGES.get('welcome_image', '')
            try:
                await event.delete()
            except Exception:
                pass
            try:
                if welcome_image:
                    await main_bot.send_file(
                        uid, welcome_image, caption=dashboard_text,
                        parse_mode='html', buttons=dashboard_buttons,
                    )
                else:
                    await main_bot.send_message(
                        uid, dashboard_text, parse_mode='html', buttons=dashboard_buttons,
                    )
            except Exception as e:
                print(f"[PRIVACY] dashboard open failed: {e}")
                await main_bot.send_message(
                    uid, dashboard_text, parse_mode='html', buttons=dashboard_buttons,
                )

            try:
                u2 = await db_call(get_user, uid)
                if u2 and not u2.get('onboarding_sent'):
                    guide = (
                        "<b>👋 Quick start</b>\n\n"
                        "1. <b>Accounts</b> — add the Telegram account that will send ads\n"
                        "2. Put your ad in that account's <b>Saved Messages</b> (or set Ads Mode)\n"
                        "3. Join / add <b>groups</b> (or topics if on a paid plan)\n"
                        "4. Open <b>Start / Manage Ads</b> → <b>Start Ads</b>\n\n"
                        "<b>Useful:</b>\n"
                        "• <b>Timing</b> — speed between groups & rest between rounds\n"
                        "• <b>Where to Send</b> — groups, topics, or both\n"
                        "• <b>Plans & Pricing</b> — unlock more accounts & features\n\n"
                        "<i>Need help? Use Support from the menu.</i>"
                    )
                    await main_bot.send_message(uid, guide, parse_mode='html')
                    await db_call(uupdate, {'user_id': int(uid)}, {'$set': {'onboarding_sent': True}}, upsert=True)
            except Exception as _ob:
                print(f"[PRIVACY] onboarding skipped: {_ob}")
            return

        if data.startswith("plan_"):
            plan_name = data.replace("plan_", "")
            
            plan = PLANS.get(plan_name)
            if not plan:
                await event.answer("Invalid plan!", alert=True)
                return
            if plan_name == "scout":
                await event.answer("This plan is no longer available.", alert=True)
                user = await db_call(get_user, uid)
                await _safe_cb_edit(event, render_plan_select_text(),
                                   buttons=plan_select_keyboard(uid, user=user))
                return
            
            # Show plan details with tagline + Buy Now button
            detail_text = f"<b>{plan['emoji']} {plan['name']} Plan</b>\n"
            detail_text += f"<i>{plan['tagline']}</i>\n\n"
            detail_text += "<b>Includes:</b>\n"
            detail_text += f"• Accounts: <code>{plan['max_accounts']}</code>\n"
            detail_text += f"• Topics: <code>{plan['max_topics']}</code>\n"
            detail_text += f"• Groups per topic: <code>{plan['max_groups_per_topic']}</code>\n"
            detail_text += f"• Auto groups cap: <code>{plan.get('max_auto_groups', 'Unlimited')}</code>\n"
            detail_text += "• Delays: <code>Custom message & cycle delays</code>\n"
            detail_text += f"• Auto reply: <code>{'Yes' if plan['auto_reply_enabled'] else 'No'}</code>\n"
            detail_text += f"• Logs: <code>{'Yes' if plan['logs_enabled'] else 'No'}</code>\n\n"
            
            user = await db_call(get_user, uid)
            user_plan_key = normalize_plan_key(user.get('plan') or user.get('plan_name'))
            is_active_plan = (user_plan_key == plan_name) and await db_call(is_premium, uid)
            
            detail_text += f"<b>Price: {plan['price_display']}</b>"
            
            if is_active_plan:
                buttons = [
                    [Button.inline("Plan Active", b"enter_dashboard")],
                    [Button.inline("← Back to Plans", b"back_plans")]
                ]
            else:
                buttons = [
                    [Button.inline(f"Buy {plan['name']} - {plan['price_display']}", f"buy_{plan_name}")],
                    [Button.inline("← Back to Plans", b"back_plans")]
                ]
            
            # Same as older working build
            plan_image = PLAN_IMAGES.get(plan_name)
            if plan_image and plan_name in ['grow', 'prime', 'dominion']:
                await event.edit(file=plan_image, text=detail_text, parse_mode='html', buttons=buttons)
            else:
                await event.edit(detail_text, parse_mode='html', buttons=buttons)
            return
        
        if data == "activate_scout":
            await event.answer("This plan is no longer available.", alert=True)
            user = await db_call(get_user, uid)
            await _safe_cb_edit(event, render_plan_select_text(),
                               buttons=plan_select_keyboard(uid, user=user))
            return
        
        # ===================== Manual UPI Payment Callbacks =====================
        
        if data.startswith("paydone_"):
            # User clicked "Payment Done" - ask for payment screenshot
            parts = data.split("_", 1)
            if len(parts) < 2:
                await event.answer("Invalid payment request", alert=True)
                return

            request_id = parts[1]
            pay_req = pending_upi_payments.get(request_id)
            if not pay_req:
                await event.answer("Payment request expired or not found. Open Plans and buy again.", alert=True)
                return

            pay_req['status'] = 'awaiting_screenshot'
            _put_flow_state(real_uid, uid, {'state': 'awaiting_payment_screenshot', 'request_id': request_id})

            await event.edit(
                "<b>📸 Send Payment Screenshot</b>\n\n"
                f"<b>Plan:</b> {pay_req.get('plan_name', pay_req.get('plan_key', ''))}\n"
                f"<b>Amount:</b> ₹{pay_req.get('price', '')}\n\n"
                "<blockquote>Send a <b>photo</b> of your UPI payment confirmation now.</blockquote>\n"
                "<i>Do not send text only — a screenshot image is required.</i>",
                parse_mode='html',
                buttons=[[Button.inline("← Back to Plans", b"back_plans")]],
            )
            return

        if data.startswith("payapprove_"):
            if not await db_call(is_admin, real_uid):
                await event.answer("Admins only", alert=True)
                return
            request_id = data.replace("payapprove_", "", 1)
            pay_req = pending_upi_payments.get(request_id)
            if not pay_req:
                await event.answer("Request expired or already handled", alert=True)
                return
            target_id = int(pay_req["user_id"])
            plan_key = pay_req.get("plan_key") or "grow"
            try:
                expires_at = await grant_premium_to_user(target_id, plan_key, 30, source="upi_approve")
                pending_upi_payments.pop(request_id, None)
                try:
                    await event.edit(
                        f"<b>✅ Payment Approved</b>\n\n"
                        f"User <code>{target_id}</code> granted <b>{pay_req.get('plan_name', plan_key)}</b> "
                        f"until <code>{expires_at.strftime('%d %b %Y')}</code>.",
                        parse_mode="html",
                    )
                except Exception:
                    await event.answer("Approved", alert=True)
            except Exception as e:
                print(f"[PAYMENT] approve failed: {e}")
                await event.answer(f"Approve failed: {str(e)[:80]}", alert=True)
            return

        if data.startswith("payreject_"):
            if not await db_call(is_admin, real_uid):
                await event.answer("Admins only", alert=True)
                return
            request_id = data.replace("payreject_", "", 1)
            pay_req = pending_upi_payments.pop(request_id, None)
            if not pay_req:
                await event.answer("Request expired or already handled", alert=True)
                return
            target_id = int(pay_req["user_id"])
            try:
                await event.edit(
                    f"<b>❌ Payment Rejected</b>\n\nUser <code>{target_id}</code> — "
                    f"{pay_req.get('plan_name', pay_req.get('plan_key', ''))}.",
                    parse_mode="html",
                )
            except Exception:
                await event.answer("Rejected", alert=True)
            try:
                await main_bot.send_message(
                    target_id,
                    "<b>Payment not verified</b>\n\n"
                    "Your screenshot was rejected. If you paid, contact support with the UTR / screenshot.",
                    parse_mode="html",
                    buttons=[[Button.inline("View Plans", b"back_plans")]],
                )
            except Exception as e:
                print(f"[PAYMENT] reject notify failed: {e}")
            return

        if data == "logs_enable_global":
            # Enable logs globally for user (applies to all accounts)
            await db_call(uupdate, {'user_id': int(uid)}, {'$set': {'logs_chat_id': int(uid)}}, upsert=True)
            invalidate_logs_cache()
            await event.answer("Logs enabled", alert=True)
            await event.edit(
                "<b>✅ Logs Enabled</b>\n\n<blockquote>Logs will now be sent for <b>all</b> your added accounts.</blockquote>",
                parse_mode='html',
                buttons=[[Button.inline("Back", b"menu_logs")]]
            )
            return

        if data == "logs_disable_global":
            await db_call(uupdate, {'user_id': int(uid)}, {'$unset': {'logs_chat_id': ""}})
            invalidate_logs_cache()
            await event.answer("Logs disabled", alert=True)
            await event.edit(
                "<b>❌ Logs Disabled</b>\n\n<i>You will no longer receive logs.</i>",
                parse_mode='html',
                buttons=[[Button.inline("Back", b"menu_logs")]]
            )
            return

        if data == "menu_fwd_mode":
            user = await db_call(get_user, uid)
            current = user.get('forwarding_mode', 'auto')  # Free users default to Groups Only
            user_is_premium = await db_call(is_premium, uid)
            
            modes = {
                'topics': 'Forward to Topics Only',
                'auto': 'Forward to Groups Only',
                'both': 'Forward to Both (Topics first, then Groups)'
            }
            
            text = (
                "<b>🔄 Mode</b>\n\n"
                "Select how ads should be forwarded."
            )
            
            if not user_is_premium:
                text += "\n\n<i>Non-premium accounts can forward to groups only. Upgrade for more options.</i>"
            
            buttons = []
            for mode, label in modes.items():
                mark = " ✅" if mode == current else ""
                
                # Lock topics and both for free users
                if not user_is_premium and mode in ['topics', 'both']:
                    buttons.append([Button.inline(f"{label} 🔒", b"locked_fwd_mode")])
                else:
                    buttons.append([Button.inline(f"{label}{mark}", f"set_fwd_mode_{mode}")])
            
            buttons.append([Button.inline("← Back", b"menu_broadcast")])
            
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        
        if data.startswith("set_fwd_mode_"):
            mode = data.replace("set_fwd_mode_", "")
            await db_call(uupdate, {'user_id': uid}, {'$set': {'forwarding_mode': mode}})
            modes = {
                'topics': 'Forward to Topics Only',
                'auto': 'Forward to Groups Only',
                'both': 'Forward to Both (Topics first, then Groups)'
            }
            await event.answer(f"Mode set: {modes.get(mode, mode)}", alert=True)
            
            text = (
                "<b>🔄 Mode</b>\n\n"
                "Select how ads should be forwarded."
            )
            
            buttons = []
            for m, label in modes.items():
                mark = " ✅" if m == mode else ""
                buttons.append([Button.inline(f"{label}{mark}", f"set_fwd_mode_{m}")])
            buttons.append([Button.inline("← Back", b"menu_broadcast")])
            
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        
        if data == "menu_refresh":
            accounts = await db_call(get_user_accounts, uid)
            total_groups = 0
            for acc in accounts:
                try:
                    session = cipher_suite.decrypt(acc['session'].encode()).decode()
                    client = TelegramClient(StringSession(session), CONFIG['api_id'], CONFIG['api_hash'])
                    await client.connect()
                    count = await fetch_groups_for_account(client, acc['_id'])
                    total_groups += count
                    await client.disconnect()
                except Exception:
                    pass
            await event.answer(f"Refreshed! Found {total_groups} groups.", alert=True)
            
            text = await db_call(render_dashboard_text, uid)
            buttons = main_dashboard_keyboard(uid, viewer_id=real_uid)
            # Admin button removed (already in main_dashboard_keyboard)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        
        if data == "adsye_now":
            try:
                dashboard_text = await db_call(render_dashboard_text, uid)
                dashboard_buttons = main_dashboard_keyboard(uid, viewer_id=real_uid)
                await _safe_cb_edit(event, dashboard_text, buttons=dashboard_buttons)
            except Exception as e:
                print(f"[UI] adsye_now failed: {e}")
                user = await db_call(get_user, uid)
                await _safe_cb_edit(
                    event,
                    render_plan_select_text(),
                    buttons=plan_select_keyboard(uid, user=user),
                )
            return

        if data == "enter_dashboard":
            # Force-join gate (extra safety)
            if not await enforce_forcejoin_or_prompt(event, edit=True):
                return

            if not await db_call(is_approved, uid):
                approve_user(uid)

            # Privacy gate
            _u = await db_call(get_user, uid)
            if not await db_call(is_admin, real_uid) and not (_u or {}).get('privacy_accepted'):
                await event.edit(
                    render_privacy_policy_text(),
                    parse_mode='html',
                    buttons=privacy_policy_keyboard(),
                )
                return

            # Text + buttons only on Home (no re-upload of welcome image — that lags).
            # Welcome image stays on /start and first privacy accept only.
            text = await db_call(render_dashboard_text, uid)
            buttons = main_dashboard_keyboard(uid, viewer_id=real_uid)
            try:
                await event.edit(text, parse_mode='html', buttons=buttons)
            except Exception:
                try:
                    await event.respond(text, parse_mode='html', buttons=buttons)
                except Exception:
                    pass

            try:
                task = _spawn_bg(apply_account_profile_templates(uid))
                task.add_done_callback(lambda t: t.exception())
            except Exception:
                pass
            return
        
        if data == "menu_status":
            user = await db_call(get_user, uid)
            try:
                check = await db_call(render_ready_checklist, uid)
            except Exception:
                check = "—"
            plan = get_display_plan_name(user)
            text_s = (
                "<b>ℹ️ Bot Status</b>\n\n"
                f"<b>Plan:</b> <code>{plan}</code>\n"
                f"<b>Your setup</b>\n{check}\n\n"
                "<b>Notes</b>\n"
                "• We do not promote spam or abuse\n"
                "• Account limits/bans are outside our control\n"
                "• Use Timing gaps to stay safer\n"
                "• Support: use the Support link from Plans / welcome"
            )
            await event.edit(
                text_s,
                parse_mode='html',
                buttons=[
                    [Button.inline("📖 Guide", b"menu_guide")],
                    [Button.inline("🏠 Home", b"enter_dashboard")],
                ],
            )
            return

        if data == "menu_guide":
            await event.edit(
                render_user_guide_text(),
                parse_mode='html',
                buttons=[
                    [Button.inline("📢 Start / Manage Ads", b"menu_broadcast")],
                    [Button.inline("📱 Accounts", b"menu_account")],
                    [Button.inline("🏠 Home", b"enter_dashboard")],
                ],
            )
            return

        if data == "menu_broadcast":
            text = (
                "<b>📢 Ads Control</b>\n\n"
                "Start or stop sending from your accounts.\n\n"
                "• <b>Start / Stop Ads</b> — run or pause\n"
                "• <b>Timing</b> — delay between groups & rest between rounds\n"
                "• <b>Where to Send</b> — groups, topics, or both\n"
                "• <b>Settings</b> — automation, auto-reply, logs, ads mode\n"
                "• <b>Stats</b> — sent / failed overview"
            )
            await event.edit(text, parse_mode='html', buttons=await db_call(broadcast_menu_keyboard, uid))
            return
        
        if data == "menu_account":
            # Clear any pending account adding state when returning to account menu
            if uid in user_states:
                del user_states[uid]
            
            accounts = await db_call(get_user_accounts, uid)
            max_acc = await db_call(get_user_max_accounts, uid)
            text = (
                f"<b>📱 Account Management</b>\n\n"
                f"<b>Accounts:</b> <code>{len(accounts)}/{max_acc}</code>\n\n"
                f"<i>Select an account below or add a new one.</i>"
            )
            await event.edit(text, parse_mode='html', buttons=await db_call(account_list_keyboard, uid))
            return
        
        if data.startswith("accpage_"):
            page = int(data.split("_")[1])
            accounts = await db_call(get_user_accounts, uid)
            max_acc = await db_call(get_user_max_accounts, uid)
            text = (
                f"<b>👤 Account Management</b>\n\n"
                f"<b>Accounts:</b> <code>{len(accounts)}/{max_acc}</code>\n\n"
                f"<i>Page:</i> <code>{page+1}</code>"
            )
            await event.edit(text, parse_mode='html', buttons=await db_call(account_list_keyboard, uid, page))
            return
        
        if data == "add_account":
            accounts = await db_call(get_user_accounts, uid)
            max_accounts = await db_call(get_user_max_accounts, uid)
            if max_accounts <= 0:
                plan_msg = render_plan_select_text()
                await event.edit(plan_msg, parse_mode='html', buttons=plan_select_keyboard(uid))
                return
            if len(accounts) >= max_accounts:
                await event.answer(f"Account limit reached ({max_accounts})!", alert=True)
                return
            _put_flow_state(real_uid, uid, {'action': 'phone', 'owner_id': uid})
            await event.edit("**Add Account**\n\nSend phone number with country code:\n\nExample: `+919876543210`", buttons=[[Button.inline("Cancel", b"menu_account")]])
            return
        
        if data == "delete_account_menu":
            accounts = await db_call(get_user_accounts, uid)
            if not accounts:
                await event.answer("No accounts to delete!", alert=True)
                return
            await event.edit("**Delete Account**\n\nSelect account to delete:", buttons=await db_call(delete_account_list_keyboard, uid))
            return
        
        if data.startswith("confirm_del_"):
            acc_id = data.replace("confirm_del_", "")
            from bson.objectid import ObjectId
            # NOTE: accounts are keyed by 'owner_id' (not 'user_id'). The old query
            # used 'user_id' and always matched nothing -> deletion silently failed.
            try:
                acc = await db_call(accounts_col.find_one, {'_id': ObjectId(acc_id), 'owner_id': uid})
            except Exception:
                acc = None
            if not acc:
                acc = await db_call(accounts_col.find_one, {'_id': acc_id, 'owner_id': uid})
            if acc:
                phone = acc['phone']
                await event.edit(
                    f"**Confirm Delete**\n\nAre you sure you want to delete account:\n`{phone}`?",
                    buttons=[
                        [Button.inline("Yes, Delete", f"final_del_{acc_id}"), Button.inline("No, Cancel", b"delete_account_menu")]
                    ]
                )
            else:
                await event.answer("Account not found!", alert=True)
            return
        
        if data.startswith("final_del_"):
            acc_id = data.replace("final_del_", "")
            from bson.objectid import ObjectId
            try:
                acc = await db_call(accounts_col.find_one, {'_id': ObjectId(acc_id), 'owner_id': uid})
            except Exception:
                acc = None
            if not acc:
                acc = await db_call(accounts_col.find_one, {'_id': acc_id, 'owner_id': uid})
            if acc:
                # Full cleanup: cancels the forwarding task, disconnects the auto-reply
                # client, and removes every related collection (no orphaned data).
                await delete_account_and_related(acc['_id'])
                await event.answer("Account deleted!", alert=True)
            else:
                await event.answer("Account not found!", alert=True)
            await event.edit(
                "<b>👤 Account Management</b>",
                parse_mode='html',
                buttons=await db_call(account_list_keyboard, uid)
            )
            return
        
        if data == "menu_analytics":
            accounts = await db_call(get_user_accounts, uid)
            total_sent = 0
            total_failed = 0
            total_groups = 0
            total_auto_replies = 0
            
            _ids = [str(acc['_id']) for acc in accounts]
            if _ids:
                _sd = await db_call(lambda: list(account_stats_col.find(
                    {'account_id': {'$in': _ids}}, {'total_sent': 1, 'total_failed': 1, 'auto_replies': 1})))
                total_sent = sum(s.get('total_sent', 0) for s in _sd)
                total_failed = sum(s.get('total_failed', 0) for s in _sd)
                total_auto_replies = sum(s.get('auto_replies', 0) for s in _sd)
                total_groups = await db_call(lambda: account_auto_groups_col.count_documents({'account_id': {'$in': _ids}}))
            
            active = sum(1 for acc in accounts if acc.get('is_forwarding'))
            
            success_rate = 0.0
            if (total_sent + total_failed) > 0:
                success_rate = (total_sent / (total_sent + total_failed)) * 100

            text = (
                "<b>📊 Analytics</b>\n\n"
                "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
                "<b>👥 Account Statistics:</b>\n"
                f"├ <b>Total Accounts:</b> <code>{len(accounts)}</code>\n"
                f"├ <b>Active Accounts:</b> <code>{active}</code>\n"
                f"└ <b>Total Groups:</b> <code>{total_groups}</code>\n\n"
                "<b>📈 Message Statistics:</b>\n"
                f"├ <b>✅ Messages Sent:</b> <code>{total_sent}</code>\n"
                f"├ <b>❌ Messages Failed:</b> <code>{total_failed}</code>\n"
                f"├ <b>📊 Success Rate:</b> <code>{success_rate:.1f}%</code>\n"
                f"└ <b>💬 Auto Replies:</b> <code>{total_auto_replies}</code>\n\n"
                "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
            )

            await event.edit(text, parse_mode='html', buttons=[[Button.inline("← Back", b"menu_broadcast")]])
            return
        
        if data == "my_profile":
            user = await db_call(get_user, uid)
            
            # Check if user is admin for special display
            if await db_call(is_admin, uid):
                # Admin/God Mode Display
                accounts = await db_call(get_user_accounts, uid)
                active_accounts = sum(1 for acc in accounts if acc.get('is_forwarding'))
                _ids = [str(acc['_id']) for acc in accounts]
                total_groups = await db_call(lambda: account_auto_groups_col.count_documents(
                    {'account_id': {'$in': _ids}})) if _ids else 0
                _statd = await db_call(lambda: list(account_stats_col.find(
                    {'account_id': {'$in': _ids}}, {'total_sent': 1}))) if _ids else []
                total_messages = sum(s.get('total_sent', 0) for s in _statd)
                
                # Get current settings
                interval_preset = user.get('interval_preset', 'medium')
                cycle_sec = get_cycle_interval_sec(user)
                if user.get('msg_delay_sec'):
                    interval_str = f"Custom msg ({int(user['msg_delay_sec'])}s / {cycle_sec}s cycle)"
                elif interval_preset == 'custom':
                    custom = user.get('custom_interval', {})
                    interval_str = f"Custom ({custom.get('msg_delay', 30)}s / {cycle_sec}s cycle)"
                else:
                    preset_info = INTERVAL_PRESETS.get(interval_preset, INTERVAL_PRESETS['medium'])
                    preset_name = interval_preset.capitalize()
                    interval_str = f"{preset_name} ({preset_info['msg_delay']}s msg / {cycle_sec}s cycle)"
                
                # Get actual feature status from user settings (not hardcoded for admins)
                auto_reply = "✅ Enabled" if user.get('autoreply_enabled') else "❌ Disabled"
                smart_rotation = "✅ Enabled" if user.get('smart_rotation', True) else "❌ Disabled"
                # Logs are enabled if logs_chat_id is set
                logs = "✅ Enabled" if user.get('logs_chat_id') else "❌ Disabled"
                
                try:
                    username = f"@{event.sender.username}" if event.sender.username else "Not set"
                except:
                    username = "Not set"
                
                text = (
                    f"<b>👤 My Profile</b>\n\n"
                    f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
                    f"<b>📱 User Details:</b>\n"
                    f"├ <b>User ID:</b> <code>{uid}</code>\n"
                    f"├ <b>Username:</b> <code>{username}</code>\n"
                    f"└ <b>Plan:</b> ⚡ <b>God Mode</b>\n\n"
                    f"<b>💎 Subscription:</b>\n"
                    f"├ <b>Expires On:</b> <code>∞ Never</code>\n"
                    f"└ <b>Days Left:</b> <code>∞ Unlimited</code>\n\n"
                    f"<b>📊 Usage Statistics:</b>\n"
                    f"├ <b>Total Accounts:</b> <code>{len(accounts)}/999</code>\n"
                    f"├ <b>Active Accounts:</b> <code>{active_accounts}</code>\n"
                    f"├ <b>Total Groups:</b> <code>{total_groups}</code>\n"
                    f"└ <b>Total Messages Sent:</b> <code>{total_messages}</code>\n\n"
                    f"<b>⚙️ Current Settings:</b>\n"
                    f"├ <b>Interval:</b> <code>{interval_str}</code>\n"
                    f"├ <b>Auto Reply:</b> {auto_reply}\n"
                    f"├ <b>Smart Rotation:</b> {smart_rotation}\n"
                    f"└ <b>Logs:</b> {logs}\n\n"
                    f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
                )
            else:
                # Regular User Display
                # Check if user still has active premium
                user_is_premium = await db_call(is_premium, uid)
                
                if user_is_premium:
                    # User has active premium - show their plan
                    plan_key = normalize_plan_key(user.get('plan') or user.get('plan_name')) or 'grow'
                    plan = PLANS.get(plan_key, PLANS['grow'])
                    plan_display = f"{plan['emoji']} <b>{plan['name']}</b>"
                else:
                    # Premium expired or revoked - reset to no plan
                    plan = PLAN_SCOUT
                    plan_display = "<b>No Plan</b>"
                
                # Calculate expiry and days remaining
                expiry_date = user.get('plan_expiry')
                if expiry_date and user_is_premium:
                    days_remaining = (expiry_date - datetime.now()).days
                    expiry_str = expiry_date.strftime('%d %b %Y')
                    days_str = f"{days_remaining} days" if days_remaining > 0 else "Expired"
                else:
                    expiry_str = "—"
                    days_str = "—"
                
                # Get usage statistics
                accounts = await db_call(get_user_accounts, uid)
                active_accounts = sum(1 for acc in accounts if acc.get('is_forwarding'))
                total_groups = 0
                total_messages = 0
                
                _ids = [str(acc['_id']) for acc in accounts]
                if _ids:
                    total_groups = await db_call(lambda: account_auto_groups_col.count_documents({'account_id': {'$in': _ids}}))
                    total_messages = await db_call(bulk_total_sent, accounts)
                
                # Get current settings
                interval_preset = user.get('interval_preset', 'medium')
                cycle_sec = get_cycle_interval_sec(user)
                if user.get('msg_delay_sec'):
                    interval_str = f"Custom msg ({int(user['msg_delay_sec'])}s / {cycle_sec}s cycle)"
                elif interval_preset == 'custom':
                    custom = user.get('custom_interval', {})
                    interval_str = f"Custom ({custom.get('msg_delay', 30)}s / {cycle_sec}s cycle)"
                else:
                    preset_info = INTERVAL_PRESETS.get(interval_preset, INTERVAL_PRESETS['medium'])
                    preset_name = interval_preset.capitalize()
                    interval_str = f"{preset_name} ({preset_info['msg_delay']}s msg / {cycle_sec}s cycle)"
                
                # Fix: Check actual user settings, not just premium status
                auto_reply = "✅ Enabled" if user.get('autoreply_enabled') else "❌ Disabled"
                smart_rotation = "✅ Enabled" if user.get('smart_rotation', True) else "❌ Disabled"
                # Logs are enabled if logs_chat_id is set
                logs = "✅ Enabled" if user.get('logs_chat_id') else "❌ Disabled"
                
                # Get username
                try:
                    username = f"@{event.sender.username}" if event.sender.username else "Not set"
                except:
                    username = "Not set"
                
                text = (
                    f"<b>👤 My Profile</b>\n\n"
                    f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
                    f"<b>📱 User Details:</b>\n"
                    f"├ <b>User ID:</b> <code>{uid}</code>\n"
                    f"├ <b>Username:</b> <code>{username}</code>\n"
                    f"└ <b>Plan:</b> {plan_display}\n\n"
                    f"<b>💎 Subscription:</b>\n"
                    f"├ <b>Expires On:</b> <code>{expiry_str}</code>\n"
                    f"└ <b>Days Left:</b> <code>{days_str}</code>\n\n"
                    f"<b>📊 Usage Statistics:</b>\n"
                    f"├ <b>Total Accounts:</b> <code>{len(accounts)}/{plan['max_accounts']}</code>\n"
                    f"├ <b>Active Accounts:</b> <code>{active_accounts}</code>\n"
                    f"├ <b>Total Groups:</b> <code>{total_groups}</code>\n"
                    f"└ <b>Total Messages Sent:</b> <code>{total_messages}</code>\n\n"
                    f"<b>⚙️ Current Settings:</b>\n"
                    f"├ <b>Interval:</b> <code>{interval_str}</code>\n"
                    f"├ <b>Auto Reply:</b> {auto_reply}\n"
                    f"├ <b>Smart Rotation:</b> {smart_rotation}\n"
                    f"└ <b>Logs:</b> {logs}\n\n"
                    f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
                )
            
            await event.edit(text, parse_mode='html', buttons=[[Button.inline("← Back to Dashboard", b"enter_dashboard")]])
            return
        
        if data == "menu_interval":
            user = await db_call(get_user, uid)
            text = render_interval_settings_text(user)
            await event.edit(text, parse_mode='html', buttons=interval_menu_keyboard(uid, viewer_id=real_uid))
            return

        if data.startswith("interval_") and data not in ("interval_locked", "interval_custom", "interval_msg_custom", "interval_freq"):
            # Slow / Medium / Fast = MSG GAP only (never changes cycle gap)
            preset_key = data.replace("interval_", "")
            if preset_key in INTERVAL_PRESETS:
                await db_call(
                    uupdate,
                    {'user_id': uid},
                    {
                        '$set': {'interval_preset': preset_key},
                        '$unset': {'custom_interval': '', 'msg_delay_sec': ''},
                    },
                )
                preset_name = {'slow':'Slow','medium':'Normal','fast':'Fast'}.get(preset_key, preset_key.capitalize())
                msg_d = INTERVAL_PRESETS[preset_key]['msg_delay']
                try:
                    await event.answer(f"Msg gap: {preset_name} ({msg_d}s). Cycle gap unchanged.", alert=True)
                except Exception:
                    pass
                user = await db_call(get_user, uid)
                text = render_interval_settings_text(user)
                await event.edit(text, parse_mode='html', buttons=interval_menu_keyboard(uid, viewer_id=real_uid))
            return

        if data == "interval_msg_custom":
            _put_flow_state(real_uid, uid, {'action': 'custom_msg_delay'})
            await event.edit(
                "<b>Custom message delay</b>" + chr(10)*2
                + f"Enter delay between groups in seconds ({MIN_MSG_DELAY}-9999)." + chr(10)
                + "This only changes msg gap — cycle gap stays as set with 10/20/30/Custom cycle.",
                parse_mode='html',
                buttons=[[Button.inline("Back", b"menu_interval")]],
            )
            return

        if data == "interval_locked":
            # Free plan users trying to access custom intervals
            text = (
                "<b>Paid Plan Feature</b>\n\n"
                "Custom intervals are available on paid plans only.\n"
                "Upgrade to Starter, Pro, or Elite to unlock custom timing."
            )
            await event.edit(text, parse_mode='html', buttons=[
                [Button.inline("💎 View Plans", b"back_plans")],
                [Button.inline("← Back", b"menu_interval")]
            ])
            return
        
        if data == "interval_custom":
            if not await db_call(is_premium, uid):
                await event.answer("Paid plan only!", alert=True)
                return
            _put_flow_state(real_uid, uid, {'action': 'custom_interval', 'step': 'msg_delay'})
            await event.edit(
                "⏱️ Custom Interval\n\nEnter message delay in seconds (5-9999):",
                buttons=[[Button.inline("← Back", b"menu_interval")]]
            )
            return

        if data == "interval_freq":
            if not await db_call(is_admin, real_uid):
                await event.answer("Frequency is managed by admin.", alert=True)
                return
            _put_flow_state(real_uid, real_uid, {'action': 'set_target_freq'})
            cur = get_effective_target_per_hour()
            await event.edit(
                f"<b>🎯 Global Frequency</b>\n\n"
                f"Max times per hour each group may receive a message.\n"
                f"Applies to <b>all users</b> (unless a user has a per-user /freq override).\n\n"
                f"<b>Current:</b> <code>{cur}/hr</code>\n"
                f"<b>Allowed:</b> <code>1–{HARD_MAX_TARGET_PER_HOUR}</code>\n\n"
                f"Send a number now.",
                parse_mode='html',
                buttons=[[Button.inline("← Back", b"admin_panel")]],
            )
            return

        if data == "toggle_live_logs":
            if not await db_call(is_admin, real_uid):
                await event.answer("Admins only.", alert=True)
                return
            # Default from env when never set; otherwise flip stored value
            cur = bool(get_global_setting('live_send_logs', LIVE_SEND_LOGS))
            new_val = not cur
            set_global_setting('live_send_logs', new_val)
            # Force short-cache refresh for this process
            try:
                _global_settings_cache.pop('live_send_logs', None)
            except Exception:
                pass
            await event.answer(
                f"Live logs {'ON' if new_val else 'OFF'} — applies on the next group send.",
                alert=True,
            )
            # Refresh admin panel if possible, else interval menu
            try:
                await event.edit(
                    f"<b>📝 Live Send Logs</b>\n\n"
                    f"Status: <b>{'ON ✅' if new_val else 'OFF'}</b>\n\n"
                    f"<i>When ON, each successful send can notify via the logger bot. "
                    f"Keep OFF at scale.</i>",
                    parse_mode='html',
                    buttons=[
                        [Button.inline(
                            f"📝 Live logs: {'ON' if new_val else 'OFF'}",
                            b"toggle_live_logs",
                        )],
                        [Button.inline("← Admin Panel", b"admin_panel")],
                    ],
                )
            except Exception:
                pass
            return

        if data in ("cycle_interval_600", "cycle_interval_1200", "cycle_interval_1800"):
            sec_map = {
                "cycle_interval_600": 600,
                "cycle_interval_1200": 1200,
                "cycle_interval_1800": 1800,
            }
            sec = int(sec_map[data])
            await db_call(uupdate,
                {'user_id': int(uid)},
                {'$set': {'cycle_interval_sec': sec}},
                upsert=True,
            )
            try:
                invalidate_user_cache(int(uid))
            except Exception:
                pass
            mins = sec // 60
            await event.answer(f"Cycle interval: {mins} min", alert=True)
            try:
                await event.edit(
                    f"<b>Cycle interval:</b> <code>{mins} min</code>",
                    parse_mode='html',
                    buttons=interval_menu_keyboard(uid),
                )
            except Exception:
                try:
                    await event.edit(
                        f"<b>Cycle interval:</b> <code>{mins} min</code>",
                        parse_mode='html',
                        buttons=[[Button.inline("← Interval menu", b"menu_interval")]],
                    )
                except Exception:
                    pass
            return

        if data == "cycle_interval_custom":
            _put_flow_state(real_uid, uid, {'action': 'cycle_interval_custom'})
            await event.edit(
                "⏱️ Custom cycle interval\n\nEnter minutes (1–1440):",
                buttons=[[Button.inline("← Back", b"menu_interval")]],
            )
            return

        if data == "menu_topics":
            accounts = await db_call(get_user_accounts, uid)
            if not accounts:
                await event.answer("Add an account first!", alert=True)
                return
            
            tier_settings = await db_call(get_user_tier_settings, uid)
            max_topics = tier_settings.get('max_topics', 3)
            
            text = (
                "<b>🏷️ Topics</b>\n\n"
                "<blockquote>Select a topic to add group links.</blockquote>\n\n"
                f"<b>Available topics:</b> <code>{max_topics}/{len(TOPICS)}</code>"
            )
            if not await db_call(is_premium, uid):
                text += "\n\n<i>Upgrade to a paid plan for all topics.</i>"
            
            buttons = []
            _topic_list = list(TOPICS[:max_topics])
            _acc_ids = [acc['_id'] for acc in accounts]
            _topic_counts = {}
            if _acc_ids:
                _agg = await db_call(lambda: list(account_topics_col.aggregate([
                    {'$match': {'account_id': {'$in': _acc_ids}, 'topic': {'$in': _topic_list}}},
                    {'$group': {'_id': '$topic', 'n': {'$sum': 1}}},
                ])))
                _topic_counts = {d['_id']: d['n'] for d in _agg}
            for i, topic in enumerate(_topic_list):
                count = _topic_counts.get(topic, 0)
                buttons.append([Button.inline(f"{topic.title()} ({count} groups)", f"topic_select_{topic}")])
            
            if not await db_call(is_premium, uid) and len(TOPICS) > max_topics:
                buttons.append([Button.inline("Unlock More Topics", b"go_premium")])
            
            buttons.append([Button.inline("Back", b"menu_settings_content")])
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        
        if data.startswith("topic_select_"):
            topic = data.replace("topic_select_", "")
            accounts = await db_call(get_user_accounts, uid)
            
            tier_settings = await db_call(get_user_tier_settings, uid)
            max_groups = tier_settings.get('max_groups_per_topic', 10)
            
            if len(accounts) == 1:
                acc = accounts[0]
                groups = await db_call(lambda: list(account_topics_col.find({'account_id': acc['_id'], 'topic': topic})))
                
                text = (
                    f"<b>{_h(topic.title())}</b>\n\n"
                    f"<b>Groups:</b> <code>{len(groups)}/{max_groups}</code>\n\n"
                    "<b>Send topic link to add:</b>\n"
                    "<code>https://t.me/groupname/5</code>"
                )
                buttons = [[Button.inline("View Groups", f"view_topic_groups_{topic}_{acc['_id']}")]] if groups else []
                buttons.append([Button.inline("Back", b"menu_topics")])
                msg = await event.edit(text, parse_mode='html', buttons=buttons)
                _put_flow_state(real_uid, uid, {'action': 'add_topic_link', 'topic': topic, 'account_id': acc['_id'], 'last_msg_id': msg.id if hasattr(msg, 'id') else event.message_id})
            else:
                text = f"<b>{_h(topic.title())}</b>\n\n<i>Select account to add groups:</i>"
                buttons = []
                _aids = [acc['_id'] for acc in accounts]
                _agg = await db_call(lambda: list(account_topics_col.aggregate([
                    {'$match': {'account_id': {'$in': _aids}, 'topic': topic}},
                    {'$group': {'_id': '$account_id', 'n': {'$sum': 1}}},
                ]))) if _aids else []
                _cba = {str(d['_id']): d['n'] for d in _agg}
                for acc in accounts:
                    phone = acc['phone'][-4:]
                    name = acc.get('name', 'Unknown')[:12]
                    count = _cba.get(str(acc['_id']), 0)
                    buttons.append([Button.inline(f"{phone} - {name} ({count})", f"topic_acc_{topic}_{acc['_id']}")])
                buttons.append([Button.inline("Back", b"menu_topics")])
                await event.edit(text, parse_mode='html', buttons=buttons)
            return
        
        if data.startswith("topic_acc_"):
            parts = data.replace("topic_acc_", "").split("_", 1)
            topic = parts[0]
            acc_id = parts[1] if len(parts) > 1 else ""
            
            tier_settings = await db_call(get_user_tier_settings, uid)
            max_groups = tier_settings.get('max_groups_per_topic', 10)
            groups = await db_call(lambda: list(account_topics_col.find({'account_id': acc_id, 'topic': topic})))
            
            text = (
                f"<b>🏷️ {topic.title()}</b>\n\n"
                f"<b>Groups:</b> <code>{len(groups)}/{max_groups}</code>\n\n"
                "<i>Send a topic link to add.</i>\n"
                "<code>Example: https://t.me/groupname/5</code>"
            )
            buttons = [[Button.inline("👁️ View Groups", f"view_topic_groups_{topic}_{acc_id}")]] if groups else []
            buttons.append([Button.inline("← Back", f"topic_select_{topic}")])
            msg = await event.edit(text, parse_mode='html', buttons=buttons)
            _put_flow_state(real_uid, uid, {'action': 'add_topic_link', 'topic': topic, 'account_id': acc_id, 'last_msg_id': msg.id if hasattr(msg, 'id') else event.message_id})
            return
        
        if data.startswith("view_topic_groups_"):
            parts = data.replace("view_topic_groups_", "").split("_", 1)
            topic = parts[0]
            acc_id = parts[1] if len(parts) > 1 else ""
            
            groups = await db_call(lambda: list(account_topics_col.find({'account_id': acc_id, 'topic': topic})))
            total = len(groups)
            display_limit = 5
            
            text = f"<b>🏷️ {topic.title()} Groups</b> <code>({total} total)</code>\n\n"
            for i, g in enumerate(groups[:display_limit]):
                title = g.get('title', g.get('url', 'Unknown'))[:25]
                text += f"{i+1}. {title}\n"
            
            if total > display_limit:
                text += f"\n...and {total - display_limit} more groups"
            
            buttons = [
                [Button.inline("Clear All", f"clear_topic_{topic}_{acc_id}")],
                [Button.inline("Back", f"topic_select_{topic}")]
            ]
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        
        if data.startswith("clear_topic_"):
            parts = data.replace("clear_topic_", "").split("_", 1)
            topic = parts[0]
            acc_id = parts[1] if len(parts) > 1 else ""
            
            await db_call(account_topics_col.delete_many, {'account_id': acc_id, 'topic': topic})
            await event.answer(f"Cleared all {topic} groups!", alert=True)
            await event.edit(
                f"<b>🏷️ {topic.title()}</b>\n\n<b>Groups:</b> <code>0</code>\n\n<i>Send a group link to add.</i>",
                parse_mode='html',
                buttons=[[Button.inline("← Back", b"menu_topics")]]
            )
            return
        
        # Locked premium-only buttons in Settings menu
        if data in {"locked_smart_rotation", "locked_auto_group_join"}:
            await event.edit(
                "<b>Paid Plan Feature</b>\n\nUpgrade to a paid plan to unlock this feature.",
                parse_mode='html',
                buttons=[[Button.inline("💎 View Plans", b"back_plans")], [Button.inline("← Back", b"menu_settings_automation")]]
            )
            return
        
        if data == "locked_autoreply":
            await event.edit(
                "<b>💬 Auto Reply</b>\n\n"
                "• <b>Starter</b> — not included\n"
                "• <b>Pro</b> — private AR, up to <b>2</b> keywords\n"
                "• <b>Elite</b> — full AR + Group AR\n\n"
                "Upgrade to unlock.",
                parse_mode='html',
                buttons=[[Button.inline("💎 View Plans", b"back_plans")], [Button.inline("← Back", b"menu_settings_content")]]
            )
            return

        if data == "locked_topics":
            await event.edit(
                "<b>Paid Plan Feature</b>\n\nUpgrade to a paid plan to unlock Topics.",
                parse_mode='html',
                buttons=[[Button.inline("💎 View Plans", b"back_plans")], [Button.inline("← Back", b"menu_settings_content")]]
            )
            return
        
        # Locked forwarding mode options (Topics Only and Both)
        if data == "locked_fwd_mode":
            await event.edit(
                "<b>Paid Plan Feature</b>\n\nUpgrade to a paid plan to unlock this forwarding mode.",
                parse_mode='html',
                buttons=[[Button.inline("💎 View Plans", b"back_plans")], [Button.inline("← Back", b"menu_fwd_mode")]]
            )
            return

        if data == "menu_settings":
            user_doc = await db_call(get_user, uid)
            tier_settings = await db_call(get_user_tier_settings, uid)
            
            # Get current settings
            ads_mode = user_doc.get('ads_mode', 'saved').upper()
            
            # Auto-reply status (check if user has explicitly enabled it AND set a message)
            auto_reply_feature_available = tier_settings.get('auto_reply_enabled', False)
            if auto_reply_feature_available:
                user = await db_call(get_user, uid)
                enabled_by_user = user.get('autoreply_enabled', False)  # Change default to False
                
                # Also check if user has actually set an auto-reply message
                # Do the N accounts + per-account settings lookups in ONE off-loop hop.
                def _has_autoreply_msg():
                    for acc in get_user_accounts(uid):
                        s = get_account_settings(str(acc.get('_id')))
                        if s.get('auto_reply'):
                            return True
                    return False
                has_auto_reply_message = await db_call(_has_autoreply_msg)
                
                # Show ON only if enabled AND has message
                auto_reply_status = "✅ ON" if (enabled_by_user and has_auto_reply_message) else "❌ OFF"
            else:
                auto_reply_status = "❌ OFF"
            
            # Interval: msg gap from Slow/Med/Fast/custom; cycle gap from cycle_interval_sec
            preset = user_doc.get('interval_preset', 'medium')
            cycle_sec = get_cycle_interval_sec(user_doc)
            if user_doc.get('msg_delay_sec'):
                msg_delay = int(user_doc['msg_delay_sec'])
                preset_name = 'Custom msg'
            elif preset == 'custom' and user_doc.get('custom_interval'):
                custom = user_doc.get('custom_interval') or {}
                msg_delay = int(custom.get('msg_delay', 30))
                preset_name = 'Custom'
            else:
                preset_info = INTERVAL_PRESETS.get(preset, INTERVAL_PRESETS['medium'])
                msg_delay = int(preset_info.get('msg_delay', 30))
                preset_name = str(preset).capitalize()
            interval_display = f"{preset_name} ({msg_delay}s msg / {cycle_sec}s cycle)"
            
            # Smart Rotation
            smart_rotation = user_doc.get('smart_rotation', True)
            rotation_status = "✅ ON" if smart_rotation else "❌ OFF"
            
            # Logs
            logs_enabled = bool(user_doc.get('logs_chat_id'))
            logs_status = "✅ Enabled" if logs_enabled else "❌ Disabled"
            
            # Auto Leave
            auto_leave_enabled = user_doc.get('auto_leave_groups', True)
            leave_status = "✅ ON" if auto_leave_enabled else "❌ OFF"
            
            text = (
                "<b>⚙️ Settings</b>\n\n"
                "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
                "<b>📋 Current Configuration:</b>\n"
                f"├ <b>📣 Ads Mode:</b> <code>{ads_mode}</code>\n"
                f"├ <b>💬 Auto-Reply:</b> <code>{auto_reply_status}</code>\n"
                f"├ <b>⏱️ Interval:</b> <code>{interval_display}</code>\n"
                f"├ <b>🔄 Smart Rotation:</b> <code>{rotation_status}</code>\n"
                f"├ <b>📝 Logs:</b> <code>{logs_status}</code>\n"
                f"└ <b>🚫 Auto Leave Failed:</b> <code>{leave_status}</code>\n\n"
                "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
            )
            await event.edit(text, parse_mode='html', buttons=settings_menu_keyboard(uid))
            return

        if data == "menu_settings_automation":
            text = (
                "<b>Automation Tools</b>\n\n"
                "Manage rotation, group join, quiet hours, refresh, and auto leave."
            )
            await event.edit(text, parse_mode='html', buttons=settings_automation_keyboard(uid))
            return


        if data == "view_toxic_groups":
            text, buttons = await render_toxic_view(uid)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data == "reset_toxic_groups":
            accts = await db_call(get_user_accounts, int(uid))
            for a in (accts or []):
                await db_call(clear_toxic_groups, str(a['_id']))
            await event.answer("Toxic list reset \u2014 these groups will be retried.", alert=True)
            text, buttons = await render_toxic_view(uid)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        if data == "menu_quiet_hours":
            if uid in user_states and user_states[uid].get('action') == 'quiet_hours':
                del user_states[uid]
            text, buttons = quiet_hours_menu(uid)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("quiet_preset_"):
            preset_map = {
                "quiet_preset_0100_0700": ("01:00", "07:00"),
                "quiet_preset_0000_0600": ("00:00", "06:00"),
                "quiet_preset_0000_0700": ("00:00", "07:00"),
            }
            if data not in preset_map:
                await event.answer("Invalid preset", alert=True)
                return

            start, end = preset_map[data]
            label = f"{start}-{end}"
            await db_call(uupdate, 
                {'user_id': int(uid)},
                {'$set': {'quiet_hours': {'enabled': True, 'start': start, 'end': end, 'label': label}}},
                upsert=True
            )
            await event.answer(f"Quiet hours set: {label}", alert=True)
            text, buttons = quiet_hours_menu(uid)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data == "quiet_off":
            await db_call(uupdate,
                {'user_id': int(uid)},
                {'$set': {'quiet_hours': {'enabled': False, 'start': None, 'end': None, 'label': 'Off'}}},
                upsert=True,
            )
            await event.answer("Quiet hours OFF — runs 24/7", alert=True)
            text, buttons = quiet_hours_menu(uid)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data == "quiet_custom":
            _put_flow_state(real_uid, uid, {'action': 'quiet_hours', 'step': 'start'})
            await event.edit(
                "<b>Quiet Hours - Custom</b>\n\n"
                "Send the <b>start time</b> in 24h format (HH:MM).\n"
                "Example: <code>01:00</code>",
                parse_mode='html',
                buttons=[[Button.inline("Back", b"menu_quiet_hours")]]
            )
            return

        if data == "menu_settings_content":
            text = (
                "<b>💬 Messages & Logs</b>\n\n"
                "• <b>Auto Reply</b> — reply to DMs (group AR if Elite)\n"
                "• <b>Topics</b> — lists for topic mode\n"
                "• <b>Logs</b> — send reports via logger bot\n"
                "• <b>Ads Mode</b> — Saved / custom text / post link"
            )
            await event.edit(text, parse_mode='html', buttons=settings_content_keyboard(uid))
            return
        
        if data == "toggle_auto_leave":
            user_doc = await db_call(get_user, uid)
            current = user_doc.get('auto_leave_groups', True)
            new_value = not current
            await db_call(uupdate, {'user_id': int(uid)}, {'$set': {'auto_leave_groups': new_value}}, upsert=True)
            
            status = "enabled" if new_value else "disabled"
            await event.answer(f"Auto Leave Failed {status}!", alert=True)
            text = (
                "<b>🤖 Automation</b>\n\n"
                "• <b>Smart Rotation</b> — shuffle groups & ads each round\n"
                "• <b>Auto Group Join</b> — join from a link list\n"
                "• <b>Refresh</b> — re-scan groups\n"
                "• <b>Auto Leave</b> — leave groups that keep failing"
            )
            await event.edit(text, parse_mode='html', buttons=settings_automation_keyboard(uid))
            return
        
        if data == "toggle_toxic_prune":
            user_doc = await db_call(get_user, uid)
            current = user_doc.get('toxic_prune', TOXIC_PRUNE_DEFAULT)
            new_value = not current
            await db_call(uupdate, {'user_id': int(uid)}, {'$set': {'toxic_prune': new_value}}, upsert=True)
            status = "enabled" if new_value else "disabled"
            await event.answer(f"Drop Toxic Groups {status}!", alert=True)
            text = (
                "<b>🤖 Automation</b>\n\n"
                "• <b>Smart Rotation</b> — shuffle groups & ads each round\n"
                "• <b>Auto Group Join</b> — join from a link list\n"
                "• <b>Refresh</b> — re-scan groups\n"
                "• <b>Auto Leave</b> — leave groups that keep failing"
            )
            await event.edit(text, parse_mode='html', buttons=settings_automation_keyboard(uid))
            return
        
        if data == "refresh_all_groups":
            # FREE for everyone. VPS-safe: batch + cooldown + one client at a time.
            accounts = await db_call(get_user_accounts, uid)
            if not accounts:
                await event.answer("Add an account first!", alert=True)
                return
            try:
                await event.answer("Refreshing… one account at a time")
            except Exception:
                pass
            _hint = (
                "<b>🔄 Refreshing groups</b>\n"
                "<i>Up to %s accounts per tap · ~%sm cooldown per account</i>"
            ) % (REFRESH_BATCH_MAX, max(1, REFRESH_COOLDOWN_SEC // 60))
            progress_msg = await event.respond(_hint, parse_mode='html')
            results, remaining = await _refresh_accounts_safe(accounts, force=False)
            if results:
                result_text = "<b>🔄 Refresh Complete</b>\n\n" + "\n".join(results)
            else:
                result_text = "<b>❌ Nothing refreshed</b>"
            if remaining > 0:
                result_text += (
                    "\n\n<i>%s account(s) left — tap <b>Refresh All Groups</b> "
                    "again for the next batch.</i>"
                ) % remaining
            await progress_msg.edit(
                result_text,
                parse_mode='html',
                buttons=[[Button.inline("Back", b"menu_settings_automation")]],
            )
            return

        if data == "menu_autoreply":
            _ar_ok = await db_call(can_use_private_autoreply, uid) or await db_call(is_admin, real_uid)
            tier = "Premium" if await db_call(is_premium, uid) else ("Admin" if await db_call(is_admin, real_uid) else "No Plan")
            text = f"<b>💬 Auto Reply</b>\n\n<b>Tier:</b> <code>{tier}</code>\n\n"
            
            if _ar_ok:
                user = await db_call(get_user, uid)
                enabled = user.get('autoreply_enabled', True)
                _kw_max = await db_call(get_max_keyword_replies, uid)
                _kw_n = len(user.get('keyword_replies') or [])
                
                # Check if user has set a custom message
                accounts = await db_call(get_user_accounts, uid)
                has_custom = any_account_has_autoreply(accounts)
                
                text += f"<b>Status:</b> <code>{'ON' if enabled else 'OFF'}</code>\n"
                text += f"<b>Keywords:</b> <code>{_kw_n}/{_kw_max if _kw_max < 50 else '∞'}</code>\n"
                text += f"<b>Custom Reply:</b> {'✅' if has_custom else '❌'} <code>{'Set' if has_custom else 'Not Set'}</code>"
            else:
                text += "🔒 <b>Auto-reply is a premium feature.</b>\n\n"
                text += "Upgrade to premium to set custom auto-reply messages!"
            
            await event.edit(text, parse_mode='html', buttons=await db_call(autoreply_menu_keyboard, uid))
            return
        
        if data == "autoreply_view":
            if not await db_call(is_premium, uid):
                await event.answer("Paid plan only!", alert=True)
                return
            
            # Get custom message from account settings
            accounts = await db_call(get_user_accounts, uid)
            reply = None
            if accounts:
                _ids = [str(acc['_id']) for acc in accounts]
                _d = account_settings_col.find_one(
                    {'account_id': {'$in': _ids}, 'auto_reply': {'$exists': True}}, {'auto_reply': 1})
                if _d:
                    reply = _d.get('auto_reply')
            
            if reply:
                text = f"<b>💬 Current Auto Reply</b>\n\n<blockquote>{_h(reply)}</blockquote>"
            else:
                text = "<b>💬 Current Auto Reply</b>\n\n<i>No custom message set yet.</i>"
            
            await event.edit(text, parse_mode='html', buttons=[[Button.inline("← Back", b"menu_autoreply")]])
            return


        if data == "group_autoreply_locked":
            await event.answer(
                "Group auto-reply is Elite only. Admin can allow with /gpreply <user>",
                alert=True,
            )
            return

        if data == "group_autoreply_toggle":
            if not await db_call(can_use_group_autoreply, uid):
                await event.answer("Elite plan or admin /gpreply grant required.", alert=True)
                return
            user = await db_call(get_user, uid)
            new_val = not bool(user.get('group_autoreply_enabled', False))
            await db_call(
                uupdate,
                {'user_id': int(uid)},
                {'$set': {'group_autoreply_enabled': new_val}},
                upsert=True,
            )
            await event.answer(f"Group auto-reply {'ON' if new_val else 'OFF'}", alert=False)
            await event.edit(
                "<b>💬 Auto Reply</b>\n\n"
                "<b>Private:</b> DMs (keywords + default message)\n"
                "<b>Group:</b> when someone @mentions the account or replies to its message",
                parse_mode='html',
                buttons=await db_call(autoreply_menu_keyboard, uid),
            )
            return

        if data == "group_autoreply_set":
            if not await db_call(can_use_group_autoreply, uid):
                await event.answer("Elite plan or admin /gpreply grant required.", alert=True)
                return
            user_states[real_uid] = {'action': 'set_group_autoreply', 'apply_to': int(uid)}
            await event.edit(
                "<b>👥 Set Group Auto Reply</b>\n\n"
                "Send the message to post when someone <b>@mentions</b> the account "
                "or <b>replies</b> to its message in a group.\n\n"
                "<i>One message for all group triggers.</i>",
                parse_mode='html',
                buttons=[[Button.inline("← Back", b"menu_autoreply")]],
            )
            return

        if data == "group_autoreply_view":
            user = await db_call(get_user, uid)
            msg = (user.get('group_auto_reply') or '').strip()
            body = f"<blockquote>{_h(msg)}</blockquote>" if msg else "<i>Not set yet.</i>"
            await event.edit(
                f"<b>👥 Group Auto Reply</b>\n\n{body}",
                parse_mode='html',
                buttons=[[Button.inline("← Back", b"menu_autoreply")]],
            )
            return

        if data == "autoreply_toggle":
            if not (await db_call(can_use_private_autoreply, uid) or await db_call(is_admin, real_uid)):
                await event.answer("Pro / Elite only (not Starter)", alert=True)
                return

            # Flip the flag and refresh menu
            user = await db_call(get_user, uid)
            enabled = user.get('autoreply_enabled', True)
            new_value = not enabled
            await db_call(uupdate, {'user_id': int(uid)}, {'$set': {'autoreply_enabled': new_value}})

            try:
                await event.answer(f"Auto Reply {'enabled' if new_value else 'disabled'}", alert=False)
            except Exception:
                pass

            # Re-render menu
            tier = "Premium"
            user = await db_call(get_user, uid)
            text = f"<b>💬 Auto Reply</b>\n\n<b>Tier:</b> <code>{tier}</code>\n\n"
            enabled = user.get('autoreply_enabled', True)
            
            # Check if user has set a custom message
            accounts = await db_call(get_user_accounts, uid)
            has_custom = any_account_has_autoreply(accounts)
            
            text += f"<b>Status:</b> <code>{'ON' if enabled else 'OFF'}</code>\n"
            text += f"<b>Custom Reply:</b> {'✅' if has_custom else '❌'} <code>{'Set' if has_custom else 'Not Set'}</code>"
            await event.edit(text, parse_mode='html', buttons=await db_call(autoreply_menu_keyboard, uid))
            return
        

        if data == "autoreply_add_keyword":
            if not (await db_call(can_use_private_autoreply, uid) or await db_call(is_admin, real_uid)):
                await event.answer("Pro / Elite only (not Starter)", alert=True)
                return
            _mx = await db_call(get_max_keyword_replies, uid)
            _u = await db_call(get_user, uid)
            if _mx > 0 and len(_u.get('keyword_replies') or []) >= _mx:
                await event.answer(f"Keyword limit {_mx} reached", alert=True)
                return
            user_states[real_uid] = {'action': 'add_keyword_reply', 'apply_to': int(uid)}
            await event.edit(
                "<b>➕ Add Keyword Reply</b>\n\n"
                "Send one line:\n<code>keyword - message to send</code>\n\n"
                "Example: <code>price - Plans start at ₹199/month</code>\n"
                "Case-insensitive; longer keyword wins if several match.",
                parse_mode='html',
                buttons=[[Button.inline("← Back", b"menu_autoreply")]],
            )
            return

        if data == "autoreply_list_keywords":
            if not (await db_call(is_premium, uid) or await db_call(is_admin, real_uid)):
                await event.answer("Paid plan / admin only!", alert=True)
                return
            user = await db_call(get_user, uid)
            kws = user.get('keyword_replies') or []
            if not kws:
                body = "<i>No keywords yet.</i>"
            else:
                lines = []
                for i, item in enumerate(kws, 1):
                    if not isinstance(item, dict):
                        continue
                    lines.append(
                        f"{i}. <code>{_h(str(item.get('keyword', '')))}</code> → "
                        f"{_h(str(item.get('message', ''))[:80])}"
                    )
                body = "\n".join(lines)
            await event.edit(
                f"<b>🔑 Keyword Replies</b>\n\n{body}",
                parse_mode='html',
                buttons=[
                    [Button.inline("➕ Add", b"autoreply_add_keyword")],
                    [Button.inline("🗑 Clear All", b"autoreply_clear_keywords")],
                    [Button.inline("← Back", b"menu_autoreply")],
                ],
            )
            return

        if data == "autoreply_clear_keywords":
            if not (await db_call(is_premium, uid) or await db_call(is_admin, real_uid)):
                await event.answer("Paid plan / admin only!", alert=True)
                return
            await db_call(uupdate, {'user_id': int(uid)}, {'$set': {'keyword_replies': []}}, upsert=True)
            await event.answer("Keywords cleared", alert=True)
            await event.edit(
                "<b>🔑 Keyword Replies</b>\n\n<i>No keywords.</i>",
                parse_mode='html',
                buttons=[
                    [Button.inline("➕ Add", b"autoreply_add_keyword")],
                    [Button.inline("← Back", b"menu_autoreply")],
                ],
            )
            return

        if data == "autoreply_custom":
            if not await db_call(is_premium, uid):
                await event.answer("Paid plan only!", alert=True)
                return
            _put_flow_state(real_uid, uid, {'action': 'custom_autoreply'})
            await event.edit(
                "<b>💬 Set Custom Reply</b>\n\nSend your custom auto-reply message:",
                parse_mode='html',
                buttons=[[Button.inline("← Back", b"menu_autoreply")]]
            )
            return
        
        if data == "back_plans":
            user = await db_call(get_user, uid)
            text = render_plan_select_text()
            await event.edit(
                text,
                parse_mode='html',
                buttons=plan_select_keyboard(uid, user=user),
            )
            return

        if data == "go_premium":
            # Show plan selection menu for everyone
            plan_msg = (
                "<b>Choose Your Plan</b>\n\n"
                "Pick what fits your scale. You can upgrade anytime.\n\n"
                "• Starter — 2 accounts (₹199)\n"
                "• Pro — 3 accounts (₹299)\n"
                "• Elite — 4 accounts (₹399)"
            )
            user = await db_call(get_user, uid)
            welcome_image = (MESSAGES.get('welcome_image') or '').strip()
            await _safe_cb_edit(
                event, plan_msg,
                buttons=plan_select_keyboard(uid, user=user),
                file=welcome_image or None,
            )
            return
        
        if data.startswith("buy_"):
            plan_key = data.replace("buy_", "").strip().lower()
            if plan_key in ("domi",):
                plan_key = "dominion"
            plan = PLANS.get(plan_key)
            if not plan or plan_key == "scout":
                await event.answer("Invalid or unavailable plan.", alert=True)
                return

            request_id = _new_payment_request_id(uid, plan_key)
            try:
                sender = await event.get_sender()
                uname = getattr(sender, "username", None)
            except Exception:
                uname = None
            pending_upi_payments[request_id] = {
                "user_id": int(uid),
                "username": uname,
                "plan_key": plan_key,
                "plan_name": plan.get("name", plan_key),
                "price": int(plan.get("price") or 0),
                "created_at": datetime.now(),
                "status": "awaiting_payment",
            }

            caption = _upi_payment_caption(plan, plan_key)
            pay_buttons = [
                [Button.inline("✅ Payment Done", f"paydone_{request_id}")],
                [Button.inline("← Back to Plans", b"back_plans")],
            ]
            qr = (UPI_PAYMENT.get("qr_image_url") or "").strip()
            try:
                if qr:
                    await event.edit(file=qr, text=caption, parse_mode="html", buttons=pay_buttons)
                else:
                    await event.edit(caption, parse_mode="html", buttons=pay_buttons)
            except Exception as e:
                print(f"[PAYMENT] UPI UI failed: {e}")
                try:
                    await main_bot.send_message(
                        uid, caption, parse_mode="html", buttons=pay_buttons, file=qr or None
                    )
                except Exception as e2:
                    print(f"[PAYMENT] UPI fallback send failed: {e2}")
                    await event.answer("Could not open payment screen. Try again.", alert=True)
            return

        if data == "account_limit_reached":
            if await db_call(get_user_max_accounts, uid) <= 0:
                plan_msg = render_plan_select_text()
                await event.edit(plan_msg, parse_mode='html', buttons=plan_select_keyboard(uid))
            else:
                await event.edit(
                    "**Account limit reached**\n\nYou have reached your current plan limit. Upgrade to add more accounts.",
                    buttons=[
                        [Button.inline("View Plans", b"go_premium")],
                        [Button.inline("Back", b"menu_account")]
                    ]
                )
            return
        
        if data == "menu_logs":
            logger_bot_username = CONFIG.get('logger_bot_username', 'logstesthubot')
            logger_link = f"https://t.me/{logger_bot_username}"

            user_doc = await db_call(get_user, uid)
            enabled = bool(user_doc.get('logs_chat_id'))
            status = "✅ Enabled" if enabled else "❌ Disabled"

            buttons = [[Button.url("Start Logger Bot", logger_link)]]
            if enabled:
                buttons.append([Button.inline("Disable Logs", b"logs_disable_global")])
            else:
                buttons.append([Button.inline("Enable Logs", b"logs_enable_global")])
            buttons.append([Button.inline("Back", b"menu_settings_content")])

            await event.edit(
                "<b>📝 Logs</b>\n\n"
                "<blockquote>Once enabled, logs will be sent for <b>all</b> your added accounts.</blockquote>\n\n"
                f"<b>Status:</b> <code>{status}</code>",
                parse_mode='html',
                buttons=buttons
            )
            return

        # ===================== Ads Mode (Saved/Custom/Post Link) =====================
        if data == "menu_ads_mode":
            user_doc = await db_call(get_user, uid)
            mode = user_doc.get('ads_mode', 'saved')
            modes = {
                'saved': 'Saved Message',
                'custom': 'Custom Message',
                'post': 'Post Link'
            }
            text = (
                "<b>📣 Ads Mode</b>\n\n"
                "<blockquote>Select which message will be used while running ads.</blockquote>\n\n"
                f"<b>Current:</b> <code>{modes.get(mode, mode)}</code>"
            )
            buttons = [
                [Button.inline("Saved Message" + (" ✅" if mode == 'saved' else ""), b"ads_mode_saved")],
                [Button.inline("Set Custom Message" + (" ✅" if mode == 'custom' else ""), b"ads_mode_custom")],
                [Button.inline("Set Post Link" + (" ✅" if mode == 'post' else ""), b"ads_mode_post")],
                [Button.inline("← Back", b"menu_settings_content")]
            ]
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data == "ads_mode_saved":
            await db_call(uupdate, {'user_id': uid}, {'$set': {'ads_mode': 'saved'}}, upsert=True)
            await event.answer("Ads Mode set: Saved Message", alert=True)
            await event.edit("<b>✅ Ads Mode Updated</b>\n\nNow bot will use each account's <b>Saved Messages</b> for forwarding.", parse_mode='html', buttons=[[Button.inline("← Back", b"menu_ads_mode")]])
            return

        if data == "ads_mode_custom":
            await db_call(uupdate, {'user_id': uid}, {'$set': {'ads_mode': 'custom'}}, upsert=True)
            cur = (await db_call(get_user, uid).get('ads_custom_message') or '').strip()
            preview = _h(cur[:500]) if cur else '<i>Not set</i>'
            text = (
                "<b>✍️ Custom Message</b>\n\n"
                "<b>Current Message:</b>\n"
                f"{preview}\n\n"
                "Send a new message to update it."
            )
            await event.edit(
                text,
                parse_mode='html',
                buttons=[
                    [Button.inline("Set Message", b"ads_custom_set")],
                    [Button.inline("View Current", b"ads_custom_view")],
                    [Button.inline("← Back", b"menu_ads_mode")]
                ]
            )
            return

        if data == "ads_custom_view":
            cur = (await db_call(get_user, uid).get('ads_custom_message') or '').strip()
            preview = _h(cur) if cur else '<i>Not set</i>'
            await event.edit(f"<b>✍️ Current Custom Message</b>\n\n{preview}", parse_mode='html', buttons=[[Button.inline("← Back", b"ads_mode_custom")]])
            return

        if data == "ads_custom_set":
            _put_flow_state(real_uid, uid, {'action': 'set_ads_custom_message'})
            await event.edit("<b>✍️ Send your custom message now</b>\n\n<i>Next message you send will be saved and used for ads.</i>", parse_mode='html', buttons=[[Button.inline("← Cancel", b"menu_ads_mode")]])
            return

        if data == "ads_mode_post":
            await db_call(uupdate, {'user_id': uid}, {'$set': {'ads_mode': 'post'}}, upsert=True)
            cur = (await db_call(get_user, uid).get('ads_post_link') or '').strip()
            preview = _h(cur) if cur else '<i>Not set</i>'
            await event.edit(
                "<b>🔗 Post Link</b>\n\n"
                f"<b>Current Link:</b> {preview}\n\n"
                "Send a Telegram post link like:\n"
                "<code>https://t.me/username/123</code>\n"
                "or\n"
                "<code>https://t.me/c/123456/789</code>",
                parse_mode='html',
                buttons=[
                    [Button.inline("Set Link", b"ads_post_set")],
                    [Button.inline("View Current", b"ads_post_view")],
                    [Button.inline("← Back", b"menu_ads_mode")]
                ]
            )
            return

        if data == "ads_post_view":
            cur = (await db_call(get_user, uid).get('ads_post_link') or '').strip()
            preview = _h(cur) if cur else '<i>Not set</i>'
            await event.edit(f"<b>🔗 Current Post Link</b>\n\n{preview}", parse_mode='html', buttons=[[Button.inline("← Back", b"ads_mode_post")]])
            return

        if data == "ads_post_set":
            _put_flow_state(real_uid, uid, {'action': 'set_ads_post_link'})
            await event.edit("<b>🔗 Send post link now</b>\n\n<i>Next message you send should be a Telegram post link.</i>", parse_mode='html', buttons=[[Button.inline("← Cancel", b"menu_ads_mode")]])
            return
        
        # ===================== Smart Rotation (Premium) =====================
        if data == "menu_smart_rotation":
            if not await db_call(is_premium, uid):
                await event.edit(
                    "<b>Paid Plan Feature</b>\n\nUpgrade to a paid plan to unlock Smart Rotation.",
                    parse_mode='html',
                    buttons=[[Button.inline("💎 View Plans", b"back_plans")], [Button.inline("← Back", b"menu_settings_automation")]]
                )
                return
            
            # Check if user has any accounts
            user_accounts = list(accounts_col.find({"owner_id": uid}))
            if not user_accounts:
                await event.answer("❌ Please add an account first!", alert=True)
                return
            
            # Get user settings (stored separately with user_id)
            user_settings = users_col.find_one({"user_id": uid})
            if not user_settings:
                user_settings = {}
            current = user_settings.get('smart_rotation', True)
            
            await event.edit(
                "<b>🔄 Smart Rotation</b>\n\n"
                "<blockquote>When enabled, the bot will randomly shuffle the order of your target groups before each forwarding round.\n\n"
                "This makes your forwarding pattern unpredictable and more natural, helping avoid detection and rate limits.</blockquote>\n\n"
                f"<b>Status:</b> {'✅ Enabled' if current else '❌ Disabled'}",
                parse_mode='html',
                buttons=[
                    [Button.inline("✅ Enable" if not current else "❌ Disable", b"toggle_smart_rotation")],
                    [Button.inline("\u2190 Back", b"menu_settings_automation")]
                ]
            )
            return
        
        if data == "toggle_smart_rotation":
            if not await db_call(is_premium, uid):
                await event.answer("⭐ Paid plan feature only!", alert=True)
                return
            
            # Get current state from users collection
            user_settings = users_col.find_one({"user_id": uid})
            if not user_settings:
                user_settings = {}
            current = user_settings.get('smart_rotation', True)
            new_val = not current
            
            # Save to users collection
            await db_call(uupdate, 
                {"user_id": uid},
                {"$set": {"smart_rotation": new_val}},
                upsert=True
            )
            
            await event.edit(
                "<b>🔄 Smart Rotation</b>\n\n"
                "<blockquote>When enabled, the bot will randomly shuffle the order of your target groups before each forwarding round.\n\n"
                "This makes your forwarding pattern unpredictable and more natural, helping avoid detection and rate limits.</blockquote>\n\n"
                f"<b>Status:</b> {'✅ Enabled' if new_val else '❌ Disabled'}",
                parse_mode='html',
                buttons=[
                    [Button.inline("✅ Enable" if not new_val else "❌ Disable", b"toggle_smart_rotation")],
                    [Button.inline("\u2190 Back", b"menu_settings_automation")]
                ]
            )
            return
        
        # ===================== Auto Group Join (Premium) =====================
        if data == "menu_auto_group_join":
            if not await db_call(is_premium, uid):
                await event.answer("⭐ Paid plan feature only!", alert=True)
                return
            
            # Check if user has any accounts
            user_accounts = list(accounts_col.find({"owner_id": uid}))
            if not user_accounts:
                await event.answer("❌ Please add an account first!", alert=True)
                return
            
            await event.edit(
                "<b>👥 Auto Group Join</b>\n\n"
                "<blockquote>Upload a .txt file with group links (one per line), and all your logged-in accounts will automatically join those groups.\n\n"
                "Supported formats:\n"
                "• https://t.me/groupname\n"
                "• t.me/groupname\n"
                "• @groupname</blockquote>\n\n"
                "Send the .txt file now, or tap Back to cancel.",
                parse_mode='html',
                buttons=[
                    [Button.inline("\U0001F50E Find Groups by Niche", b"find_groups")],
                    [Button.inline("\u2190 Back", b"menu_settings_automation")]
                ]
            )
            _put_flow_state(real_uid, uid, {'state': 'awaiting_group_join_file'})
            return

        if data == "find_groups":
            if not await db_call(is_premium, uid):
                await event.answer("\u2B50 Paid plan feature only!", alert=True)
                return
            if not list(accounts_col.find({'owner_id': uid}).limit(1)):
                await event.answer("\u274C Add an account first!", alert=True)
                return
            _put_flow_state(real_uid, uid, {'state': 'awaiting_niche_keyword'})
            await event.edit(
                "<b>\U0001F50E Find Groups by Niche</b>\n\n"
                "<blockquote>Send a keyword/niche (e.g. <code>crypto</code>, <code>forex</code>, "
                "<code>dropshipping</code>) and I'll search Telegram for public groups to join.</blockquote>",
                parse_mode='html',
                buttons=[[Button.inline("\u2190 Back", b"menu_auto_group_join")]]
            )
            return

        if data == "join_found_groups":
            _found = (user_states.get(uid, {}) or {}).get("found_groups") or []
            if not _found:
                await event.answer("Search again first.", alert=True)
                return
            user_states.pop(uid, None)
            await event.edit(
                f"<b>\u2795 Joining {len(_found)} groups\u2026</b>\n\n<i>Paced to stay safe; summary follows here.</i>",
                parse_mode='html', buttons=[[Button.inline("\u23F9 Stop", b"auto_join_cancel")]]
            )
            _spawn_bg(_join_groups_for_user(uid, _found, event.chat_id, "Joining found groups"))
            return

        if data == "menu_results":
            accounts = await db_call(get_user_accounts, uid)
            sent = await db_call(bulk_total_sent, accounts)
            clicks, links = await db_call(lambda: get_user_click_stats(uid))
            lines = [f"<b>\U0001F4C8 Results</b>\n",
                     f"<b>Ads sent:</b> <code>{sent}</code>",
                     f"<b>Tracked clicks:</b> <code>{clicks}</code>",
                     f"<b>Tracked links:</b> <code>{len(links)}</code>"]
            if links:
                lines.append("\n<b>Per-link clicks:</b>")
                for d in sorted(links, key=lambda x: x.get('clicks', 0), reverse=True)[:10]:
                    lines.append(f"\u2022 <code>{d.get('clicks',0)}</code> \u2014 {_h((d.get('target_url') or '')[:42])}")
            if not N8N_TRACK_BASE:
                lines.append("\n<i>Click tracking not configured (set N8N_TRACK_BASE + run the n8n workflow).</i>")
            await event.edit("\n".join(lines), parse_mode='html', buttons=[
                [Button.inline("\U0001F517 Create Tracked Link", b"create_tracked_link")],
                [Button.inline("\u2190 Back", b"menu_broadcast")],
            ])
            return

        if data == "create_tracked_link":
            if not N8N_TRACK_BASE:
                await event.answer("Click tracking isn't set up yet (admin: set N8N_TRACK_BASE).", alert=True)
                return
            _put_flow_state(real_uid, uid, {'state': 'awaiting_track_url'})
            await event.edit(
                "<b>\U0001F517 Create Tracked Link</b>\n\n"
                "<blockquote>Send the URL you advertise (e.g. your channel/website). I'll give you a tracked "
                "link to put in your ad \u2014 every click is counted in Results.</blockquote>",
                parse_mode='html', buttons=[[Button.inline("\u2190 Back", b"menu_results")]]
            )
            return

        if data == "logs_enable_global":
            # Enable logs globally for user (applies to all accounts)
            await db_call(uupdate, {'user_id': int(uid)}, {'$set': {'logs_chat_id': int(uid)}}, upsert=True)
            invalidate_logs_cache()
            await event.answer("Logs enabled", alert=True)
            await event.edit(
                "<b>✅ Logs Enabled</b>\n\n<blockquote>Logs will now be sent for <b>all</b> your added accounts.</blockquote>",
                parse_mode='html',
                buttons=[[Button.inline("Back", b"menu_logs")]]
            )
            return

        if data == "logs_disable_global":
            await db_call(uupdate, {'user_id': int(uid)}, {'$unset': {'logs_chat_id': ""}})
            invalidate_logs_cache()
            await event.answer("Logs disabled", alert=True)
            await event.edit(
                "<b>❌ Logs Disabled</b>\n\n<i>You will no longer receive logs.</i>",
                parse_mode='html',
                buttons=[[Button.inline("Back", b"menu_logs")]]
            )
            return

        if data == "menu_fwd_mode":
            user = await db_call(get_user, uid)
            current = user.get('forwarding_mode', 'auto')  # Free users default to Groups Only
            user_is_premium = await db_call(is_premium, uid)
            
            modes = {
                'topics': 'Forward to Topics Only',
                'auto': 'Forward to Groups Only',
                'both': 'Forward to Both (Topics first, then Groups)'
            }
            
            text = (
                "<b>🔄 Mode</b>\n\n"
                "Select how ads should be forwarded."
            )
            
            if not user_is_premium:
                text += "\n\n<i>Non-premium accounts can forward to groups only. Upgrade for more options.</i>"
            
            buttons = []
            for mode, label in modes.items():
                mark = " ✅" if mode == current else ""
                
                # Lock topics and both for free users
                if not user_is_premium and mode in ['topics', 'both']:
                    buttons.append([Button.inline(f"{label} 🔒", b"locked_fwd_mode")])
                else:
                    buttons.append([Button.inline(f"{label}{mark}", f"set_fwd_mode_{mode}")])
            
            buttons.append([Button.inline("← Back", b"menu_broadcast")])
            
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        
        if data.startswith("set_fwd_mode_"):
            mode = data.replace("set_fwd_mode_", "")
            await db_call(uupdate, {'user_id': uid}, {'$set': {'forwarding_mode': mode}})
            modes = {
                'topics': 'Forward to Topics Only',
                'auto': 'Forward to Groups Only',
                'both': 'Forward to Both (Topics first, then Groups)'
            }
            await event.answer(f"Mode set: {modes.get(mode, mode)}", alert=True)
            
            text = (
                "<b>🔄 Mode</b>\n\n"
                "Select how ads should be forwarded."
            )
            
            buttons = []
            for m, label in modes.items():
                mark = " ✅" if m == mode else ""
                buttons.append([Button.inline(f"{label}{mark}", f"set_fwd_mode_{m}")])
            buttons.append([Button.inline("← Back", b"menu_broadcast")])
            
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        
        if data == "menu_refresh":
            accounts = await db_call(get_user_accounts, uid)
            total_groups = 0
            for acc in accounts:
                try:
                    session = cipher_suite.decrypt(acc['session'].encode()).decode()
                    client = TelegramClient(StringSession(session), CONFIG['api_id'], CONFIG['api_hash'])
                    await client.connect()
                    count = await fetch_groups_for_account(client, acc['_id'])
                    total_groups += count
                    await client.disconnect()
                except Exception:
                    pass
            await event.answer(f"Refreshed! Found {total_groups} groups.", alert=True)
            
            text = await db_call(render_dashboard_text, uid)
            buttons = main_dashboard_keyboard(uid, viewer_id=real_uid)
            # Admin button removed (already in main_dashboard_keyboard)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        

        if data == "start_all_ads":
            accounts = await db_call(get_user_accounts, uid)
            if not accounts:
                await event.answer("No accounts to start!", alert=True)
                return

            # Profile templates must not block Start
            try:
                _spawn_bg(apply_account_profile_templates(uid))
            except Exception:
                pass

            started = await start_broadcast_for_user(uid)
            try:
                await event.answer(
                    f"Started {started} account(s). Sending begins shortly.",
                    alert=True,
                )
            except Exception:
                pass
            # Toast only — stay on Ads menu (fast; no full dashboard rebuild)
            await event.edit(
                "<b>📢 Ads Control</b>\n\n"
                f"✅ <b>Started {started}</b> account(s).\n"
                "Workers will pick them up within a few seconds.\n\n"
                "• <b>Stop Ads</b> — pause all\n"
                "• <b>Timing</b> / <b>Where to Send</b> — adjust while running",
                parse_mode='html',
                buttons=await db_call(broadcast_menu_keyboard, uid),
            )
            return


        if data == "stop_all_ads":
            stopped = await stop_broadcast_for_user(uid)
            try:
                await event.answer(f"Stopped {stopped} account(s).", alert=True)
            except Exception:
                pass
            await event.edit(
                "<b>📢 Ads Control</b>\n\n"
                f"⏹ <b>Stopped {stopped}</b> account(s).\n"
                "No further sends until you Start again.",
                parse_mode='html',
                buttons=await db_call(broadcast_menu_keyboard, uid),
            )
            return


        if data == "tier_free":
            if not await db_call(is_approved, uid):
                approve_user(uid)
            
            accounts = await db_call(get_user_accounts, uid)
            max_acc = await db_call(get_user_max_accounts, uid)
            tier_settings = await db_call(get_user_tier_settings, uid)
            tier = "Premium" if await db_call(is_premium, uid) else "No Plan"
            active = sum(1 for a in accounts if a.get('is_forwarding'))
            
            text = (
                f"<b>{tier} Hub</b>\n\n"
                f"<b>Accounts:</b> <code>{len(accounts)}/{max_acc}</code>\n"
                f"<b>Active:</b> <code>{active}</code> | <b>Inactive:</b> <code>{len(accounts) - active}</code>\n\n"
                f"<b>Delays:</b> <code>{tier_settings['msg_delay']}s msg / {tier_settings['round_delay']}s round</code>"
            )

            await event.edit(text, parse_mode='html', buttons=await db_call(account_list_keyboard, uid))
            return
        
        if data == "tier_premium":
            if await db_call(is_premium, uid):
                await event.edit(
                    "**Plan Active**\n\nYour paid plan is already active.",
                    buttons=[[Button.inline("Open Dashboard", b"tier_free")], [Button.inline("Back", b"enter_dashboard")]]
                )
            else:
                await event.edit(
                    f"**Plan Access**\n\n{MESSAGES['premium_contact']}",
                    buttons=premium_contact_keyboard()
                )
            return
        
        if data == "admin_panel" or data == "back_admin":
            if not await db_call(is_admin, uid):
                await event.answer("Admin only!", alert=True)
                return
            
            # Reuse stats for a few seconds so rapid open/back does not re-count Mongo
            import time as _time
            _now = _time.time()
            if (
                _ADMIN_PANEL_STATS_CACHE.get('data') is not None
                and (_now - float(_ADMIN_PANEL_STATS_CACHE.get('ts') or 0)) < _ADMIN_PANEL_STATS_TTL
            ):
                _ap_counts = _ADMIN_PANEL_STATS_CACHE['data']
            else:
                today_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
                _ap_counts = await db_call(lambda: {
                    'total_users': users_col.count_documents({}),
                    'premium_users': users_col.count_documents({'tier': 'premium'}),
                    'total_accounts': accounts_col.count_documents({}),
                    'active': accounts_col.count_documents({'is_forwarding': True}),
                    'total_admins': admins_col.count_documents({}) + 1,
                    'new_today': users_col.count_documents({'created_at': {'$gte': today_start}}),
                })
                _ADMIN_PANEL_STATS_CACHE['ts'] = _now
                _ADMIN_PANEL_STATS_CACHE['data'] = _ap_counts
            total_users = _ap_counts['total_users']
            premium_users = _ap_counts['premium_users']
            total_accounts = _ap_counts['total_accounts']
            active = _ap_counts['active']
            total_admins = _ap_counts['total_admins']
            new_today = _ap_counts['new_today']
            
            text = (
                "<b>🛠 Admin Panel</b>\n\n"
                "Manage users, plans, accounts, and global limits.\n\n"
                "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
                "<b>👥 User Statistics:</b>\n"
                f"├ <b>Total Users:</b> <code>{total_users}</code> <i>(+{new_today} today)</i>\n"
                f"├ <b>💎 Premium Users:</b> <code>{premium_users}</code>\n"
                f"└ <b>👨‍💼 Total Admins:</b> <code>{total_admins}</code>\n\n"
                "<b>📱 Account Statistics:</b>\n"
                f"├ <b>Total Accounts:</b> <code>{total_accounts}</code>\n"
                f"└ <b>▶️ Active Forwarding:</b> <code>{active}</code>\n\n"
                "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
            )
            
            await event.edit(text, parse_mode='html', buttons=admin_panel_keyboard())
            return

        if data == "admin_stop_all_broadcasts":
            if not await db_call(is_admin, uid):
                await event.answer("Admin only!", alert=True)
                return
            stopped = await stop_all_broadcasts()
            await event.edit(
                f"<b>🛑 Global Stop</b>\n\n<b>Accounts Stopped:</b> <code>{stopped}</code>",
                parse_mode='html',
                buttons=[[Button.inline("← Back", b"admin_panel")]]
            )
            return
        
        if data == "admin_admins":
            if not await db_call(is_admin, uid):
                return
            
            # Show all admins with IDs and usernames
            try:
                owner_id = CONFIG.get('owner_id')
                all_admins = await db_call(lambda: list(admins_col.find({}, {'user_id': 1})))
                admin_ids = [admin['user_id'] for admin in all_admins]
                
                text = "<b>ᴀᴅᴍɪɴꜱ ᴍᴀɴᴀɢᴇᴍᴇɴᴛ</b>\n\n"
                text += "<blockquote><b>Commands:</b>\n"
                text += "<code>/addadmin {user_id}</code>\n"
                text += "<code>/rmadmin {user_id}</code></blockquote>\n\n"
                text += "━━━━━━━━━━━━━━━\n\n"
                text += "<b>ᴀᴅᴍɪɴꜱ ʟɪꜱᴛ</b>\n\n"
                
                # Show owner
                try:
                    owner = await main_bot.get_entity(int(owner_id))
                    owner_username = f"@{owner.username}" if getattr(owner, 'username', None) else "ɴᴏ ᴜꜱᴇʀɴᴀᴍᴇ"
                    owner_name = getattr(owner, 'first_name', 'Owner')
                    text += f"👑 <b>ᴏᴡɴᴇʀ:</b> <code>{owner_id}</code>\n"
                    text += f"   ɴᴀᴍᴇ: {owner_name}\n"
                    text += f"   ᴜꜱᴇʀɴᴀᴍᴇ: {owner_username}\n\n"
                except Exception:
                    text += f"👑 <b>ᴏᴡɴᴇʀ:</b> <code>{owner_id}</code>\n\n"
                
                # Show admins
                if admin_ids:
                    text += f"👥 <b>ᴀᴅᴍɪɴꜱ ({len(admin_ids)}):</b>\n\n"
                    for admin_id in admin_ids:
                        try:
                            admin = await main_bot.get_entity(int(admin_id))
                            admin_username = f"@{admin.username}" if getattr(admin, 'username', None) else "ɴᴏ ᴜꜱᴇʀɴᴀᴍᴇ"
                            admin_name = getattr(admin, 'first_name', 'Admin')
                            text += f"   • <code>{admin_id}</code>\n"
                            text += f"      ɴᴀᴍᴇ: {admin_name}\n"
                            text += f"      ᴜꜱᴇʀɴᴀᴍᴇ: {admin_username}\n\n"
                        except Exception:
                            text += f"   • <code>{admin_id}</code>\n\n"
                else:
                    text += "👥 <b>ᴀᴅᴍɪɴꜱ:</b> ɴᴏ ᴀᴅᴍɪɴꜱ ᴀᴅᴅᴇᴅ"
                
                await event.edit(text, parse_mode='html', buttons=[[Button.inline("← Back", b"admin_panel")]])
            except Exception as e:
                await event.edit(f"<b>Error:</b> {str(e)}", parse_mode='html', buttons=[[Button.inline("← Back", b"admin_panel")]])
            return
        
        if data == "admin_users":
            # Overview dashboard
            if not await db_call(is_admin, real_uid):
                await event.answer("Admin only!", alert=True)
                return
            try:
                today_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
                snap = await db_call(lambda: {
                    'users': users_col.count_documents({}),
                    'premium': users_col.count_documents({
                        '$or': [
                            {'is_premium': True},
                            {'premium': True},
                            {'tier': 'premium'},
                            {'plan': {'$in': ['grow', 'prime', 'dominion']}},
                        ]
                    }),
                    'banned': users_col.count_documents({'banned': True}),
                    'accounts': accounts_col.count_documents({}),
                    'active': accounts_col.count_documents({'is_forwarding': True}),
                    'new_today': users_col.count_documents({'created_at': {'$gte': today_start}}),
                })
                # Aggregate send stats (projection)
                def _agg_stats():
                    sent = fail = ar = 0
                    for s in account_stats_col.find({}, {'total_sent': 1, 'total_failed': 1, 'auto_replies': 1}):
                        sent += int(s.get('total_sent') or 0)
                        fail += int(s.get('total_failed') or 0)
                        ar += int(s.get('auto_replies') or 0)
                    return sent, fail, ar
                total_sent, total_failed, total_ar = await db_call(_agg_stats)
                rate = (total_sent / max(1, total_sent + total_failed)) * 100
                tph = get_effective_target_per_hour()
                ll = 'ON' if live_logs_enabled() else 'OFF'
                text_o = (
                    f"<b>📈 Overview</b>\n\n"
                    f"<b>Users</b>\n"
                    f"├ Total: <code>{snap['users']}</code> (+{snap['new_today']} today)\n"
                    f"├ Paid: <code>{snap['premium']}</code>\n"
                    f"└ Banned: <code>{snap['banned']}</code>\n\n"
                    f"<b>Accounts</b>\n"
                    f"├ Total: <code>{snap['accounts']}</code>\n"
                    f"└ Sending now: <code>{snap['active']}</code>\n\n"
                    f"<b>Messages</b>\n"
                    f"├ Sent: <code>{total_sent}</code>\n"
                    f"├ Failed: <code>{total_failed}</code>\n"
                    f"├ Success: <code>{rate:.1f}%</code>\n"
                    f"└ Auto-replies: <code>{total_ar}</code>\n\n"
                    f"<b>Global</b>\n"
                    f"├ Freq cap: <code>{tph}/hr</code>\n"
                    f"└ Live logs: <code>{ll}</code>"
                )
                await event.edit(
                    text_o,
                    parse_mode='html',
                    buttons=[
                        [Button.inline("🔄 Refresh", b"admin_users")],
                        [Button.inline("← Admin Panel", b"admin_panel")],
                    ],
                )
            except Exception as e:
                await event.edit(
                    f"<b>Overview error:</b> {_h(str(e)[:200])}",
                    parse_mode='html',
                    buttons=[[Button.inline("← Back", b"admin_panel")]],
                )
            return

        if data == "admin_banned_users":
            if not await db_call(is_admin, real_uid):
                await event.answer("Admin only!", alert=True)
                return
            try:
                banned = await db_call(
                    lambda: list(
                        users_col.find({'banned': True}, {'user_id': 1, 'username': 1, 'ban_reason': 1})
                        .sort('user_id', 1)
                        .limit(40)
                    )
                )
                if not banned:
                    await event.edit(
                        "<b>🚫 Banned Users</b>\n\n<i>No banned users.</i>",
                        parse_mode='html',
                        buttons=[[Button.inline("← Admin Panel", b"admin_panel")]],
                    )
                    return
                lines = [f"<b>🚫 Banned Users</b> <code>({len(banned)})</code>\n"]
                buttons = []
                for u in banned:
                    uid_b = int(u['user_id'])
                    un = u.get('username')
                    label = f"@{un}" if un else str(uid_b)
                    reason = (u.get('ban_reason') or '—')[:40]
                    lines.append(f"• {label} — <i>{_h(reason)}</i>")
                    buttons.append([Button.inline(f"✅ Unban {label}", f"admin_unban_{uid_b}")])
                buttons.append([Button.inline("← Admin Panel", b"admin_panel")])
                await event.edit("\n".join(lines), parse_mode='html', buttons=buttons)
            except Exception as e:
                await event.edit(
                    f"<b>Banned list error:</b> {_h(str(e)[:200])}",
                    parse_mode='html',
                    buttons=[[Button.inline("← Back", b"admin_panel")]],
                )
            return

        if data.startswith("admin_unban_"):
            if not await db_call(is_admin, real_uid):
                await event.answer("Admin only!", alert=True)
                return
            try:
                target = int(data.replace("admin_unban_", ""))
            except Exception:
                await event.answer("Bad user id", alert=True)
                return
            await db_call(
                uupdate,
                {'user_id': int(target)},
                {'$set': {'banned': False}, '$unset': {'ban_reason': ''}},
                upsert=True,
            )
            await event.answer(f"Unbanned {target}", alert=True)
            # Refresh list
            data = "admin_banned_users"
            # fall through by re-invoking via edit path: set and continue
            banned = await db_call(
                lambda: list(
                    users_col.find({'banned': True}, {'user_id': 1, 'username': 1, 'ban_reason': 1})
                    .sort('user_id', 1)
                    .limit(40)
                )
            )
            if not banned:
                await event.edit(
                    "<b>🚫 Banned Users</b>\n\n<i>No banned users.</i>",
                    parse_mode='html',
                    buttons=[[Button.inline("← Admin Panel", b"admin_panel")]],
                )
                return
            lines = [f"<b>🚫 Banned Users</b> <code>({len(banned)})</code>\n"]
            buttons = []
            for u in banned:
                uid_b = int(u['user_id'])
                un = u.get('username')
                label = f"@{un}" if un else str(uid_b)
                reason = (u.get('ban_reason') or '—')[:40]
                lines.append(f"• {label} — <i>{_h(reason)}</i>")
                buttons.append([Button.inline(f"✅ Unban {label}", f"admin_unban_{uid_b}")])
            buttons.append([Button.inline("← Admin Panel", b"admin_panel")])
            await event.edit("\n".join(lines), parse_mode='html', buttons=buttons)
            return

        if data == "admin_all_users":
            if not await db_call(is_admin, uid):
                return

            page = 0
            per_page = 5
            users = await db_call(lambda: list(users_col.find().sort('created_at', -1).skip(page*per_page).limit(per_page)))
            total = await db_call(users_col.count_documents, {})
            total_pages = max(1, (total + per_page - 1) // per_page)

            text = f"<b>👥 All Users</b> <code>({total} total, page {page+1}/{total_pages})</code>\n\n"
            user_list = []
            buttons = []
            
            for u in users:
                user_id = u['user_id']
                username = u.get('username')
                
                # Try to fetch username from Telegram if not in database
                if not username:
                    username = await get_username_from_id(event.client, user_id)
                    if username:
                        # Update database with fetched username
                        await db_call(uupdate, {'user_id': user_id}, {'$set': {'username': username}})
                
                # Add to display list
                if username:
                    user_list.append(f"@{username}")
                    label = f"View @{username}"
                else:
                    user_list.append(f"<code>{user_id}</code>")
                    label = f"View {user_id}"
                
                buttons.append([Button.inline(label, f"admin_user_detail_all_{user_id}")])
            
            text += "\n".join(user_list) if users else "<i>No users found.</i>"
            nav = []
            if page > 0:
                nav.append(Button.inline("<", f"admin_all_users_page_{page-1}"))
            if (page+1)*per_page < total:
                nav.append(Button.inline(">", f"admin_all_users_page_{page+1}"))
            if nav:
                buttons.append(nav)

            buttons.append([Button.inline("← Back", b"admin_panel")])
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        
        if data.startswith("admin_all_users_page_"):
            if not await db_call(is_admin, uid):
                return

            page = int(data.replace("admin_all_users_page_", ""))
            per_page = 5
            users = await db_call(lambda: list(users_col.find().sort('created_at', -1).skip(page*per_page).limit(per_page)))
            total = await db_call(users_col.count_documents, {})
            total_pages = max(1, (total + per_page - 1) // per_page)

            text = f"<b>👥 All Users</b> <code>({total} total, page {page+1}/{total_pages})</code>\n\n"
            user_list = []
            buttons = []
            
            for u in users:
                user_id = u['user_id']
                username = u.get('username')
                
                # Try to fetch username from Telegram if not in database
                if not username:
                    username = await get_username_from_id(event.client, user_id)
                    if username:
                        # Update database with fetched username
                        await db_call(uupdate, {'user_id': user_id}, {'$set': {'username': username}})
                
                # Add to display list
                if username:
                    user_list.append(f"@{username}")
                    label = f"View @{username}"
                else:
                    user_list.append(f"<code>{user_id}</code>")
                    label = f"View {user_id}"
                
                buttons.append([Button.inline(label, f"admin_user_detail_all_{user_id}")])
            
            text += "\n".join(user_list) if users else "<i>No users found.</i>"
            nav = []
            if page > 0:
                nav.append(Button.inline("<", f"admin_all_users_page_{page-1}"))
            if (page+1)*per_page < total:
                nav.append(Button.inline(">", f"admin_all_users_page_{page+1}"))
            if nav:
                buttons.append(nav)

            buttons.append([Button.inline("← Back", b"admin_panel")])
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        
        if data.startswith("admin_user_detail_all_"):
            if not await db_call(is_admin, uid):
                return

            target_id = int(data.replace("admin_user_detail_all_", ""))
            user_detail_source = 'all'

        elif data.startswith("admin_user_detail_"):
            if not await db_call(is_admin, uid):
                return
            
            target_id = int(data.replace("admin_user_detail_", ""))
            user_detail_source = 'premium'
        
        # Common user detail display logic for both handlers
        if data.startswith("admin_user_detail_all_") or data.startswith("admin_user_detail_"):
            user = await db_call(users_col.find_one, {'user_id': target_id})
            
            if not user:
                await event.answer("User not found!", alert=True)
                return
            
            tier = user.get('tier', 'free')
            max_acc = get_plan_max_accounts(user)
            approved = user.get('approved', False)
            accounts = await db_call(lambda: list(accounts_col.find({'owner_id': target_id})))
            active = sum(1 for a in accounts if a.get('is_forwarding'))
            
            created_at = user.get('created_at')
            created_str = created_at.strftime('%Y-%m-%d %H:%M') if hasattr(created_at, 'strftime') else str(created_at)
            
            # Show plan name and expiry instead of tier
            # Check if target user is admin
            is_target_admin = await db_call(is_admin, target_id)
            
            if is_target_admin:
                plan_display = "⚡ God Mode"
                expiry_display = "∞"
                max_acc = 999  # Admins have unlimited accounts
            elif tier == 'premium':
                plan_name = get_display_plan_name(user)
                expires_at = user.get('premium_expires_at')
                if expires_at and isinstance(expires_at, datetime):
                    remaining = expires_at - datetime.now()
                    if remaining.total_seconds() > 0:
                        expiry_display = f"{remaining.days}d"
                    else:
                        expiry_display = "Expired"
                else:
                    expiry_display = "∞"
                plan_display = plan_name
            else:
                plan_display = "No Plan"
                expiry_display = "∞"
            
            text = (
                "<b>👤 User Profile</b>\n\n"
                "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
                "<b>📋 User Information:</b>\n"
                f"├ <b>User ID:</b> <code>{target_id}</code>\n"
                f"├ <b>Plan:</b> <code>{plan_display}</code>\n"
                f"├ <b>Expiry:</b> <code>{expiry_display}</code>\n"
                f"└ <b>Approved:</b> {'✅ Yes' if approved else '❌ No'}\n\n"
                "<b>📱 Account Statistics:</b>\n"
                f"├ <b>Max Accounts:</b> <code>{max_acc}</code>\n"
                f"├ <b>Total Accounts:</b> <code>{len(accounts)}</code>\n"
                f"└ <b>▶️ Active Now:</b> <code>{active}</code>\n\n"
                "<b>⏰ Account Activity:</b>\n"
                f"└ <b>Joined:</b> <code>{created_str}</code>\n\n"
                "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
            )
            
            buttons = []
            
            # Don't show Grant/Revoke Premium buttons for admins
            if not is_target_admin:
                if tier != 'premium':
                    buttons.append([Button.inline("✅ Grant Premium", f"admin_grant_premium_{target_id}")])
                else:
                    buttons.append([Button.inline("❌ Revoke Premium", f"admin_revoke_premium_{target_id}")])
                
                # Add Reset button for non-admin users
                buttons.append([Button.inline("Reset User", f"admin_reset_user_{target_id}")])
                buttons.append([
                    Button.inline("Start Broadcast", f"admin_start_broadcast_{target_id}"),
                    Button.inline("Stop Broadcast", f"admin_stop_broadcast_{target_id}")
                ])
                buttons.append([Button.inline("Set Settings", f"admin_set_settings_{target_id}_{user_detail_source}")])
                buttons.append([
                    Button.inline("Automation Tools", f"admin_settings_automation_{target_id}_{user_detail_source}"),
                    Button.inline("Messaging & Logs", f"admin_menu_content_{target_id}_{user_detail_source}")
                ])
                buttons.append([Button.inline("Accounts", f"admin_user_accounts_{target_id}")])
                buttons.append([Button.inline("Add Account", f"admin_add_account_{target_id}")])
                buttons.append([Button.inline("View as user", f"admin_impersonate_{target_id}")])
            
            # Back button routing based on source list
            if user_detail_source == 'all':
                back_callback = b"admin_all_users"
            else:
                back_callback = b"admin_premium"
            buttons.append([Button.inline("← Back", back_callback)])
            
            await event.edit(text, parse_mode='html', buttons=buttons)
            return


        if data.startswith("admin_impersonate_"):
            if not _is_adm:
                return
            try:
                target_id = int(data.replace("admin_impersonate_", ""))
            except ValueError:
                await event.answer("Invalid user", alert=True)
                return
            if int(target_id) == int(real_uid):
                await event.answer("Already yourself", alert=True)
                return
            target = await db_call(users_col.find_one, {'user_id': int(target_id)})
            if not target:
                await event.answer("User not found", alert=True)
                return
            _impersonate[int(real_uid)] = int(target_id)
            try:
                _write_impersonation_audit(
                    audit_col,
                    admin_id=int(real_uid),
                    target_id=int(target_id),
                    action='start_view_as',
                    detail='admin_impersonate',
                )
            except Exception:
                pass
            # Drop any leftover text-input states so View-as-user flows work cleanly
            user_states.pop(int(real_uid), None)
            user_states.pop(int(target_id), None)
            try:
                await event.answer(f"Impersonating {target_id}", alert=True)
            except Exception:
                pass
            body = await db_call(render_dashboard_text, int(target_id))
            text = (
                f"<b>Impersonating</b> <code>{target_id}</code>" + chr(10)
                + "<i>Changes apply to this user. Tap Stop Impersonation to exit.</i>"
                + chr(10) * 2 + str(body)
            )
            buttons = main_dashboard_keyboard(int(target_id), viewer_id=real_uid)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data == "stop_impersonate":
            if not _is_adm:
                return
            try:
                _prev = _impersonate.get(int(real_uid))
                _write_impersonation_audit(
                    audit_col,
                    admin_id=int(real_uid),
                    target_id=int(_prev or 0),
                    action='stop_view_as',
                    detail='stop_impersonate',
                )
            except Exception:
                pass
            _impersonate.pop(int(real_uid), None)
            try:
                await event.answer("Impersonation ended", alert=True)
            except Exception:
                pass
            text = await db_call(render_dashboard_text, real_uid)
            buttons = main_dashboard_keyboard(real_uid, viewer_id=real_uid)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_set_settings_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_set_settings_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            text, buttons = admin_settings_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_settings_mode_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_settings_mode_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            text, buttons = admin_mode_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_settings_interval_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_settings_interval_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            text, buttons = admin_interval_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_settings_ads_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_settings_ads_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            text, buttons = admin_ads_mode_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_set_mode_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_set_mode_", "")
            parts = payload.split("_")
            target_id = int(parts[0])
            mode = parts[1] if len(parts) > 1 else "auto"
            source = parts[2] if len(parts) > 2 else "premium"
            await db_call(uupdate, {'user_id': target_id}, {'$set': {'forwarding_mode': mode}}, upsert=True)
            await event.answer("Mode updated", alert=True)
            text, buttons = admin_mode_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_set_interval_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_set_interval_", "")
            parts = payload.split("_")
            target_id = int(parts[0])
            preset = parts[1] if len(parts) > 1 else "medium"
            source = parts[2] if len(parts) > 2 else "premium"
            await db_call(uupdate, {'user_id': target_id}, {'$set': {'interval_preset': preset}}, upsert=True)
            await event.answer("Intervals updated", alert=True)
            text, buttons = admin_interval_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return


        if data.startswith("admin_msg_preset_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_msg_preset_", "")
            parts = payload.split("_")
            if len(parts) < 2:
                return
            target_id = int(parts[0])
            preset_key = parts[1]
            source = parts[2] if len(parts) > 2 else "premium"
            if preset_key not in INTERVAL_PRESETS:
                await event.answer("Invalid preset", alert=True)
                return
            await db_call(uupdate, {'user_id': target_id}, {
                '$set': {'interval_preset': preset_key},
                '$unset': {'custom_interval': '', 'msg_delay_sec': ''},
            })
            await event.answer(f"Msg speed: {preset_key} applied", alert=True)
            text, buttons = admin_interval_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_msg_custom_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_msg_custom_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            user_states[uid] = {'action': 'admin_custom_msg_delay', 'target_id': target_id, 'source': source}
            await event.edit(
                f"Custom message delay for <code>{target_id}</code>" + chr(10)*2 + "Enter seconds between groups (5-9999):",
                parse_mode='html',
                buttons=[[Button.inline("Back", f"admin_settings_interval_{target_id}_{source}")]],
            )
            return

        if data.startswith("admin_user_freq_off_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_user_freq_off_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            await db_call(uupdate, {'user_id': target_id}, {
                '$set': {'freq_disabled': True},
                '$unset': {'freq_per_hour': ''},
            })
            await event.answer("Frequency OFF for user", alert=True)
            text, buttons = admin_interval_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_user_freq_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_user_freq_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            user_states[uid] = {'action': 'admin_set_user_freq', 'target_id': target_id, 'source': source}
            await event.edit(
                f"Frequency cap for <code>{target_id}</code>" + chr(10)*2 + f"Enter max cycles/hour (1-{HARD_MAX_TARGET_PER_HOUR}), or 0 for global default:",
                parse_mode='html',
                buttons=[[Button.inline("Back", f"admin_settings_interval_{target_id}_{source}")]],
            )
            return

        if data == "admin_find_user":
            if not await db_call(is_admin, uid):
                return
            user_states[uid] = {'action': 'admin_find_user'}
            await event.edit(
                "Find user" + chr(10)*2 + "Send numeric user id or @username:",
                buttons=[[Button.inline("Back", b"admin_panel")]],
            )
            return

        if data.startswith("admin_cycle_") and not data.startswith("admin_cycle_custom_") and not data.startswith("admin_cycle_clear_"):
            # admin_cycle_{uid}_{sec}_{source}
            parts = data.split("_")
            # admin cycle TARGET SEC SOURCE
            try:
                target_id = int(parts[2])
                sec = int(parts[3])
                source = parts[4] if len(parts) > 4 else "all"
            except Exception:
                await event.answer("Invalid", alert=True)
                return
            if not await db_call(is_admin, uid):
                return
            await db_call(uupdate, {'user_id': target_id}, {'$set': {'cycle_interval_sec': sec}})
            await event.answer(f"Cycle interval {sec // 60} min for {target_id}", alert=True)
            t, b = admin_interval_menu(target_id, source)
            await event.edit(t, parse_mode='html', buttons=b)
            return

        if data.startswith("admin_cycle_clear_"):
            payload = data.replace("admin_cycle_clear_", "")
            try:
                target_id_s, source = payload.rsplit("_", 1)
                target_id = int(target_id_s)
            except Exception:
                await event.answer("Invalid", alert=True)
                return
            if not await db_call(is_admin, uid):
                return
            await db_call(uupdate, {'user_id': target_id}, {'$unset': {'cycle_interval_sec': ''}})
            await event.answer("Cycle override cleared", alert=True)
            t, b = admin_interval_menu(target_id, source)
            await event.edit(t, parse_mode='html', buttons=b)
            return

        if data.startswith("admin_cycle_custom_"):
            payload = data.replace("admin_cycle_custom_", "")
            try:
                target_id_s, source = payload.rsplit("_", 1)
                target_id = int(target_id_s)
            except Exception:
                await event.answer("Invalid", alert=True)
                return
            if not await db_call(is_admin, uid):
                return
            user_states[uid] = {'action': 'admin_cycle_interval_custom', 'target_id': target_id, 'source': source}
            await event.edit(
                f"⏱️ Custom cycle interval for <code>{target_id}</code>\n\nEnter minutes (1–1440):",
                parse_mode='html',
                buttons=[[Button.inline("← Back", f"admin_settings_interval_{target_id}_{source}")]],
            )
            return

        if data.startswith("admin_interval_custom_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_interval_custom_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            user_states[uid] = {'action': 'admin_custom_interval', 'step': 'msg_delay', 'target_id': target_id, 'source': source}
            await event.edit(
                "<b>Admin: Custom Interval</b>\n\n"
                f"<b>User ID:</b> <code>{target_id}</code>\n\n"
                "Enter message delay in seconds (5-9999):",
                parse_mode='html',
                buttons=[[Button.inline("Back", f"admin_settings_interval_{target_id}_{source}")]]
            )
            return

        if data.startswith("admin_set_ads_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_set_ads_", "")
            parts = payload.split("_")
            target_id = int(parts[0])
            mode = parts[1] if len(parts) > 1 else "saved"
            source = parts[2] if len(parts) > 2 else "premium"
            await db_call(uupdate, {'user_id': target_id}, {'$set': {'ads_mode': mode}}, upsert=True)
            await event.answer("Ads mode updated", alert=True)
            text, buttons = admin_ads_mode_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_settings_automation_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_settings_automation_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            text, buttons = admin_automation_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_menu_content_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_menu_content_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            text, buttons = admin_content_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_locked_smart_rotation_") or data.startswith("admin_locked_auto_group_join_"):
            if data.startswith("admin_locked_smart_rotation_"):
                payload = data.replace("admin_locked_smart_rotation_", "")
            else:
                payload = data.replace("admin_locked_auto_group_join_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0]) if parts and parts[0].isdigit() else uid
            source = parts[1] if len(parts) > 1 else "premium"
            await event.edit(
                "<b>Paid Plan Feature</b>\n\nUpgrade the user to unlock this feature.",
                parse_mode='html',
                buttons=[[Button.inline("Back", f"admin_settings_automation_{target_id}_{source}")]]
            )
            return

        if data.startswith("admin_locked_autoreply_") or data.startswith("admin_locked_topics_"):
            if data.startswith("admin_locked_autoreply_"):
                payload = data.replace("admin_locked_autoreply_", "")
            else:
                payload = data.replace("admin_locked_topics_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0]) if parts and parts[0].isdigit() else uid
            source = parts[1] if len(parts) > 1 else "premium"
            await event.edit(
                "<b>Paid Plan Feature</b>\n\nUpgrade the user to unlock this feature.",
                parse_mode='html',
                buttons=[[Button.inline("Back", f"admin_menu_content_{target_id}_{source}")]]
            )
            return

        if data.startswith("admin_toggle_smart_rotation_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_toggle_smart_rotation_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            user_doc = await db_call(get_user, target_id)
            new_val = not user_doc.get('smart_rotation', True)
            await db_call(uupdate, {'user_id': target_id}, {'$set': {'smart_rotation': new_val}}, upsert=True)
            await event.answer(f"Smart Rotation {'enabled' if new_val else 'disabled'}", alert=True)
            text, buttons = admin_automation_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_toggle_auto_leave_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_toggle_auto_leave_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            user_doc = await db_call(get_user, target_id)
            new_val = not user_doc.get('auto_leave_groups', True)
            await db_call(uupdate, {'user_id': target_id}, {'$set': {'auto_leave_groups': new_val}}, upsert=True)
            await event.answer(f"Auto Leave {'enabled' if new_val else 'disabled'}", alert=True)
            text, buttons = admin_automation_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_auto_group_join_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_auto_group_join_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            user_states[uid] = {'state': 'admin_awaiting_group_join_file', 'target_id': target_id, 'source': source}
            await event.edit(
                "<b>Admin: Auto Group Join</b>\n\n"
                "Upload a .txt file with group links (one per line).\n\n"
                "Supported:\n"
                "• https://t.me/groupname\n"
                "• t.me/groupname\n"
                "• @groupname",
                parse_mode='html',
                buttons=[[Button.inline("Back", f"admin_settings_automation_{target_id}_{source}")]]
            )
            return

        if data.startswith("admin_refresh_all_"):
            if not await db_call(is_admin, real_uid):
                return
            payload = data.replace("admin_refresh_all_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            accounts = await db_call(get_user_accounts, target_id)
            if not accounts:
                await event.answer("No accounts for this user.", alert=True)
                return
            try:
                await event.answer("Refreshing…")
            except Exception:
                pass
            _hint = (
                "<b>🔄 Refreshing groups for</b> <code>%s</code>\n"
                "<i>Batch %s · cooldown %sm</i>"
            ) % (target_id, REFRESH_BATCH_MAX, max(1, REFRESH_COOLDOWN_SEC // 60))
            progress_msg = await event.respond(_hint, parse_mode='html')
            results, remaining = await _refresh_accounts_safe(accounts, force=False)
            if results:
                result_text = "<b>🔄 Refresh Complete</b>\n\n" + "\n".join(results)
            else:
                result_text = "<b>❌ Nothing refreshed</b>"
            if remaining > 0:
                result_text += "\n\n<i>%s left — tap Refresh again.</i>" % remaining
            await progress_msg.edit(
                result_text,
                parse_mode='html',
                buttons=[[Button.inline(
                    "Back",
                    f"admin_settings_automation_{target_id}_{source}",
                )]],
            )
            return

        if data.startswith("admin_quiet_hours_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_quiet_hours_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            text, buttons = admin_quiet_hours_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_quiet_preset_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_quiet_preset_", "")
            parts = payload.split("_")
            target_id = int(parts[0])
            start = parts[1]
            end = parts[2]
            source = parts[3] if len(parts) > 3 else "premium"
            start = f"{start[:2]}:{start[2:]}"
            end = f"{end[:2]}:{end[2:]}"
            label = f"{start}-{end}"
            await db_call(uupdate, 
                {'user_id': int(target_id)},
                {'$set': {'quiet_hours': {'enabled': True, 'start': start, 'end': end, 'label': label}}},
                upsert=True
            )
            await event.answer("Quiet hours updated", alert=True)
            text, buttons = admin_quiet_hours_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_quiet_off_"):
            if not await db_call(is_admin, real_uid):
                return
            payload = data.replace("admin_quiet_off_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            await db_call(uupdate,
                {'user_id': int(target_id)},
                {'$set': {'quiet_hours': {'enabled': False, 'start': None, 'end': None, 'label': 'Off'}}},
                upsert=True,
            )
            await event.answer("Quiet hours OFF for user", alert=True)
            text, buttons = admin_quiet_hours_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_quiet_custom_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_quiet_custom_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            user_states[uid] = {'action': 'admin_quiet_hours', 'step': 'start', 'target_id': target_id, 'source': source}
            await event.edit(
                "<b>Admin: Quiet Hours - Custom</b>\n\n"
                f"<b>User ID:</b> <code>{target_id}</code>\n\n"
                "Send the start time in 24h format (HH:MM).",
                parse_mode='html',
                buttons=[[Button.inline("Back", f"admin_quiet_hours_{target_id}_{source}")]]
            )
            return

        if data.startswith("admin_menu_autoreply_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_menu_autoreply_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            text, buttons = admin_autoreply_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_autoreply_toggle_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_autoreply_toggle_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            user_doc = await db_call(get_user, target_id)
            new_val = not user_doc.get('autoreply_enabled', False)
            await db_call(uupdate, {'user_id': int(target_id)}, {'$set': {'autoreply_enabled': new_val}}, upsert=True)
            await event.answer("Auto reply updated", alert=True)
            text, buttons = admin_autoreply_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_autoreply_set_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_autoreply_set_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            user_states[uid] = {'action': 'admin_custom_autoreply', 'target_id': target_id, 'source': source}
            await event.edit(
                "<b>Admin: Set Auto Reply</b>\n\n"
                f"<b>User ID:</b> <code>{target_id}</code>\n\n"
                "Send the auto-reply message.",
                parse_mode='html',
                buttons=[[Button.inline("Back", f"admin_menu_autoreply_{target_id}_{source}")]]
            )
            return

        if data.startswith("admin_autoreply_view_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_autoreply_view_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            accounts = await db_call(get_user_accounts, target_id)
            reply = None
            if accounts:
                _ids = [str(acc['_id']) for acc in accounts]
                _d = account_settings_col.find_one(
                    {'account_id': {'$in': _ids}, 'auto_reply': {'$exists': True}}, {'auto_reply': 1})
                if _d:
                    reply = _d.get('auto_reply')
            preview = _h(reply) if reply else "<i>Not set</i>"
            await event.edit(
                f"<b>Admin: Auto Reply</b>\n\n{preview}",
                parse_mode='html',
                buttons=[[Button.inline("Back", f"admin_menu_autoreply_{target_id}_{source}")]]
            )
            return

        if data.startswith("admin_menu_logs_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_menu_logs_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            text, buttons = admin_logs_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_logs_enable_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_logs_enable_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            await db_call(uupdate, {'user_id': int(target_id)}, {'$set': {'logs_chat_id': int(target_id)}}, upsert=True)
            invalidate_logs_cache()
            await event.answer("Logs enabled", alert=True)
            text, buttons = admin_logs_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_logs_disable_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_logs_disable_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            await db_call(uupdate, {'user_id': int(target_id)}, {'$unset': {'logs_chat_id': ""}})
            invalidate_logs_cache()
            await event.answer("Logs disabled", alert=True)
            text, buttons = admin_logs_menu(target_id, source)
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_menu_topics_"):
            if not await db_call(is_admin, uid):
                return
            payload = data.replace("admin_menu_topics_", "")
            parts = payload.split("_", 1)
            target_id = int(parts[0])
            source = parts[1] if len(parts) > 1 else "premium"
            accounts = await db_call(get_user_accounts, target_id)
            if not accounts:
                await event.answer("Add an account first!", alert=True)
                return
            tier_settings = await db_call(get_user_tier_settings, target_id)
            max_topics = tier_settings.get('max_topics', 3)
            text = (
                "<b>🏷️ Topics</b>\n\n"
                "<blockquote>Select a topic to add group links.</blockquote>\n\n"
                f"<b>Available topics:</b> <code>{max_topics}/{len(TOPICS)}</code>"
            )
            if not await db_call(is_premium, target_id):
                text += "\n\n<i>Upgrade to a paid plan for all topics.</i>"
            buttons = []
            _tlist = list(TOPICS[:max_topics])
            _tcounts = await db_call(bulk_topic_counts, accounts, _tlist)
            for topic in _tlist:
                count = _tcounts.get(topic, 0)
                buttons.append([Button.inline(f"{topic.title()} ({count} groups)", f"admin_topic_select_{target_id}_{topic}_{source}")])
            buttons.append([Button.inline("Back", f"admin_menu_content_{target_id}_{source}")])
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_topic_select_"):
            payload = data.replace("admin_topic_select_", "")
            parts = payload.split("_", 2)
            target_id = int(parts[0])
            topic = parts[1]
            source = parts[2] if len(parts) > 2 else "premium"
            accounts = await db_call(get_user_accounts, target_id)
            tier_settings = await db_call(get_user_tier_settings, target_id)
            max_groups = tier_settings.get('max_groups_per_topic', 10)
            if len(accounts) == 1:
                acc = accounts[0]
                groups = await db_call(lambda: list(account_topics_col.find({'account_id': acc['_id'], 'topic': topic})))
                text = (
                    f"<b>{_h(topic.title())}</b>\n\n"
                    f"<b>Groups:</b> <code>{len(groups)}/{max_groups}</code>\n\n"
                    "<b>Send topic link to add:</b>\n"
                    "<code>https://t.me/groupname/5</code>"
                )
                buttons = [[Button.inline("View Groups", f"admin_view_topic_groups_{target_id}_{topic}_{acc['_id']}_{source}")]] if groups else []
                buttons.append([Button.inline("Back", f"admin_menu_topics_{target_id}_{source}")])
                msg = await event.edit(text, parse_mode='html', buttons=buttons)
                user_states[uid] = {'action': 'admin_add_topic_link', 'topic': topic, 'account_id': acc['_id'], 'target_id': target_id, 'source': source, 'last_msg_id': msg.id if hasattr(msg, 'id') else event.message_id}
            else:
                text = f"<b>{_h(topic.title())}</b>\n\n<i>Select account to add groups:</i>"
                buttons = []
                _aids = [acc['_id'] for acc in accounts]
                _agg = await db_call(lambda: list(account_topics_col.aggregate([
                    {'$match': {'account_id': {'$in': _aids}, 'topic': topic}},
                    {'$group': {'_id': '$account_id', 'n': {'$sum': 1}}},
                ]))) if _aids else []
                _cba = {str(d['_id']): d['n'] for d in _agg}
                for acc in accounts:
                    phone = acc['phone'][-4:]
                    name = acc.get('name', 'Unknown')[:12]
                    count = _cba.get(str(acc['_id']), 0)
                    buttons.append([Button.inline(f"{phone} - {name} ({count})", f"admin_topic_acc_{target_id}_{topic}_{acc['_id']}_{source}")])
                buttons.append([Button.inline("Back", f"admin_menu_topics_{target_id}_{source}")])
                await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_topic_acc_"):
            payload = data.replace("admin_topic_acc_", "")
            parts = payload.split("_", 3)
            target_id = int(parts[0])
            topic = parts[1]
            acc_id = parts[2]
            source = parts[3] if len(parts) > 3 else "premium"
            tier_settings = await db_call(get_user_tier_settings, target_id)
            max_groups = tier_settings.get('max_groups_per_topic', 10)
            groups = await db_call(lambda: list(account_topics_col.find({'account_id': acc_id, 'topic': topic})))
            text = (
                f"<b>🏷️ {topic.title()}</b>\n\n"
                f"<b>Groups:</b> <code>{len(groups)}/{max_groups}</code>\n\n"
                "<i>Send a topic link to add.</i>\n"
                "<code>Example: https://t.me/groupname/5</code>"
            )
            buttons = [[Button.inline("👁️ View Groups", f"admin_view_topic_groups_{target_id}_{topic}_{acc_id}_{source}")]] if groups else []
            buttons.append([Button.inline("← Back", f"admin_topic_select_{target_id}_{topic}_{source}")])
            msg = await event.edit(text, parse_mode='html', buttons=buttons)
            user_states[uid] = {'action': 'admin_add_topic_link', 'topic': topic, 'account_id': acc_id, 'target_id': target_id, 'source': source, 'last_msg_id': msg.id if hasattr(msg, 'id') else event.message_id}
            return

        if data.startswith("admin_view_topic_groups_"):
            payload = data.replace("admin_view_topic_groups_", "")
            parts = payload.split("_", 3)
            target_id = int(parts[0])
            topic = parts[1]
            acc_id = parts[2]
            source = parts[3] if len(parts) > 3 else "premium"
            groups = await db_call(lambda: list(account_topics_col.find({'account_id': acc_id, 'topic': topic})))
            total = len(groups)
            display_limit = 5
            text = f"<b>🏷️ {topic.title()} Groups</b> <code>({total} total)</code>\n\n"
            for i, g in enumerate(groups[:display_limit]):
                title = g.get('title', g.get('url', 'Unknown'))[:25]
                text += f"{i+1}. {title}\n"
            if total > display_limit:
                text += f"\n...and {total - display_limit} more groups"
            buttons = [
                [Button.inline("Clear All", f"admin_clear_topic_{target_id}_{topic}_{acc_id}_{source}")],
                [Button.inline("Back", f"admin_topic_select_{target_id}_{topic}_{source}")]
            ]
            await event.edit(text, parse_mode='html', buttons=buttons)
            return

        if data.startswith("admin_clear_topic_"):
            payload = data.replace("admin_clear_topic_", "")
            parts = payload.split("_", 3)
            target_id = int(parts[0])
            topic = parts[1]
            acc_id = parts[2]
            source = parts[3] if len(parts) > 3 else "premium"
            await db_call(account_topics_col.delete_many, {'account_id': acc_id, 'topic': topic})
            await event.answer(f"Cleared all {topic} groups!", alert=True)
            await event.edit(
                f"<b>🏷️ {topic.title()}</b>\n\n<b>Groups:</b> <code>0</code>\n\n<i>Send a group link to add.</i>",
                parse_mode='html',
                buttons=[[Button.inline("← Back", f"admin_menu_topics_{target_id}_{source}")]]
            )
            return
        
        if data.startswith("admin_grant_premium_"):
            if not await db_call(is_admin, uid):
                return
            
            target_id = int(data.replace("admin_grant_premium_", ""))
            
            # Show plan selection screen
            text = (
                f"<b>Grant Plan</b>\n\n"
                f"<b>User ID:</b> <code>{target_id}</code>\n\n"
                f"<i>Select a plan to grant (30 days):</i>\n\n"
                f"<b>📈 Starter:</b> 2 accounts, medium speed\n"
                f"<b>⭐ Pro:</b> 3 accounts, fast speed\n"
                f"<b>👑 Elite:</b> 4 accounts, fastest speed"
            )
            
            buttons = [
                [Button.inline("📈 Starter", f"admin_grant_grow_{target_id}")],
                [Button.inline("⭐ Pro", f"admin_grant_prime_{target_id}")],
                [Button.inline("👑 Elite", f"admin_grant_dominion_{target_id}")],
                [Button.inline("← Back", f"admin_user_detail_{target_id}")]
            ]
            
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        
        # Handle individual plan grants
        if data.startswith("admin_grant_scout_"):
            if not await db_call(is_admin, uid):
                return
            
            target_id = int(data.replace("admin_grant_scout_", ""))
            await event.answer("Plan unavailable.", alert=True)
            await event.edit(
                f"<b>Plan Unavailable</b>\n\n<i>User {target_id} cannot be granted the legacy plan.</i>",
                parse_mode='html',
                buttons=[[Button.inline("← Back to Users", b"admin_all_users")]]
            )
            return
        
        if data.startswith("admin_grant_grow_"):
            if not await db_call(is_admin, uid):
                return
            
            target_id = int(data.replace("admin_grant_grow_", ""))
            days = 30
            
            try:
                # Use centralized function - handles DB, user notification, AND channel notification
                await grant_premium_to_user(target_id, 'grow', days, source='admin_user_profile')
                
                await event.answer("✅ Starter plan granted!", alert=True)
                await event.edit(
                    f"<b>✅ Plan Granted</b>\n\n<i>User {target_id} now has Starter plan access (30 days).</i>",
                    parse_mode='html',
                    buttons=[[Button.inline("← Back to Users", b"admin_all_users")]]
                )
            except Exception as e:
                await event.answer(f"❌ Error: {str(e)[:50]}", alert=True)
                print(f"[ADMIN] Failed to grant Starter to {target_id}: {e}")
            return
        
        if data.startswith("admin_grant_prime_"):
            if not await db_call(is_admin, uid):
                return
            
            target_id = int(data.replace("admin_grant_prime_", ""))
            days = 30
            
            try:
                # Use centralized function - handles DB, user notification, AND channel notification
                await grant_premium_to_user(target_id, 'prime', days, source='admin_user_profile')
                
                await event.answer("✅ Pro plan granted!", alert=True)
                await event.edit(
                    f"<b>✅ Plan Granted</b>\n\n<i>User {target_id} now has Pro plan access (30 days).</i>",
                    parse_mode='html',
                    buttons=[[Button.inline("← Back to Users", b"admin_all_users")]]
                )
            except Exception as e:
                await event.answer(f"❌ Error: {str(e)[:50]}", alert=True)
                print(f"[ADMIN] Failed to grant Pro to {target_id}: {e}")
            return
        
        if data.startswith("admin_grant_dominion_"):
            if not await db_call(is_admin, uid):
                return
            
            target_id = int(data.replace("admin_grant_dominion_", ""))
            days = 30
            
            try:
                # Use centralized function - handles DB, user notification, AND channel notification
                await grant_premium_to_user(target_id, 'dominion', days, source='admin_user_profile')
                
                await event.answer("✅ Elite plan granted!", alert=True)
                await event.edit(
                    f"<b>✅ Plan Granted</b>\n\n<i>User {target_id} now has Elite plan access (30 days).</i>",
                    parse_mode='html',
                    buttons=[[Button.inline("← Back to Users", b"admin_all_users")]]
                )
            except Exception as e:
                await event.answer(f"❌ Error: {str(e)[:50]}", alert=True)
                print(f"[ADMIN] Failed to grant Elite to {target_id}: {e}")
            return
        
        if data.startswith("admin_revoke_premium_"):
            if not await db_call(is_admin, uid):
                return
            
            target_id = int(data.replace("admin_revoke_premium_", ""))
            await db_call(remove_user_premium, target_id)
            try:
                await db_call(_write_audit, admin_audit_col, uid, 'revoke_premium', target_id)
            except Exception:
                pass
            await event.answer("❌ Premium revoked!", alert=True)
            
            await event.edit(
                f"<b>❌ Premium Revoked</b>\n\n<i>User {target_id} now has no active plan.</i>",
                parse_mode='html',
                buttons=[[Button.inline("← Back to Premium Users", b"admin_premium")]]
            )
            return
        
        if data == "admin_premium":
            if not await db_call(is_admin, uid):
                return
            
            users = await db_call(get_premium_users)
            text = f"<b>\U0001F451 Premium Users</b> <code>({len(users) if users else 0} total)</code>\n\n"
            
            buttons = []
            if not users:
                text += "<i>No premium users yet.</i>"
            else:
                for u in users[:20]:
                    user_id = u.get('user_id')
                    max_acc = get_plan_max_accounts(u)
                    acc_count = await db_call(accounts_col.count_documents, {'owner_id': user_id})
                    username = u.get('username')
                    label_id = f"@{username}" if username else str(user_id)
                    label = f"\U0001F451 {label_id} ({acc_count}/{max_acc} acc)"
                    buttons.append([Button.inline(label, f"admin_user_detail_{user_id}")])
            
            buttons.append([Button.inline("← Back", b"admin_panel")])
            
            await event.edit(text, parse_mode='html', buttons=buttons)
            return
        
        if data == "admin_stats":
            if not await db_call(is_admin, uid):
                return
            
            total_sent = 0
            total_failed = 0
            total_auto_replies = 0
            for stat in await db_call(lambda: list(account_stats_col.find({}, {'total_sent': 1, 'total_failed': 1, 'auto_replies': 1}))):
                total_sent += stat.get('total_sent', 0)
                total_failed += stat.get('total_failed', 0)
                total_auto_replies += stat.get('auto_replies', 0)
            
            text = f"**Bot Statistics**\n\n"
            text += f"Total Messages Sent: {total_sent}\n"
            text += f"Total Failed: {total_failed}\n"
            text += f"Success Rate: {(total_sent / max(1, total_sent + total_failed) * 100):.1f}%\n"
            text += f"Total Auto Replies: {total_auto_replies}"
            
            await event.edit(text, buttons=[[Button.inline("Back", b"admin_panel")]])
            return
        
        if data == "admin_broadcast":
            if not await db_call(is_admin, uid):
                return
            
            _put_flow_state(real_uid, uid, {'action': 'broadcast'})
            await event.respond("Send the message to broadcast to all users:")
            return
        
        if data.startswith("page_"):
            page = int(data.split("_")[1])
            accounts = await db_call(get_user_accounts, uid)
            max_acc = await db_call(get_user_max_accounts, uid)
            tier_settings = await db_call(get_user_tier_settings, uid)
            tier = "Premium" if await db_call(is_premium, uid) else "No Plan"
            
            text = f"**{tier} Hub** (Page {page+1})\n\nAccounts: {len(accounts)}/{max_acc}"
            await event.edit(text, buttons=await db_call(account_list_keyboard, uid, page))
            return
        
        if data.startswith("acc_"):
            account_id = data.split("_")[1]
            acc = await db_call(get_account_by_id, account_id)
            if not acc:
                await event.answer("Not found!", alert=True)
                return

            # Session-dead: always show fix panel (all plans)
            if acc.get('auth_invalid'):
                phone = acc.get('phone') or '?'
                await event.edit(
                    f"<b>⚠️ Session dead</b>\n\n"
                    f"Phone: <code>{phone}</code>\n"
                    f"This account's Telegram session is invalid or revoked.\n"
                    f"Forwarding is stopped until you re-login.\n\n"
                    f"<b>Fix:</b> Delete this account, then <b>Add Account</b> again "
                    f"with the same number.",
                    parse_mode='html',
                    buttons=[
                        [Button.inline("🗑 Delete account", f"delete_{account_id}")],
                        [Button.inline("← Accounts", b"menu_account")],
                    ],
                )
                return
            
            # Check if user has per-account config access (Pro/Elite)
            if not has_per_account_config_access(uid):
                await event.answer("Per-account config is a Pro/Elite feature!", alert=True)
                await event.edit(
                    "🔒 **Per-Account Configuration**\n\n"
                    "This feature allows you to customize settings for each account individually.\n\n"
                    "Available in:\n"
                    "• Pro Plan (₹299)\n"
                    "• Elite Plan (₹399)\n\n"
                    "Use main dashboard settings to control all accounts together.",
                    buttons=[[Button.inline("⬆️ Upgrade Plan", b"go_premium")], [Button.inline("🏠 Dashboard", b"enter_dashboard")]]
                )
                return
            
            # Batch the 4 panel reads into ONE off-loop hop (was 4 blocking calls/tap).
            def _acc_panel_data():
                return (
                    get_account_stats(account_id),
                    get_account_settings(account_id),
                    account_topics_col.count_documents({'account_id': account_id}),
                    account_auto_groups_col.count_documents({'account_id': account_id}),
                )
            stats, settings, topics, groups = await db_call(_acc_panel_data)
            
            status = "🟢 Running" if acc.get('is_forwarding') else "🔴 Stopped"
            
            # Get user-level intervals
            user_doc = await db_call(get_user, uid)
            preset = user_doc.get('interval_preset', 'medium')
            if preset == 'custom':
                custom = user_doc.get('custom_interval', {})
                msg_d = custom.get('msg_delay', 30)
                round_d = custom.get('round_delay', 600)
            else:
                interval_data = INTERVAL_PRESETS.get(preset, INTERVAL_PRESETS['medium'])
                msg_d = interval_data['msg_delay']
                round_d = interval_data['round_delay']
            
            text = (
                "<b>📱 Account Details</b>\n\n"
                "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
                "<b>📋 Account Info:</b>\n"
                f"├ <b>Phone:</b> <code>{acc['phone']}</code>\n"
                f"├ <b>Name:</b> <code>{acc.get('name', 'Unknown')}</code>\n"
                f"└ <b>Status:</b> {status}\n\n"
                "<b>📊 Statistics:</b>\n"
                f"├ <b>Topics:</b> <code>{topics}</code>\n"
                f"├ <b>Groups:</b> <code>{groups}</code>\n"
                f"├ <b>✅ Messages Sent:</b> <code>{stats.get('total_sent', 0)}</code>\n"
                f"└ <b>❌ Failed:</b> <code>{stats.get('total_failed', 0)}</code>\n\n"
                "<b>⏱️ Interval Settings:</b>\n"
                f"├ <b>⏰ Message Delay:</b> <code>{msg_d}s</code>\n"
                f"└ <b>🔄 Cycle Delay:</b> <code>{round_d}s</code>\n\n"
                "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
            )
            
            await event.edit(text, parse_mode='html', buttons=account_menu_keyboard(account_id, acc, uid))
            return
        
        if data.startswith("topics_"):
            account_id = data.split("_")[1]
            acc = get_account_by_id(account_id)
            await event.edit(
                f"<b> Topics</b>\n<blockquote>Account: <code>{_h(acc['phone'])}</code></blockquote>",
                parse_mode='html',
                buttons=topics_menu_keyboard(account_id, uid)
            )
            return
        
        if data.startswith("topic_"):
            parts = data.split("_")
            account_id, topic = parts[1], parts[2]
            
            tier_settings = await db_call(get_user_tier_settings, uid)
            max_groups = tier_settings.get('max_groups_per_topic', 10)
            
            links = await db_call(lambda: list(account_topics_col.find({'account_id': {'$in': _account_id_variants(account_id)}, 'topic': topic})))
            text = f"**{topic.capitalize()}** ({len(links)}/{max_groups} links)\n\n"
            
            for i, l in enumerate(links[:15], 1):
                text += f"{i}. {l['url']}\n"
            if len(links) > 15:
                text += f"...+{len(links)-15} more"
            
            if not links:
                text += "No links yet."
            
            await event.edit(text, buttons=[
                [Button.inline("Add", f"add_{account_id}_{topic}"), Button.inline("Clear", f"clear_{account_id}_{topic}")],
                [Button.inline("Back", f"topics_{account_id}")]
            ])
            return
        
        if data.startswith("auto_"):
            account_id = data.split("_")[1]
            groups = list(account_auto_groups_col.find({'account_id': {'$in': _account_id_variants(account_id)}}))
            
            text = f"**Auto Groups** ({len(groups)})\n\n"
            for i, g in enumerate(groups[:15], 1):
                u = f"@{g['username']}" if g.get('username') else "Private"
                text += f"{i}. {g['title'][:20]} ({u})\n"
            if len(groups) > 15:
                text += f"...+{len(groups)-15} more"
            
            await event.edit(text, buttons=[[Button.inline("Back", f"topics_{account_id}")]])
            return
        
        if data.startswith("add_"):
            parts = data.split("_")
            account_id, topic = parts[1], parts[2]
            _put_flow_state(real_uid, uid, {'action': 'add_links', 'account_id': account_id, 'topic': topic})
            await event.respond(f"Send links for **{topic}** (one per line):")
            return
        
        if data.startswith("clear_"):
            parts = data.split("_")
            account_id, topic = parts[1], parts[2]
            result = await db_call(account_topics_col.delete_many, {'account_id': {'$in': _account_id_variants(account_id)}, 'topic': topic})
            await event.answer(f"Deleted {result.deleted_count} links!")
            return
        
        if data.startswith("settings_"):
            account_id = data.split("_")[1]
            settings = get_account_settings(account_id)
            
            # Get user-level intervals
            user_doc = await db_call(get_user, uid)
            preset = user_doc.get('interval_preset', 'medium')
            if preset == 'custom':
                custom = user_doc.get('custom_interval', {})
                msg_d = custom.get('msg_delay', 30)
                round_d = custom.get('round_delay', 600)
            else:
                interval_data = INTERVAL_PRESETS.get(preset, INTERVAL_PRESETS['medium'])
                msg_d = interval_data['msg_delay']
                round_d = interval_data['round_delay']
            
            text = "**Settings**\n\n"
            text += f"ᴍᴇꜱꜱᴀɢᴇ ᴅᴇʟᴀʏ: {msg_d}ꜱ\n"
            text += f"ʀᴏᴜɴᴅ ᴅᴇʟᴀʏ: {round_d}ꜱ\n"
            
            tier_settings = await db_call(get_user_tier_settings, uid)
            if tier_settings.get('auto_reply_enabled'):
                auto_reply_text = settings.get('auto_reply', 'ᴅᴇꜰᴀᴜʟᴛ')
                if auto_reply_text and auto_reply_text != 'ᴅᴇꜰᴀᴜʟᴛ':
                    text += f"ᴀᴜᴛᴏ-ʀᴇᴘʟʏ: {auto_reply_text[:40]}...\n"
                else:
                    text += f"ᴀᴜᴛᴏ-ʀᴇᴘʟʏ: ᴅᴇꜰᴀᴜʟᴛ...\n"
            
            failed = account_failed_groups_col.count_documents({'account_id': account_id})
            text += f"ꜰᴀɪʟᴇᴅ ɢʀᴏᴜᴘꜱ: {failed}"
            
            await event.edit(text, parse_mode='markdown', buttons=settings_keyboard(account_id, uid))
            return
        # setmsg_ and setround_ removed: intervals are now user-level only (Settings -> Intervals)
        
        if data.startswith("setreply_"):
            tier_settings = await db_call(get_user_tier_settings, uid)
            if not tier_settings.get('auto_reply_enabled'):
                await event.answer("Paid plan feature!", alert=True)
                return
            account_id = data.split("_")[1]
            _put_flow_state(real_uid, uid, {'action': 'set_reply', 'account_id': account_id})
            await event.respond("Send new auto-reply message:")
            return
        
        if data.startswith("clearfailed_"):
            account_id = data.split("_")[1]
            clear_failed_groups(account_id)
            await event.answer("Cleared failed groups!")
            return
        
        if data.startswith("stats_"):
            account_id = data.split("_")[1]
            acc = get_account_by_id(account_id)
            stats = get_account_stats(account_id)
            failed = account_failed_groups_col.count_documents({'account_id': account_id})
            
            last = stats.get('last_forward')
            last_time = last.strftime('%Y-%m-%d %H:%M') if last else 'Never'
            
            total_sent = stats.get('total_sent', 0)
            total_failed = stats.get('total_failed', 0)
            total_attempts = total_sent + total_failed
            success_rate = (total_sent / total_attempts * 100) if total_attempts > 0 else 0
            
            text = (
                f"<b>📊 Account Statistics</b>\n\n"
                "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
                f"<b>📱 Account:</b> <code>{acc['phone']}</code>\n\n"
                "<b>📈 Message Statistics:</b>\n"
                f"├ <b>✅ Messages Sent:</b> <code>{total_sent}</code>\n"
                f"├ <b>❌ Messages Failed:</b> <code>{total_failed}</code>\n"
                f"├ <b>⏭️ Skipped Groups:</b> <code>{failed}</code>\n"
                f"└ <b>📊 Success Rate:</b> <code>{success_rate:.1f}%</code>\n\n"
                "<b>⏰ Last Activity:</b>\n"
                f"└ <b>Last Forward:</b> <code>{last_time}</code>\n\n"
                "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
            )
            
            await event.edit(text, parse_mode='html', buttons=[
                [Button.inline("🔄 Reset Stats", f"reset_{account_id}")],
                [Button.inline("← Back", f"acc_{account_id}")]
            ])
            return
        
        if data.startswith("reset_"):
            account_id = data.split("_")[1]
            account_stats_col.update_one(
                {'account_id': account_id},
                {'$set': {'total_sent': 0, 'total_failed': 0}},
                upsert=True
            )
            await event.answer("Stats reset!")
            return
        
        if data.startswith("refresh_"):
            account_id = data.split("_")[1]
            acc = get_account_by_id(account_id)
            
            await event.answer("Refreshing groups...", alert=False)
            
            try:
                session = cipher_suite.decrypt(acc['session'].encode()).decode()
                client = TelegramClient(StringSession(session), CONFIG['api_id'], CONFIG['api_hash'])
                await client.connect()
                
                if await client.is_user_authorized():
                    count = await fetch_groups(client, account_id, acc['phone'])
                    await send_log(account_id, f"<b>Groups refreshed:</b> <code>{count}</code>")
                    await client.disconnect()
                    await event.answer(f"Found {count} groups!", alert=True)
                    await event.edit(f"<b>Refresh Groups</b>\n\n<b>Found:</b> <code>{count}</code>", parse_mode='html', buttons=[[Button.inline("Back", f"acc_{account_id}")]])
                else:
                    await event.answer("Session expired!", alert=True)
            except Exception as e:
                await event.answer("Error!", alert=True)
            return
        
        if data.startswith("fwd_select_"):
            account_id = data.split("_")[2]
            await event.edit("**Start Forwarding**\n\nSelect where to forward:", buttons=forwarding_select_keyboard(account_id, uid))
            return
        
        if data.startswith("startfwd_"):
            parts = data.split("_")
            account_id = parts[1]
            topic = parts[2] if len(parts) > 2 else "all"
            
            acc = get_account_by_id(account_id)
            if not acc:
                await event.answer("Account not found!", alert=True)
                return
            accounts_col.update_one({'_id': acc['_id']}, {'$set': {'is_forwarding': True, 'fwd_topic': topic}})
            ensure_account_running(acc.get('owner_id', uid), acc['_id'])
            
            await event.answer("Started!")
            await event.edit(f"Forwarding started!\n\nTopic: {topic}", buttons=[[Button.inline("Back", f"acc_{account_id}")]])
            return
        
        if data.startswith("stop_"):
            account_id = data.split("_")[1]
            acc = get_account_by_id(account_id)
            
            accounts_col.update_one({'_id': acc['_id']}, {'$set': {'is_forwarding': False}})
            try:
                invalidate_accounts_cache(acc.get('owner_id'))
            except Exception:
                pass
            
            ensure_account_stopped(acc['_id'])
            
            if account_id in auto_reply_clients:
                try:
                    await auto_reply_clients[account_id].disconnect()
                except Exception:
                    pass
                del auto_reply_clients[account_id]
            
            # Send log message to user (not per account)
            try:
                user_doc = await db_call(get_user, uid)
                logs_chat_id = user_doc.get('logs_chat_id')
                if logs_chat_id and CONFIG.get('logger_bot_token'):
                    log_msg = (
                        f"<b>⏹️ Ads Stopped</b>\n\n"
                        f"<b>Account:</b> <code>{acc.get('phone', 'Unknown')}</code>\n\n"
                        f"<i>Advertising has been stopped by user.</i>"
                    )
                    await _tg_send_http(CONFIG['logger_bot_token'], int(logs_chat_id), log_msg)
                    print(f"[STOP] Stop log sent to user {uid} for account {account_id}")
            except Exception as e:
                print(f"[LOG ERROR] Failed to send stop log to user {uid}: {e}")
            
            await event.answer("Stopped!")
            await event.edit("Forwarding stopped!", buttons=[[Button.inline("Back", f"acc_{account_id}")]])
            return
        
        # (Removed legacy per-account log toggles; logs are user-level via menu_logs)
        
        if data.startswith("delete_"):
            account_id = data.split("_")[1]
            await event.edit(
                "**Delete this account?**\n\nAll data will be removed!",
                buttons=[
                    [Button.inline("Yes", f"confirm_{account_id}"), Button.inline("No", f"acc_{account_id}")]
                ]
            )
            return
        
        if data.startswith("confirm_"):
            account_id = data.split("_")[1]
            acc = get_account_by_id(account_id)
            
            if acc:
                from bson.objectid import ObjectId
                accounts_col.delete_one({'_id': ObjectId(account_id)})
                account_topics_col.delete_many({'account_id': {'$in': _account_id_variants(account_id)}})
                account_settings_col.delete_many({'account_id': {'$in': _account_id_variants(account_id)}})
                account_stats_col.delete_many({'account_id': {'$in': _account_id_variants(account_id)}})
                account_auto_groups_col.delete_many({'account_id': {'$in': _account_id_variants(account_id)}})
                account_failed_groups_col.delete_many({'account_id': {'$in': _account_id_variants(account_id)}})
                logger_tokens_col.delete_many({'account_id': {'$in': _account_id_variants(account_id)}})
                
                ensure_account_stopped(acc['_id'])
                
                if account_id in auto_reply_clients:
                    try:
                        await auto_reply_clients[account_id].disconnect()
                    except Exception:
                        pass
                    del auto_reply_clients[account_id]
            
            await event.answer("Deleted!")
            await event.edit("**Dashboard**", buttons=await db_call(account_list_keyboard, uid))
            return
        
        if data == "host":
            if not await db_call(is_approved, uid):
                approve_user(uid)
            
            accounts = await db_call(get_user_accounts, uid)
            max_accounts = await db_call(get_user_max_accounts, uid)
            
            if len(accounts) >= max_accounts:
                if await db_call(is_premium, uid):
                    await event.answer(f"Limit reached ({max_accounts})", alert=True)
                else:
                    await event.answer("Upgrade to a paid plan for more accounts!", alert=True)
                return
            
            _put_flow_state(real_uid, uid, {'action': 'phone', 'owner_id': uid})
            await event.respond("Send phone with country code:\n\nExample: `+919876543210`")
            return
        
        if data.startswith("otp_"):
            if uid not in user_states or user_states[uid].get('action') != 'otp':
                return
            
            digit = data.split("_")[1]
            otp = user_states[uid].get('otp', '')
            
            if digit == "cancel":
                if 'client' in user_states[uid]:
                    await user_states[uid]['client'].disconnect()
                del user_states[uid]
                await event.answer("Cancelled!")
                await event.delete()
                return
            elif digit == "back":
                otp = otp[:-1]
            else:
                otp += digit
            
            user_states[uid]['otp'] = otp
            
            if len(otp) == 5:
                await event.edit(f"Code: `{otp}`\n\nVerifying...")
                
                client = None
                try:
                    client = user_states.get(uid, {}).get('client')
                    if not client:
                        raise RuntimeError('Session expired. Please request OTP again.')
                    
                    await client.sign_in(user_states[uid]['phone'], otp, phone_code_hash=user_states[uid]['hash'])
                    
                    me = await client.get_me()
                    session = client.session.save()
                    encrypted = cipher_suite.encrypt(session.encode()).decode()
                    owner_id = int(user_states[uid].get('owner_id', uid))
                    
                    result = await db_call(lambda: accounts_col.insert_one({
                        'owner_id': owner_id,
                        'phone': user_states[uid]['phone'],
                        'name': me.first_name or 'Unknown',
                        'session': encrypted,
                        'is_forwarding': False,
                        'auth_invalid': False,
                        'last_error': '',
                        'last_error_code': '',
                        'last_error_at': None,
                        'two_fa_password': user_states[uid].get('two_fa_password', ''),
                        'added_at': datetime.now()
                    }))
                    
                    account_id = str(result.inserted_id)
                    count = await fetch_groups(client, account_id, user_states[uid]['phone'])
                    
                    try:
                        await client.disconnect()
                    except Exception:
                        pass
                    
                    # Capture phone before clearing state
                    account_phone = user_states.get(uid, {}).get('phone', '')

                    if uid in user_states:
                        del user_states[uid]
                    
                    print(f"[ACCOUNT] Added account for user {owner_id}, fetched {count} groups")

                    # Send account added notification to channel
                    try:
                        user = await db_call(get_user, owner_id)
                        sender = await event.get_sender()
                        total_accounts = await db_call(accounts_col.count_documents, {'owner_id': owner_id})
                        plan_name = get_display_plan_name(user)
                        max_accounts = await db_call(get_user_max_accounts, owner_id)

                        print(f"[ACCOUNT] Triggering notification for user {owner_id}, phone {account_phone}")
                        task = _spawn_bg(notify_account_added(
                            owner_id, sender.username, getattr(sender, 'phone', None),
                            account_phone, plan_name, total_accounts, max_accounts
                        ))
                        task.add_done_callback(lambda t: print(f"[ACCOUNT] Notification task completed: {t.exception() if t.exception() else 'Success'}"))
                    except Exception as e:
                        print(f"[NOTIFICATION] Error creating notification task (OTP callback flow): {e}")

                    if owner_id != uid:
                        await event.edit(
                            f"**Account Added for {owner_id}!**\n\n{me.first_name}\nFound {count} groups",
                            buttons=[[Button.inline("Back to User", f"admin_user_detail_{owner_id}")]]
                        )
                    else:
                        await event.edit(
                            f"**Account Added!**\n\n{me.first_name}\nFound {count} groups",
                            buttons=await db_call(account_list_keyboard, uid)
                        )
                    
                except SessionPasswordNeededError:
                    try:
                        st = dict(user_states.get(uid) or {})
                        st['action'] = '2fa'
                        user_states[int(uid)] = st
                    except Exception:
                        user_states[uid]['action'] = '2fa'
                    await event.edit("**2FA Required**\n\nSend your cloud password:")
                except PhoneCodeInvalidError:
                    user_states[uid]['otp'] = ''
                    await event.edit("Wrong code! Try again:", buttons=otp_keyboard())
                except Exception as e:
                    await event.edit(f"Error: {str(e)[:100]}")
                    try:
                        if client:
                            await client.disconnect()
                    except Exception:
                        pass
                    if uid in user_states:
                        del user_states[uid]
            else:
                await event.edit(f"Code: `{otp}{'_' * (5-len(otp))}`", buttons=otp_keyboard())
            return
    
    except MessageNotModifiedError:
        pass
    except Exception as e:
        print(f"Callback error: {e}")
        await event.answer("Error!", alert=True)

@main_bot.on(events.NewMessage)
async def text_handler(event):
    real_uid = event.sender_id
    apply_uid = acting_uid(real_uid)
    # Prefer state owned by the typer (real_uid). When impersonating, also accept
    # target-keyed legacy state. Prefer real_uid if it has apply_to set.
    state_key = None
    if real_uid in user_states:
        state_key = real_uid
    elif apply_uid != real_uid and apply_uid in user_states:
        state_key = apply_uid
    else:
        return
    text = (event.text or "").strip()
    
    if text.startswith('/'):
        return
    
    state = user_states[state_key]
    action = state.get('action') if isinstance(state, dict) else None
    state_type = state.get('state') if isinstance(state, dict) else None
    # Settings always apply to the viewed user (or apply_to in state)
    uid = _flow_target(state, apply_uid)

    def _clear_state():
        user_states.pop(state_key, None)
        user_states.pop(real_uid, None)
        user_states.pop(apply_uid, None)
        _clear_state()
    
    # Admin: set the global per-group send frequency (the Frequency button).
    if action == 'set_target_freq':
        if not await db_call(is_admin, real_uid):
            _clear_state()
            await event.respond("Frequency is managed by admin.")
            return
        raw = str(text or '').strip()
        if not raw.isdigit():
            await event.respond(f"Send a number between 1 and {HARD_MAX_TARGET_PER_HOUR}.")
            return
        val = max(1, min(HARD_MAX_TARGET_PER_HOUR, int(raw)))
        set_global_setting('target_per_hour', val)
        try:
            _global_settings_cache.pop('target_per_hour', None)
        except Exception:
            pass
        _clear_state()
        await event.respond(
            f"✅ Global frequency set to <b>{val}/hr</b> per group (all users).",
            parse_mode='html',
            buttons=[[Button.inline("← Admin Panel", b"admin_panel")]],
        )
        return

    # Ops manager: natural-language chat with the fleet manager (admin only).
    if action == 'manager_chat':
        if not await db_call(is_admin, real_uid):
            _clear_state()
            return
        if text.lower() in ('exit', 'quit', 'done', 'stop', 'bye', 'leave'):
            _clear_state()
            await event.respond("👋 Left manager chat. Send /manager anytime.")
            return
        await _handle_manager_message(event, uid, text, state)
        return

    if action == 'add_keyword_reply':
        target = int(state.get('apply_to') or uid)
        if not (await db_call(can_use_private_autoreply, target) or await db_call(is_admin, real_uid)):
            _clear_state()
            await event.respond(
                "Auto Reply is on <b>Pro</b> and <b>Elite</b> only (not Starter).",
                parse_mode='html',
            )
            return
        if ' - ' not in text:
            await event.respond("Format: <code>keyword - message</code>", parse_mode='html')
            return
        kw, _, msg = text.partition(' - ')
        kw, msg = kw.strip(), msg.strip()
        if not kw or not msg:
            await event.respond("Both keyword and message are required.")
            return
        if len(kw) > 64 or len(msg) > 1000:
            await event.respond("Keyword max 64 chars, message max 1000.")
            return
        user = await db_call(get_user, target)
        kws = list(user.get('keyword_replies') or [])
        max_kw = await db_call(get_max_keyword_replies, target)
        _existing = any(
            isinstance(x, dict) and str(x.get('keyword') or '').strip().lower() == kw.lower()
            for x in kws
        )
        if max_kw <= 0 and not await db_call(is_admin, real_uid):
            _clear_state()
            await event.respond("Your plan does not include Auto Reply keywords.")
            return
        if (not _existing) and max_kw > 0 and len(kws) >= max_kw:
            _clear_state()
            await event.respond(
                f"Keyword limit reached (<b>{max_kw}</b> on your plan). "
                f"Remove one or upgrade to Elite.",
                parse_mode='html',
            )
            return
        found = False
        for item in kws:
            if isinstance(item, dict) and str(item.get('keyword', '')).lower() == kw.lower():
                item['keyword'] = kw
                item['message'] = msg
                found = True
                break
        if not found:
            kws.append({'keyword': kw, 'message': msg})
        if len(kws) > 30:
            await event.respond("Max 30 keywords.")
            return
        await db_call(
            uupdate,
            {'user_id': int(target)},
            {'$set': {'keyword_replies': kws, 'autoreply_enabled': True}},
            upsert=True,
        )
        _clear_state()
        await event.respond(
            f"✅ Saved <code>{_h(kw)}</code> → {_h(msg[:200])}\n"
            f"<i>Auto-reply ON. Account must be running (broadcast) to watch DMs.</i>",
            parse_mode='html',
        )
        return

    if action == 'set_group_autoreply':
        target = int(state.get('apply_to') or uid)
        if not await db_call(can_use_group_autoreply, target):
            _clear_state()
            await event.respond("Elite plan or admin /gpreply grant required.")
            return
        msg = text.strip()
        if not msg or len(msg) > 1000:
            await event.respond("Send a non-empty message (max 1000 chars).")
            return
        await db_call(
            uupdate,
            {'user_id': int(target)},
            {'$set': {'group_auto_reply': msg, 'group_autoreply_enabled': True}},
            upsert=True,
        )
        _clear_state()
        await event.respond(
            "✅ Group auto-reply saved and <b>ON</b>.\n"
            "Triggers when someone @mentions the account or replies to its message in a group.\n"
            "<i>Account must be running (broadcast) to watch groups.</i>",
            parse_mode='html',
        )
        return



    # ===================== Payment Screenshot Handler =====================
    if state_type == 'awaiting_payment_screenshot':
        # User should send a photo (payment screenshot)
        request_id = state.get('request_id')
        if not request_id or request_id not in pending_upi_payments:
            await event.respond("⚠️ Payment request expired. Please start again.")
            _clear_state()
            return
        
        # Check if message has photo
        if not event.message.photo:
            await event.respond("📸 Please send a <b>photo</b> of your payment screenshot.", parse_mode='html')
            return
        
        pay_req = pending_upi_payments[request_id]
        pay_req['status'] = 'submitted'
        
        # Get admin list: OWNER + DB admins
        admin_ids = [BOT_CONFIG['owner_id']]
        db_admins = list(admins_col.find({}))
        for adm in db_admins:
            admin_ids.append(adm['user_id'])
        
        admin_ids = list(set(admin_ids))  # deduplicate
        
        # Build admin notification
        sender = await event.get_sender()
        username_display = f"@{pay_req['username']}" if pay_req.get('username') else 'No username'
        
        admin_text = (
            f"<b>💰 New Payment Screenshot</b>\n\n"
            f"<b>User ID:</b> <code>{pay_req['user_id']}</code>\n"
            f"<b>Username:</b> {username_display}\n"
            f"<b>Plan:</b> {pay_req['plan_name']}\n"
            f"<b>Amount:</b> ₹{pay_req['price']}\n\n"
            f"<b>UPI ID:</b> <code>{UPI_PAYMENT.get('upi_id', '')}</code>\n\n"
            f"Review the screenshot and approve/reject:"
        )
        
        admin_buttons = [
            [
                Button.inline("✅ Approve", f"payapprove_{request_id}".encode()),
                Button.inline("❌ Reject", f"payreject_{request_id}".encode())
            ]
        ]
        
        # Forward screenshot to all admins
        for admin_id in admin_ids:
            try:
                msg = await main_bot.send_message(
                    admin_id,
                    admin_text,
                    parse_mode='html',
                    file=event.message.photo,
                    buttons=admin_buttons
                )
                admin_payment_message_map[msg.id] = request_id
            except Exception as e:
                print(f"[PAYMENT] Failed to notify admin {admin_id}: {e}")
        
        # Confirm to user
        await event.respond(
            "<b>✅ Screenshot Submitted</b>\n\n"
            "Your payment is under review. You'll be notified once it's verified.\n\n"
            "<i>This usually takes a few minutes.</i>",
            parse_mode='html'
        )
        
        # Clear user state
        _clear_state()
        return

    # ===================== Admin Auto Group Join File Handler =====================
    if state_type == 'admin_awaiting_group_join_file':
        target_id = state.get('target_id')
        source = state.get('source', 'premium')
        if not target_id:
            _clear_state()
            await event.respond("Target user missing. Please retry.")
            return

        if not event.message.document:
            await event.respond("📄 Please send a .txt file with group links (one per line).", parse_mode='html')
            return

        if not await db_call(is_premium, target_id):
            await event.respond("Paid plan feature only for this user.")
            _clear_state()
            return

        try:
            file_path = await event.message.download_media()
            with open(file_path, 'r', encoding='utf-8') as f:
                raw_lines = f.read().splitlines()

            group_links = []
            for line in raw_lines:
                line = (line or '').strip()
                if not line or line.startswith('#'):
                    continue
                if 'https://t.me/' in line:
                    username = line.split('https://t.me/')[-1].strip('/')
                elif 't.me/' in line:
                    username = line.split('t.me/')[-1].strip('/')
                elif line.startswith('@'):
                    username = line[1:]
                else:
                    username = line
                username = (username or '').strip().strip('/')
                if username:
                    group_links.append(username)

            try:
                os.remove(file_path)
            except Exception:
                pass

            seen = set()
            deduped = []
            for u in group_links:
                key = u.lower()
                if key in seen:
                    continue
                seen.add(key)
                deduped.append(u)
            group_links = deduped

            if not group_links:
                await event.respond("❌ No valid group links found in the file.")
                _clear_state()
                return

            user_accounts = list(accounts_col.find({'owner_id': int(target_id)}))
            if not user_accounts:
                await event.respond("❌ Target user has no accounts.")
                _clear_state()
                return

            BATCH_SIZE = 50
            BATCH_WAIT_SECONDS = 3600

            total_ops = len(user_accounts) * len(group_links)
            progress = {'done': 0, 'joined': 0, 'failed': 0, 'current_batch': 1}

            progress_msg = await event.respond(
                f"<b>Joining Groups...</b>\n\n"
                f"<b>User:</b> <code>{target_id}</code>\n"
                f"<b>Accounts:</b> {len(user_accounts)}\n"
                f"<b>Groups:</b> {len(group_links)}\n"
                f"<b>Mode:</b> <code>{BATCH_SIZE}/hour</code>\n\n"
                f"<b>Progress:</b> <code>0/{total_ops}</code>",
                parse_mode='html',
                buttons=[[Button.inline("Stop", b"auto_join_cancel"), Button.inline("Back", f"admin_settings_automation_{target_id}_{source}")]]
            )

            lock = asyncio.Lock()
            stop_evt = asyncio.Event()
            auto_join_cancel[uid] = False

            from telethon.tl.functions.channels import JoinChannelRequest

            async def update_progress_loop():
                last = None
                while not stop_evt.is_set():
                    await asyncio.sleep(1)
                    if auto_join_cancel.get(uid):
                        stop_evt.set()
                        break
                    async with lock:
                        snap = (progress['done'], progress['joined'], progress['failed'], progress['current_batch'])
                    if snap == last:
                        continue
                    last = snap
                    done, joined, failed, batch_no = snap
                    try:
                        await main_bot.edit_message(
                            progress_msg.chat_id,
                            progress_msg.id,
                            f"<b>Joining Groups...</b>\n\n"
                            f"<b>User:</b> <code>{target_id}</code>\n"
                            f"<b>Accounts:</b> {len(user_accounts)}\n"
                            f"<b>Groups:</b> {len(group_links)}\n"
                            f"<b>Mode:</b> <code>{BATCH_SIZE}/hour</code>\n"
                            f"<b>Batch:</b> <code>{batch_no}</code>\n\n"
                            f"<b>Progress:</b> <code>{done}/{total_ops}</code>\n"
                            f"<b>Joined:</b> <code>{joined}</code>\n"
                            f"<b>Failed:</b> <code>{failed}</code>",
                            parse_mode='html'
                        )
                    except Exception:
                        pass

            async def join_with_account(acc):
                account_id = acc.get('account_id') or acc.get('_id')
                if not account_id:
                    return
                try:
                    session = _load_account_session(account_id)
                    if not session:
                        session_enc = (acc or {}).get('session') or (acc or {}).get('session_string')
                        if session_enc:
                            try:
                                session = cipher_suite.decrypt(
                                    session_enc.encode() if isinstance(session_enc, str) else session_enc
                                ).decode()
                            except Exception:
                                session = None
                    if not session:
                        return
                except Exception:
                    return

                client = TelegramClient(StringSession(session), CONFIG['api_id'], CONFIG['api_hash'])
                try:
                    await client.connect()
                    if not await client.is_user_authorized():
                        return

                    for idx, username in enumerate(group_links):
                        if stop_evt.is_set() or auto_join_cancel.get(uid):
                            break
                        if idx > 0 and (idx % BATCH_SIZE) == 0:
                            async with lock:
                                progress['current_batch'] += 1
                            for _ in range(BATCH_WAIT_SECONDS):
                                if stop_evt.is_set() or auto_join_cancel.get(uid):
                                    break
                                await asyncio.sleep(1)

                        try:
                            entity = await client.get_entity(username)
                            await client(JoinChannelRequest(entity))
                            async with lock:
                                progress['joined'] += 1
                                progress['done'] += 1
                        except FloodWaitError as e:
                            wait_s = int(getattr(e, 'seconds', 0) or 0)
                            async with lock:
                                progress['done'] += 1
                            if wait_s > 0:
                                for _ in range(wait_s):
                                    if stop_evt.is_set() or auto_join_cancel.get(uid):
                                        break
                                    await asyncio.sleep(1)
                        except Exception:
                            async with lock:
                                progress['failed'] += 1
                                progress['done'] += 1
                        await asyncio.sleep(1)
                finally:
                    try:
                        await client.disconnect()
                    except Exception:
                        pass

            progress_task = asyncio.create_task(update_progress_loop())
            account_tasks = [asyncio.create_task(join_with_account(acc)) for acc in user_accounts]
            await asyncio.gather(*account_tasks, return_exceptions=True)
            stop_evt.set()
            try:
                await progress_task
            except Exception:
                pass

            async with lock:
                done = progress['done']
                joined = progress['joined']
                failed = progress['failed']

            final_status = "✅ Complete" if not auto_join_cancel.get(uid) else "⏸ Stopped"
            await main_bot.edit_message(
                progress_msg.chat_id,
                progress_msg.id,
                f"<b>{final_status}</b>\n\n"
                f"<b>User:</b> <code>{target_id}</code>\n"
                f"<b>Accounts:</b> {len(user_accounts)}\n"
                f"<b>Groups:</b> {len(group_links)}\n\n"
                f"<b>Total Attempts:</b> <code>{done}/{total_ops}</code>\n"
                f"<b>Joined:</b> <code>{joined}</code>\n"
                f"<b>Failed:</b> <code>{failed}</code>",
                parse_mode='html'
            )
        except Exception as e:
            await event.respond(f"❌ Error processing file: {e}")
            print(f"[ADMIN AUTO_JOIN] Error: {e}")

        _clear_state()
        return
    
    # ===================== Auto Group Join File Handler =====================
    if state_type == 'awaiting_track_url':
        url = (event.raw_text or event.text or '').strip()
        if not (url.startswith('http://') or url.startswith('https://') or url.startswith('t.me/') or url.startswith('@')):
            await event.respond("Send a valid URL (https://… or t.me/… or @username).")
            return
        if url.startswith('@'):
            url = f"https://t.me/{url[1:]}"
        elif url.startswith('t.me/'):
            url = f"https://{url}"
        tracked, code = await db_call(lambda: create_tracked_link(uid, url))
        _clear_state()
        if not tracked:
            await event.respond("Click tracking isn't configured yet (admin: set N8N_TRACK_BASE).")
            return
        await event.respond(
            "<b>\u2705 Tracked link created</b>\n\n"
            f"<b>Put this in your ad:</b>\n<code>{_h(tracked)}</code>\n\n"
            "<i>Every click is counted under Results.</i>",
            parse_mode='html',
            buttons=[[Button.inline("\U0001F4C8 View Results", b"menu_results")]]
        )
        return

    if state_type == 'awaiting_niche_keyword':
        keyword = (event.raw_text or event.text or '').strip()
        if not keyword or len(keyword) < 2:
            await event.respond("Send a keyword (at least 2 characters).")
            return
        await event.respond("🔎 Searching Telegram for groups…")
        found, status = await find_niche_groups(uid, keyword, limit=int(os.getenv('FIND_GROUPS_LIMIT', '50')))
        if status != 'ok':
            _clear_state()
            await event.respond(f"❌ Search failed: {status.replace('_', ' ')}")
            return
        if not found:
            _clear_state()
            await event.respond("No public groups found for that niche. Try a broader keyword.")
            return
        usernames = [g['username'] for g in found]
        user_states[uid] = {'state': 'found_groups_ready', 'found_groups': usernames}
        def _gline(g):
            m = g.get('members', 0)
            mtxt = f" — {m:,} members" if m else ""
            return f"• {(g['title'] or '')[:32]} (@{g['username']}){mtxt}"
        preview = "\n".join(_gline(g) for g in found[:20])
        more = f"\n…and {len(found) - 20} more" if len(found) > 20 else ""
        await event.respond(
            f"<b>🔎 Found {len(found)} groups for “{_h(keyword)}”</b>\n\n{_h(preview)}{more}",
            parse_mode='html',
            buttons=[[Button.inline(f"➕ Join All {len(found)} Found", b"join_found_groups")],
                     [Button.inline("← Back", b"menu_auto_group_join")]]
        )
        return

    if state_type == 'awaiting_group_join_file':
        # Accept EITHER a .txt file OR pasted links (one per line) in the message.
        if not await db_call(is_premium, uid):
            await event.respond("⭐ Paid plan feature only!")
            _clear_state()
            return

        try:
            raw_lines = []
            if event.message.document:
                file_path = await event.message.download_media()
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        raw_lines = f.read().splitlines()
                finally:
                    try:
                        os.remove(file_path)
                    except Exception:
                        pass
            else:
                _txt = (event.raw_text or event.text or '')
                if _txt.strip():
                    raw_lines = _txt.splitlines()

            if not raw_lines:
                await event.respond("📄 Send a .txt file OR paste group links (one per line).", parse_mode='html')
                return

            # Parse group links
            group_links = []
            for line in raw_lines:
                line = (line or '').strip()
                if not line or line.startswith('#'):
                    continue
                if 'https://t.me/' in line:
                    username = line.split('https://t.me/')[-1].strip('/')
                elif 't.me/' in line:
                    username = line.split('t.me/')[-1].strip('/')
                elif line.startswith('@'):
                    username = line[1:]
                else:
                    username = line

                username = (username or '').strip().strip('/')
                if username:
                    group_links.append(username)

            # Deduplicate while preserving order
            seen = set()
            deduped = []
            for u in group_links:
                if u.lower() in seen:
                    continue
                seen.add(u.lower())
                deduped.append(u)
            group_links = deduped

            if not group_links:
                await event.respond("❌ No valid group links found in the file.")
                _clear_state()
                return

            user_accounts = list(accounts_col.find({'owner_id': uid}))
            if not user_accounts:
                await event.respond("❌ Add an account first.")
                _clear_state()
                return

            # Requirements: join 50 groups per hour (batch) per account
            BATCH_SIZE = 50
            BATCH_WAIT_SECONDS = 3600

            total_ops = len(user_accounts) * len(group_links)
            progress = {
                'done': 0,
                'joined': 0,
                'failed': 0,
                'current_batch': 1,
            }

            progress_msg = await event.respond(
                f"<b>Joining Groups...</b>\n\n"
                f"<b>Accounts:</b> {len(user_accounts)}\n"
                f"<b>Groups:</b> {len(group_links)}\n"
                f"<b>Mode:</b> <code>{BATCH_SIZE}/hour</code>\n\n"
                f"<b>Progress:</b> <code>0/{total_ops}</code>",
                parse_mode='html',
                buttons=[[Button.inline("Stop", b"auto_join_cancel"), Button.inline("Back", b"menu_auto_group_join")]]
            )

            lock = asyncio.Lock()
            stop_evt = asyncio.Event()
            auto_join_cancel[uid] = False

            from telethon.tl.functions.channels import JoinChannelRequest

            async def update_progress_loop():
                last = None
                while not stop_evt.is_set():
                    await asyncio.sleep(1)
                    if auto_join_cancel.get(uid):
                        stop_evt.set()
                        break

                    async with lock:
                        snap = (progress['done'], progress['joined'], progress['failed'], progress['current_batch'])
                    if snap == last:
                        continue
                    last = snap

                    done, joined, failed, batch_no = snap
                    try:
                        await main_bot.edit_message(
                            progress_msg.chat_id,
                            progress_msg.id,
                            f"<b>Joining Groups...</b>\n\n"
                            f"<b>Accounts:</b> {len(user_accounts)}\n"
                            f"<b>Groups:</b> {len(group_links)}\n"
                            f"<b>Mode:</b> <code>{BATCH_SIZE}/hour</code>\n"
                            f"<b>Batch:</b> <code>{batch_no}</code>\n\n"
                            f"<b>Progress:</b> <code>{done}/{total_ops}</code>\n"
                            f"<b>Joined:</b> <code>{joined}</code>\n"
                            f"<b>Failed:</b> <code>{failed}</code>",
                            parse_mode='html'
                        )
                    except Exception:
                        pass

            async def join_with_account(acc):
                account_id = acc.get('account_id') or acc.get('_id')
                if not account_id:
                    return

                # decrypt session
                try:
                    session = _load_account_session(account_id)
                    if not session:
                        session_enc = (acc or {}).get('session') or (acc or {}).get('session_string')
                        if session_enc:
                            try:
                                session = cipher_suite.decrypt(
                                    session_enc.encode() if isinstance(session_enc, str) else session_enc
                                ).decode()
                            except Exception:
                                session = None
                    if not session:
                        return
                except Exception:
                    return

                client = TelegramClient(StringSession(session), CONFIG['api_id'], CONFIG['api_hash'])
                try:
                    await client.connect()
                    if not await client.is_user_authorized():
                        return

                    for idx, username in enumerate(group_links):
                        if stop_evt.is_set() or auto_join_cancel.get(uid):
                            break

                        # Batch throttle: after each 50 joins attempt, wait 1 hour
                        if idx > 0 and (idx % BATCH_SIZE) == 0:
                            async with lock:
                                progress['current_batch'] += 1
                            # Wait, but still allow cancel
                            for _ in range(BATCH_WAIT_SECONDS):
                                if stop_evt.is_set() or auto_join_cancel.get(uid):
                                    break
                                await asyncio.sleep(1)

                        try:
                            entity = await client.get_entity(username)
                            await client(JoinChannelRequest(entity))
                            async with lock:
                                progress['joined'] += 1
                                progress['done'] += 1
                        except FloodWaitError as e:
                            # Respect floodwait for joining; don't count as failure but still counts as an attempt
                            wait_s = int(getattr(e, 'seconds', 0) or 0)
                            async with lock:
                                progress['done'] += 1
                            if wait_s > 0:
                                for _ in range(wait_s):
                                    if stop_evt.is_set() or auto_join_cancel.get(uid):
                                        break
                                    await asyncio.sleep(1)
                        except Exception:
                            async with lock:
                                progress['failed'] += 1
                                progress['done'] += 1

                        await asyncio.sleep(1)

                finally:
                    try:
                        await client.disconnect()
                    except Exception:
                        pass

            progress_task = asyncio.create_task(update_progress_loop())
            account_tasks = [asyncio.create_task(join_with_account(acc)) for acc in user_accounts]
            await asyncio.gather(*account_tasks, return_exceptions=True)
            stop_evt.set()
            try:
                await progress_task
            except Exception:
                pass

            async with lock:
                done = progress['done']
                joined = progress['joined']
                failed = progress['failed']

            final_status = "✅ Complete" if not auto_join_cancel.get(uid) else "⏸ Stopped"
            await main_bot.edit_message(
                progress_msg.chat_id,
                progress_msg.id,
                f"<b>{final_status}</b>\n\n"
                f"<b>Accounts:</b> {len(user_accounts)}\n"
                f"<b>Groups:</b> {len(group_links)}\n\n"
                f"<b>Total Attempts:</b> <code>{done}/{total_ops}</code>\n"
                f"<b>Joined:</b> <code>{joined}</code>\n"
                f"<b>Failed:</b> <code>{failed}</code>",
                parse_mode='html'
            )

        except Exception as e:
            await event.respond(f"❌ Error processing file: {e}")
            print(f"[AUTO_JOIN] Error: {e}")

        _clear_state()
        return
    
    if action == 'broadcast':
        if not await db_call(is_admin, uid):
            _clear_state()
            return
        
        users = get_all_users()
        sent = 0
        failed = 0
        for u in users:
            try:
                await main_bot.send_message(u['user_id'], f"**Announcement**\n\n{text}")
                sent += 1
            except:
                failed += 1
        
        _clear_state()
        await event.respond(f"Broadcast complete!\nSent: {sent}\nFailed: {failed}")
        return
    
    if action == 'custom_autoreply':
        if not await db_call(is_premium, uid):
            _clear_state()
            await event.respond("Paid plan only!")
            return
        
        # Save custom auto-reply to ALL user's accounts in account_settings_col
        accounts = await db_call(get_user_accounts, uid)
        if accounts:
            for acc in accounts:
                update_account_settings(str(acc['_id']), {'auto_reply': text})
        
        _clear_state()
        await respond_with_welcome(
            event,
            f"✅ <b>Custom auto-reply saved!</b>\n\n<i>Applied to all {len(accounts)} account(s)</i>",
            buttons=[[Button.inline("← Back to Auto Reply", b"menu_autoreply")]]
        )
        return

    if action == 'admin_custom_autoreply':
        target_id = state.get('target_id')
        source = state.get('source', 'premium')
        if not target_id:
            _clear_state()
            await event.respond("Target user missing.")
            return
        if not await db_call(is_premium, target_id):
            _clear_state()
            await event.respond("Paid plan feature only for this user.")
            return

        accounts = await db_call(get_user_accounts, target_id)
        if accounts:
            for acc in accounts:
                update_account_settings(str(acc['_id']), {'auto_reply': text})

        _clear_state()
        await respond_with_welcome(
            event,
            f"✅ <b>Auto-reply saved</b>\n\nApplied to <code>{len(accounts)}</code> account(s).",
            buttons=[[Button.inline("Back", f"admin_menu_autoreply_{target_id}_{source}")]]
        )
        return
    
    if action == 'add_topic_link':
        topic = state.get('topic')
        acc_id = state.get('account_id')
        last_msg_id = state.get('last_msg_id')
        
        raw_links = text.strip().replace(',', '\n').split('\n')
        links = []
        for raw in raw_links:
            link = raw.strip()
            if not link:
                continue
            if '?' in link:
                link = link.split('?')[0]
            if link.startswith('@'):
                link = f"https://t.me/{link[1:]}"
            elif link.startswith('t.me/'):
                link = f"https://{link}"
            elif not link.startswith('https://t.me/'):
                continue
            if 't.me/' in link:
                links.append(link)
        
        if not links:
            await event.respond("Invalid! Send links like:\n`https://t.me/groupname/5`\n\nYou can send multiple links, one per line.")
            return
        
        tier_settings = await db_call(get_user_tier_settings, uid)
        max_groups = tier_settings.get('max_groups_per_topic', 10)
        current_count = await db_call(account_topics_col.count_documents, {'account_id': acc_id, 'topic': topic})
        
        added = 0
        skipped = 0
        
        for link in links:
            if current_count + added >= max_groups:
                break
            
            existing = await db_call(account_topics_col.find_one, {'account_id': acc_id, 'topic': topic, 'link': link})
            if existing:
                skipped += 1
                continue
            
            parts = link.replace('https://t.me/', '').split('/')
            group_username = parts[0]
            topic_msg_id = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else None
            display_title = f"{group_username}/{topic_msg_id}" if topic_msg_id else group_username
            
            await db_call(lambda: account_topics_col.insert_one({
                'account_id': str(acc_id),  # ensure string for consistency
                'topic': topic,
                'link': link,
                'title': display_title,
                'topic_msg_id': topic_msg_id,
                'added_at': datetime.now()
            }))
            added += 1
        
        new_count = current_count + added
        
        update_text = f"**{topic.title()}**\n\nGroups: {new_count}/{max_groups}\n"
        if added > 0:
            update_text += f"Added: {added}"
        if skipped > 0:
            update_text += f" | Skipped: {skipped} (duplicates)"
        update_text += "\n\n"
        
        groups = await db_call(lambda: list(account_topics_col.find({'account_id': acc_id, 'topic': topic}).sort('added_at', -1).limit(5)))
        for i, g in enumerate(groups):
            update_text += f"{i+1}. {g.get('title', 'Unknown')}\n"
        
        total = await db_call(account_topics_col.count_documents, {'account_id': acc_id, 'topic': topic})
        if total > 5:
            update_text += f"\n...and {total - 5} more"
        
        update_text += "\n\nSend more links or go back."
        
        if last_msg_id:
            try:
                await main_bot.edit_message(event.chat_id, last_msg_id, update_text, 
                    buttons=[[Button.inline("View All", f"view_topic_groups_{topic}_{acc_id}")], [Button.inline("Back to Topics", b"menu_topics")]])
                await event.delete()
            except:
                msg = await event.respond(update_text,
                    buttons=[[Button.inline("View All", f"view_topic_groups_{topic}_{acc_id}")], [Button.inline("Back to Topics", b"menu_topics")]])
                user_states[uid]['last_msg_id'] = msg.id
        else:
            msg = await event.respond(update_text,
                buttons=[[Button.inline("View All", f"view_topic_groups_{topic}_{acc_id}")], [Button.inline("Back to Topics", b"menu_topics")]])
            user_states[uid]['last_msg_id'] = msg.id
        return

    if action == 'admin_add_topic_link':
        topic = state.get('topic')
        acc_id = state.get('account_id')
        target_id = state.get('target_id')
        source = state.get('source', 'premium')
        last_msg_id = state.get('last_msg_id')

        raw_links = text.strip().replace(',', '\n').split('\n')
        links = []
        for raw in raw_links:
            link = raw.strip()
            if not link:
                continue
            if '?' in link:
                link = link.split('?')[0]
            if link.startswith('@'):
                link = f"https://t.me/{link[1:]}"
            elif link.startswith('t.me/'):
                link = f"https://{link}"
            elif not link.startswith('https://t.me/'):
                continue
            if 't.me/' in link:
                links.append(link)

        if not links:
            await event.respond("Invalid! Send links like:\n`https://t.me/groupname/5`\n\nYou can send multiple links, one per line.")
            return

        tier_settings = await db_call(get_user_tier_settings, int(target_id))
        max_groups = tier_settings.get('max_groups_per_topic', 10)
        current_count = await db_call(account_topics_col.count_documents, {'account_id': acc_id, 'topic': topic})

        added = 0
        skipped = 0
        for link in links:
            if current_count + added >= max_groups:
                break
            existing = await db_call(account_topics_col.find_one, {'account_id': acc_id, 'topic': topic, 'link': link})
            if existing:
                skipped += 1
                continue

            parts = link.replace('https://t.me/', '').split('/')
            group_username = parts[0]
            topic_msg_id = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else None
            display_title = f"{group_username}/{topic_msg_id}" if topic_msg_id else group_username

            await db_call(lambda: account_topics_col.insert_one({
                'account_id': str(acc_id),
                'topic': topic,
                'link': link,
                'title': display_title,
                'topic_msg_id': topic_msg_id,
                'added_at': datetime.now()
            }))
            added += 1

        new_count = current_count + added
        update_text = f"**{topic.title()}**\n\nGroups: {new_count}/{max_groups}\n"
        if added > 0:
            update_text += f"Added: {added}"
        if skipped > 0:
            update_text += f" | Skipped: {skipped} (duplicates)"
        update_text += "\n\n"

        groups = await db_call(lambda: list(account_topics_col.find({'account_id': acc_id, 'topic': topic}).sort('added_at', -1).limit(5)))
        for i, g in enumerate(groups):
            update_text += f"{i+1}. {g.get('title', 'Unknown')}\n"

        total = await db_call(account_topics_col.count_documents, {'account_id': acc_id, 'topic': topic})
        if total > 5:
            update_text += f"\n...and {total - 5} more"

        update_text += "\n\nSend more links or go back."

        buttons = [
            [Button.inline("View All", f"admin_view_topic_groups_{target_id}_{topic}_{acc_id}_{source}")],
            [Button.inline("Back to Topics", f"admin_menu_topics_{target_id}_{source}")]
        ]
        if last_msg_id:
            try:
                await main_bot.edit_message(event.chat_id, last_msg_id, update_text, buttons=buttons)
                await event.delete()
            except:
                msg = await event.respond(update_text, buttons=buttons)
                user_states[uid]['last_msg_id'] = msg.id
        else:
            msg = await event.respond(update_text, buttons=buttons)
            user_states[uid]['last_msg_id'] = msg.id
        return
    
    if action == 'quiet_hours':
        step = state.get('step')
        if step == 'start':
            start = _parse_time_24h(text)
            if not start:
                await event.respond("Please use 24h format: HH:MM (example: 01:00).")
                return
            user_states[uid]['start'] = start
            user_states[uid]['step'] = 'end'
            await event.respond("Send the end time in 24h format (HH:MM). Example: 07:00")
            return

        if step == 'end':
            end = _parse_time_24h(text)
            if not end:
                await event.respond("Please use 24h format: HH:MM (example: 07:00).")
                return
            start = state.get('start')
            if not start:
                _clear_state()
                await event.respond("Start time missing. Please open Quiet Hours again.")
                return

            label = f"{start}-{end}"
            await db_call(uupdate, 
                {'user_id': int(uid)},
                {'$set': {'quiet_hours': {'enabled': True, 'start': start, 'end': end, 'label': label}}},
                upsert=True
            )
            _clear_state()
            text, buttons = quiet_hours_menu(uid)
            welcome_image = MESSAGES.get('welcome_image', '')
            if welcome_image:
                await event.respond(file=welcome_image, message=text, parse_mode='html', buttons=buttons)
            else:
                await event.respond(text, parse_mode='html', buttons=buttons)
        return
    
    if action == 'admin_custom_interval':
        step = state.get('step')
        target_id = int(state.get('target_id'))
        source = state.get('source', 'premium')
        try:
            val = int(text)
        except:
            await event.respond("Please enter a valid number!")
            return

        if step == 'msg_delay':
            if val < 5 or val > 9999:
                await event.respond("Enter a value between 5-9999:")
                return
            user_states[uid]['msg_delay'] = val
            user_states[uid]['step'] = 'round_delay'
            await event.respond("Enter cycle delay in seconds (60-9999):")
            return

        if step == 'round_delay':
            if val < 60 or val > 9999:
                await event.respond("Enter a value between 60-9999:")
                return

            custom_interval = {
                'msg_delay': user_states[uid]['msg_delay'],
                'round_delay': val
            }
            await db_call(uupdate, 
                {'user_id': target_id},
                {'$set': {'custom_interval': custom_interval, 'interval_preset': 'custom', 'cycle_interval_sec': custom_interval['round_delay']}},
                upsert=True
            )
            _clear_state()
            await respond_with_welcome(
                event,
                f"<b>Custom Interval Set</b>\n\n"
                f"User: <code>{target_id}</code>\n"
                f"Message Delay: <code>{custom_interval['msg_delay']}s</code>\n"
                f"Cycle Delay: <code>{custom_interval['round_delay']}s</code>",
                buttons=[[Button.inline("Back", f"admin_settings_interval_{target_id}_{source}")]]
            )
            return

    if action == 'admin_quiet_hours':
        step = state.get('step')
        target_id = state.get('target_id')
        source = state.get('source', 'premium')
        if not target_id:
            _clear_state()
            await event.respond("Target user missing.")
            return

        if step == 'start':
            start = _parse_time_24h(text)
            if not start:
                await event.respond("Please use 24h format: HH:MM (example: 01:00).")
                return
            user_states[uid]['start'] = start
            user_states[uid]['step'] = 'end'
            await event.respond("Send the end time in 24h format (HH:MM). Example: 07:00")
            return

        if step == 'end':
            end = _parse_time_24h(text)
            if not end:
                await event.respond("Please use 24h format: HH:MM (example: 07:00).")
                return
            start = state.get('start')
            if not start:
                _clear_state()
                await event.respond("Start time missing. Please open Quiet Hours again.")
                return
            label = f"{start}-{end}"
            await db_call(uupdate, 
                {'user_id': int(target_id)},
                {'$set': {'quiet_hours': {'enabled': True, 'start': start, 'end': end, 'label': label}}},
                upsert=True
            )
            _clear_state()
            text, buttons = admin_quiet_hours_menu(int(target_id), source)
            await respond_with_welcome(event, text, buttons=buttons)
            return


    if action == 'custom_msg_delay':
        try:
            val = int(text.strip())
        except Exception:
            await event.respond("Enter a number of seconds (5-9999).")
            return
        if val < 5 or val > 9999:
            await event.respond("Enter seconds between 5 and 9999.")
            return
        target = _flow_target(state, uid)
        await db_call(uupdate, {'user_id': int(target)}, {
            '$set': {'msg_delay_sec': int(val), 'interval_preset': 'custom'},
            '$unset': {'custom_interval': ''},
        })
        _clear_state()
        await event.respond(
            f"Message delay set to <b>{val}s</b> for user <code>{target}</code>. Cycle gap unchanged.",
            parse_mode='html',
            buttons=[[Button.inline("Back to Intervals", b"menu_interval")]],
        )
        return

    if action == 'cycle_interval_custom':
        try:
            minutes = int(text.strip())
        except Exception:
            await event.respond("Enter a number of minutes (1-1440).")
            return
        if minutes < 1 or minutes > 1440:
            await event.respond("Enter minutes between 1 and 1440.")
            return
        sec = minutes * 60
        await db_call(uupdate, {'user_id': uid}, {'$set': {'cycle_interval_sec': sec}})
        _clear_state()
        await event.respond(
            f"✅ Cycle interval set to <b>{minutes} min</b> ({sec}s).\n"
            "Frequency will never shorten this gap.",
            parse_mode='html',
            buttons=[[Button.inline("Back", b"menu_interval")]],
        )
        return


    if action == 'admin_custom_msg_delay':
        if not await db_call(is_admin, uid):
            return
        try:
            val = int(text.strip())
        except Exception:
            await event.respond("Enter a number of seconds (5-9999).")
            return
        if val < 5 or val > 9999:
            await event.respond("Enter seconds between 5 and 9999.")
            return
        target_id = int(state.get('target_id'))
        source = state.get('source', 'premium')
        await db_call(uupdate, {'user_id': target_id}, {
            '$set': {'msg_delay_sec': val, 'interval_preset': 'custom'},
            '$unset': {'custom_interval': ''},
        })
        _clear_state()
        await event.respond(
            f"Message delay for <code>{target_id}</code> set to <b>{val}s</b>.",
            parse_mode='html',
            buttons=[[Button.inline("Back", f"admin_settings_interval_{target_id}_{source}")]],
        )
        return

    if action == 'admin_set_user_freq':
        if not await db_call(is_admin, uid):
            return
        try:
            val = int(text.strip())
        except Exception:
            await event.respond("Enter a number.")
            return
        target_id = int(state.get('target_id'))
        source = state.get('source', 'premium')
        if val <= 0:
            await db_call(uupdate, {'user_id': target_id}, {
                '$unset': {'freq_per_hour': '', 'freq_disabled': ''},
            })
            msg = f"Frequency for <code>{target_id}</code> reset to global default."
        else:
            val = min(HARD_MAX_TARGET_PER_HOUR, val)
            await db_call(uupdate, {'user_id': target_id}, {
                '$set': {'freq_per_hour': val, 'freq_disabled': False},
            })
            msg = f"Frequency for <code>{target_id}</code> set to <b>{val}/hr</b>."
        _clear_state()
        await event.respond(msg, parse_mode='html', buttons=[[Button.inline("Back", f"admin_settings_interval_{target_id}_{source}")]])
        return

    if action == 'admin_find_user':
        if not await db_call(is_admin, uid):
            return
        raw = text.strip()
        target_id = await resolve_target_user_id(raw, event.client)
        _clear_state()
        if not target_id:
            await event.respond("User not found.", buttons=[[Button.inline("Back", b"admin_panel")]])
            return
        user = await db_call(users_col.find_one, {'user_id': int(target_id)})
        if not user:
            await event.respond(
                f"No DB record for <code>{target_id}</code>.",
                parse_mode='html',
                buttons=[[Button.inline("Back", b"admin_panel")]],
            )
            return
        await event.respond(
            f"Open user <code>{target_id}</code>:",
            parse_mode='html',
            buttons=[[Button.inline("Open profile", f"admin_user_detail_all_{int(target_id)}")],
                     [Button.inline("Back", b"admin_panel")]],
        )
        return

    if action == 'admin_cycle_interval_custom':
        if not await db_call(is_admin, uid):
            return
        try:
            minutes = int(text.strip())
        except Exception:
            await event.respond("Enter a number of minutes (1–1440).")
            return
        if minutes < 1 or minutes > 1440:
            await event.respond("Enter minutes between 1 and 1440.")
            return
        target_id = int(state.get('target_id'))
        source = state.get('source', 'all')
        sec = minutes * 60
        await db_call(uupdate, {'user_id': target_id}, {'$set': {'cycle_interval_sec': sec}})
        _clear_state()
        await event.respond(
            f"✅ Cycle interval for <code>{target_id}</code> set to <b>{minutes} min</b>.",
            parse_mode='html',
        )
        return

    if action == 'custom_interval':
        step = state.get('step')
        target = _flow_target(state, uid)
        try:
            val = int(text)
        except Exception:
            await event.respond("Please enter a valid number!")
            return
        
        if step == 'msg_delay':
            if val < 5 or val > 9999:
                await event.respond("Enter a value between 5-9999:")
                return
            state['msg_delay'] = val
            state['step'] = 'round_delay'
            _put_flow_state(real_uid, target, state)
            await event.respond("Enter cycle delay in seconds (60-9999):")
            return
        
        if step == 'round_delay':
            if val < 60 or val > 9999:
                await event.respond("Enter a value between 60-9999:")
                return
            
            custom_interval = {
                'msg_delay': int(state.get('msg_delay') or 30),
                'round_delay': val
            }
            await db_call(uupdate, {'user_id': int(target)}, {
                '$set': {
                    'custom_interval': custom_interval,
                    'interval_preset': 'custom',
                    'cycle_interval_sec': custom_interval['round_delay'],
                    'msg_delay_sec': custom_interval['msg_delay'],
                }
            })
            _clear_state()
            saved_text = (
                f"<b>Custom Interval Saved!</b> (user <code>{target}</code>)\n\n"
                f"Message Delay: <code>{custom_interval['msg_delay']}s</code>\n"
                f"Cycle Delay: <code>{custom_interval['round_delay']}s</code>"
            )
            buttons = [[Button.inline("Back to Dashboard", b"enter_dashboard")]]
            welcome_image = MESSAGES.get('welcome_image', '')
            if welcome_image:
                await event.respond(file=welcome_image, message=saved_text, parse_mode='html', buttons=buttons)
            else:
                await event.respond(saved_text, parse_mode='html', buttons=buttons)
            return
    
    
    if not await db_call(is_approved, uid):
        approve_user(uid)
    
    if action == 'phone':
        if not re.match(r'^\+\d{10,15}$', text):
            await event.respond("Invalid format!\n\nUse: `+919876543210`")
            return
        owner_id = int(state.get('owner_id') or state.get('apply_to') or uid)
        # Only the real admin may add accounts for another user
        if owner_id != real_uid and not await db_call(is_admin, real_uid):
            owner_id = int(uid)
        await db_call(get_user, owner_id)

        accounts = await db_call(get_user_accounts, owner_id)
        max_accounts = await db_call(get_user_max_accounts, owner_id)

        if len(accounts) >= max_accounts:
            _clear_state()
            if owner_id != uid:
                await event.respond(f"User {owner_id} reached the account limit ({max_accounts}).")
            else:
                await event.respond(f"Account limit reached ({max_accounts})!")
            return
        
        # Typewriter effect: progressive updates
        status_msg = await event.respond("Connecting...")
        await asyncio.sleep(0.6)
        await status_msg.edit("Connecting to server...")
        await asyncio.sleep(0.7)
        await status_msg.edit("Sending OTP...")
        
        client = None
        try:
            sent = None
            proxy = None
            last_err = None
            for candidate in get_proxy_candidates():
                proxy = candidate
                proxy_info = f" via proxy" if proxy else ""
                print(f"[OTP] Sending code to {text}{proxy_info}")
                client = TelegramClient(StringSession(), CONFIG['api_id'], CONFIG['api_hash'], proxy=proxy)
                try:
                    await client.connect()
                    sent = await client.send_code_request(text)
                    break
                except Exception as e:
                    last_err = e
                    try:
                        await client.disconnect()
                    except Exception:
                        pass
                    client = None
                    continue

            if not sent:
                raise last_err or RuntimeError("All proxies failed")
            
            await asyncio.sleep(0.5)
            await status_msg.edit("OTP Sent!")
            
            user_states[uid] = {
                'action': 'otp',
                'client': client,
                'phone': text,
                'hash': sent.phone_code_hash,
                'proxy': proxy,
                'owner_id': owner_id
            }
            
            await asyncio.sleep(0.4)
            await event.respond(
                "**OTP Sent**\n\n"
                "Enter the code you received.\n\n"
                "Format: `code1234` (if code is 1234)\n\n"
                "Example: `code12345`"
            )
            
        except PhoneNumberInvalidError:
            await status_msg.edit("Invalid phone number!")
            _clear_state()
            if client:
                try:
                    await client.disconnect()
                except Exception:
                    pass
        except Exception as e:
            await status_msg.edit(f"Failed to send OTP: {str(e)[:100]}")
            _clear_state()
            if client:
                try:
                    await client.disconnect()
                except Exception:
                    pass
    
    elif action == 'otp':
        # Accept code in format: code1234 (remove "code" prefix)
        otp_code = text
        if text.lower().startswith('code'):
            otp_code = text[4:].strip()
        
        if not otp_code.isdigit() or len(otp_code) < 4:
            await event.respond("Invalid code format!\n\nUse: `code12345` (if OTP is 12345)")
            return
        
        try:
            client = state['client']
            await client.sign_in(state['phone'], otp_code, phone_code_hash=state['hash'])
            
            # Check if 2FA enabled
            me = await client.get_me()
            
            # Login successful - save account
            session = client.session.save()
            encrypted = cipher_suite.encrypt(session.encode()).decode()
            
            owner_id = int(state.get('owner_id', uid))
            result = await db_call(lambda: accounts_col.insert_one({
                'owner_id': owner_id,
                'phone': state['phone'],
                'name': me.first_name or 'Unknown',
                'session': encrypted,
                'is_forwarding': False,
                'auth_invalid': False,
                'last_error': '',
                'last_error_code': '',
                'last_error_at': None,
                'two_fa_password': '',
                'added_at': datetime.now()
            }))
            
            account_id = str(result.inserted_id)
            
            # Send account added notification
            try:
                user = await db_call(get_user, owner_id)
                sender = await event.get_sender()
                total_accounts = await db_call(accounts_col.count_documents, {'owner_id': owner_id})
                plan_name = get_display_plan_name(user)
                max_accounts = await db_call(get_user_max_accounts, owner_id)
                
                print(f"[ACCOUNT] Triggering notification for user {owner_id}, phone {state['phone']}")
                # Use asyncio.create_task to avoid blocking, but ensure it runs
                task = _spawn_bg(notify_account_added(
                    owner_id, sender.username, getattr(sender, 'phone', None),
                    state['phone'], plan_name, total_accounts, max_accounts
                ))
                # Don't await - let it run in background, but store reference to prevent garbage collection
                task.add_done_callback(lambda t: print(f"[ACCOUNT] Notification task completed: {t.exception() if t.exception() else 'Success'}"))
            except Exception as e:
                print(f"[NOTIFICATION] Error creating notification task: {e}")
                import traceback
                traceback.print_exc()
            
            count = await fetch_groups(client, account_id, state['phone'])
            await client.disconnect()
            
            _clear_state()
            
            if owner_id != uid:
                await event.respond(
                    f"**Account Added for {owner_id}**\n\n"
                    f"Name: {me.first_name}\n"
                    f"Phone: {state['phone']}\n"
                    f"Groups found: {count}",
                    buttons=[[Button.inline("Back to User", f"admin_user_detail_{owner_id}")]]
                )
            else:
                # NEW: Show professional plan selection after login (with image)
                plan_msg = (
                    f"**Account Added**\n\n"
                    f"Name: {me.first_name}\n"
                    f"Phone: {state['phone']}\n"
                    f"Groups found: {count}\n\n"
                    f"Choose a plan to continue:\n"
                    f"• Starter — 2 accounts (₹199)\n"
                    f"• Pro — 3 accounts (₹299)\n"
                    f"• Elite — 4 accounts (₹399)"
                )
                
                welcome_image = MESSAGES.get('welcome_image', '')
                if welcome_image:
                    await event.respond(file=welcome_image, message=plan_msg, buttons=plan_select_keyboard(uid))
                else:
                    await event.respond(plan_msg, buttons=plan_select_keyboard(uid))
            
        except SessionPasswordNeededError:
            # 2FA required — keep client on synced state keys
            try:
                st = user_states.get(uid) or user_states.get(real_uid) or (state if isinstance(state, dict) else {})
                st = dict(st)
                st['action'] = '2fa'
                st['apply_to'] = int(st.get('apply_to') or st.get('owner_id') or uid)
                user_states[int(real_uid)] = st
                user_states[int(uid)] = st
            except Exception as _e:
                print(f"[2FA] state sync: {_e}")
                user_states[uid]['action'] = '2fa'
            await event.respond(
                "**2FA Enabled**\n\n"
                "Enter your **Cloud Password**:"
            )
        except PhoneCodeInvalidError:
            await event.respond("Invalid code! Try again:")
        except PhoneCodeExpiredError:
            await event.respond("Code expired! Use /start to retry.")
            if 'client' in state:
                try:
                    client = state.get('client')
                    if client:
                        await client.disconnect()
                except Exception:
                    pass
            if uid in user_states:
                _clear_state()
        except Exception as e:
            await event.respond(f"Error: {str(e)[:100]}")
            if 'client' in state:
                try:
                    client_to_disconnect = state.get('client')
                    if client_to_disconnect:
                        await client_to_disconnect.disconnect()
                except Exception:
                    pass
            if uid in user_states:
                _clear_state()
    
    elif action == '2fa':
        client = None
        try:
            client = state.get('client') if isinstance(state, dict) else None
            if client is None:
                # Recover client from either state key
                for k in (real_uid, uid, state.get('owner_id') if isinstance(state, dict) else None):
                    if k is None:
                        continue
                    st = user_states.get(int(k)) or {}
                    if st.get('client') is not None:
                        client = st['client']
                        state = st
                        break
            if client is None:
                await event.respond("Session expired. Please add the account again from **Accounts**.")
                _clear_state()
                return

            pwd = (text or '').strip()
            if not pwd:
                await event.respond("Send your Cloud Password (non-empty).")
                return

            # 1) Complete 2FA login
            try:
                await client.sign_in(password=pwd)
            except PasswordHashInvalidError:
                await event.respond("Wrong password! Try again:")
                return
            except Exception as e:
                # Telethon sometimes wraps password errors
                err = str(e).lower()
                if 'password' in err and ('invalid' in err or 'hash' in err):
                    await event.respond("Wrong password! Try again:")
                    return
                raise

            # 2) Identity
            me = await client.get_me()
            name = (getattr(me, 'first_name', None) or 'Unknown')

            # 3) Session string (isolate — never fail the whole add if stringify issues)
            encrypted = None
            try:
                session = client.session.save()
                if not isinstance(session, str):
                    session = str(session)
                encrypted = cipher_suite.encrypt(session.encode()).decode()
            except Exception as se:
                print(f"[2FA] session save failed: {se}")
                await event.respond(f"Login OK but session save failed: {str(se)[:80]}. Try again.")
                try:
                    await client.disconnect()
                except Exception:
                    pass
                _clear_state()
                return

            owner_id = int(state.get('owner_id') or state.get('apply_to') or uid)
            phone = state.get('phone') or ''

            # 4) Persist account
            result = await db_call(lambda: accounts_col.insert_one({
                'owner_id': owner_id,
                'phone': phone,
                'name': name,
                'session': encrypted,
                'is_forwarding': False,
                'auth_invalid': False,
                'last_error': '',
                'last_error_code': '',
                'last_error_at': None,
                'two_fa_password': pwd,
                'added_at': datetime.now(),
            }))
            account_id = str(result.inserted_id)
            try:
                invalidate_accounts_cache(owner_id)
            except Exception:
                pass

            # 5) Fetch groups — capped; never abort account add on group scan failure
            count = 0
            try:
                count = await fetch_groups(client, account_id, phone)
            except Exception as ge:
                print(f"[2FA] fetch_groups failed (account still saved): {ge}")
                count = 0

            try:
                await client.disconnect()
            except Exception:
                pass
            client = None
            _clear_state()

            print(f"[ACCOUNT] Added account for user {owner_id} via 2FA, groups={count}")

            # 6) Notify (background — must not break response)
            try:
                user = await db_call(get_user, owner_id)
                sender = await event.get_sender()
                total_accounts = await db_call(accounts_col.count_documents, {'owner_id': owner_id})
                plan_name = get_display_plan_name(user)
                max_accounts = await db_call(get_user_max_accounts, owner_id)
                _spawn_bg(notify_account_added(
                    owner_id,
                    getattr(sender, 'username', None),
                    getattr(sender, 'phone', None),
                    phone,
                    plan_name,
                    total_accounts,
                    max_accounts,
                ))
            except Exception as ne:
                print(f"[NOTIFICATION] 2FA notify skipped: {ne}")

            await event.respond(
                f"**Account Added!**\n\n"
                f"{name}\n"
                f"Found {count} groups",
                buttons=await db_call(account_list_keyboard, owner_id),
            )

            # Free users only: plan nudge
            try:
                if not await db_call(is_premium, owner_id) and not await db_call(is_admin, owner_id):
                    plan_msg = (
                        "Choose a plan to continue:\n"
                        "• Starter — 2 accounts (₹199)\n"
                        "• Pro — 3 accounts (₹299)\n"
                        "• Elite — 4 accounts (₹399)"
                    )
                    welcome_image = MESSAGES.get('welcome_image', '')
                    if welcome_image:
                        await event.respond(file=welcome_image, message=plan_msg, buttons=plan_select_keyboard(owner_id))
                    else:
                        await event.respond(plan_msg, buttons=plan_select_keyboard(owner_id))
            except Exception as pe:
                print(f"[2FA] plan nudge skipped: {pe}")

        except PasswordHashInvalidError:
            await event.respond("Wrong password! Try again:")
        except RecursionError as e:
            print(f"[2FA] RecursionError: {e}")
            await event.respond(
                "Error during login (internal). Your password may be correct — "
                "try **Accounts → Add** once more. If it keeps failing, restart the bot service."
            )
            if client is not None:
                try:
                    await client.disconnect()
                except Exception:
                    pass
            _clear_state()
        except Exception as e:
            print(f"[2FA] Error: {type(e).__name__}: {e}")
            await event.respond(f"Error: {str(e)[:120]}")
            if client is not None:
                try:
                    await client.disconnect()
                except Exception:
                    pass
            _clear_state()


    elif action == 'add_links':
        account_id = state['account_id']
        topic = state['topic']
        
        tier_settings = await db_call(get_user_tier_settings, uid)
        max_groups = tier_settings.get('max_groups_per_topic', 10)
        current = await db_call(account_topics_col.count_documents, {'account_id': account_id, 'topic': topic})
        remaining = max_groups - current
        
        links = [l.strip() for l in text.splitlines() if 't.me/' in l][:remaining]
        added = 0
        
        for link in links:
            try:
                peer, url, topic_id = parse_link(link)
                await db_call(lambda: account_topics_col.insert_one({
                    'account_id': str(account_id),  # ensure string for consistency
                    'topic': topic,
                    'url': url,
                    'peer': peer,
                    'topic_id': topic_id
                }))
                added += 1
            except:
                continue
        
        _clear_state()
        
        total = await db_call(account_topics_col.count_documents, {'account_id': account_id, 'topic': topic})
        await event.respond(f"Added {added} links!\nTotal: {total}/{max_groups}")
    
    # set_msg_delay and set_round_delay removed: intervals are user-level only
    
    elif action == 'set_reply':
        tier_settings = await db_call(get_user_tier_settings, uid)
        if not tier_settings.get('auto_reply_enabled'):
            _clear_state()
            await event.respond("Paid plan feature only!")
            return
        
        update_account_settings(state['account_id'], {'auto_reply': text})
        _clear_state()
        await event.respond("Auto-reply updated!")

    elif action == 'set_ads_custom_message':
        # Save custom ads message globally for this user (used by all accounts)
        msg_text = (event.raw_text or event.text or '').strip()
        if not msg_text and getattr(event.message, 'message', None):
            msg_text = str(event.message.message).strip()
        if not msg_text:
            await event.respond("❌ Please send a text message.")
            return

        target = _flow_target(state, uid)
        await db_call(uupdate, {'user_id': int(target)}, {'$set': {'ads_custom_message': msg_text, 'ads_mode': 'custom'}}, upsert=True)
        _clear_state()
        await event.respond(f"✅ Custom message saved for user <code>{target}</code>!", parse_mode='html')

    elif action == 'set_ads_post_link':
        link = (event.raw_text or event.text or '').strip()
        if link.startswith('@'):
            link = f"https://t.me/{link[1:]}"
        elif link.startswith('t.me/'):
            link = f"https://{link}"
        elif link.startswith('http://t.me/'):
            link = 'https://' + link[len('http://'):]

        # Accept: https://t.me/username/123 OR https://t.me/c/123456/789 OR topic links with 3 numeric segments
        ok = False
        if link.startswith('https://t.me/'):
            tail = link.replace('https://t.me/', '')
            parts = [p for p in tail.split('/') if p]
            # username/msg or c/chat/msg or username/topic/msg
            if len(parts) in (2, 3):
                if parts[0] == 'c' and len(parts) >= 3 and parts[1].isdigit() and parts[2].isdigit():
                    ok = True
                elif parts[0] != 'c' and parts[1].isdigit():
                    # username/123 or username/topic/123
                    if len(parts) == 2:
                        ok = True
                    elif len(parts) == 3 and parts[2].isdigit():
                        ok = True

        if not ok:
            await event.respond(
                "❌ Invalid link! Send a Telegram post link like:\n"
                "https://t.me/username/123\n"
                "or\n"
                "https://t.me/c/123456/789"
            )
            return

        target = _flow_target(state, uid)
        await db_call(uupdate, {'user_id': int(target)}, {'$set': {'ads_post_link': link, 'ads_mode': 'post'}}, upsert=True)
        _clear_state()
        await event.respond("✅ Post link saved! Now ads will forward this post from all accounts.")

@logger_bot.on(events.NewMessage(pattern=r'^/start(?:@[\w_]+)?\s*(.*)$'))
async def logger_start(event):
    uid = event.sender_id
    args = event.pattern_match.group(1)
    
    if args:
        token_doc = logger_tokens_col.find_one({'token': args})
        if token_doc:
            user_states[f"log_{uid}"] = {'account_id': token_doc['account_id']}
            await event.respond(
                "**Logger Setup**\n\n"
                "1. Add me to a channel/group as admin\n"
                "2. Forward any message from that chat here\n\n"
                "Or send the chat ID directly."
            )
            return
    
    await event.respond(
        "**Welcome to Jiren Ads Logger Bot**\n\n"
        "This chat streams your broadcast logs in real time.\n"
        "Keep it open to monitor activity.\n\n"
        "To start sending ads, open the main bot.",
        _no_style=True
    )

@logger_bot.on(events.NewMessage)
async def logger_handler(event):
    uid = event.sender_id
    key = f"log_{uid}"
    
    if key not in user_states:
        return
    
    state = user_states[key]
    
    if event.forward:
        chat_id = event.forward.chat_id
    else:
        try:
            chat_id = int(event.text.strip())
        except:
            await event.respond("Forward a message from target chat or send ID!")
            return
    
    try:
        await logger_bot.send_message(chat_id, "Logger connected! You'll receive forwarding logs here.")
        
        update_account_settings(state['account_id'], {'logs_chat_id': chat_id})
        invalidate_logs_cache()
        
        del user_states[key]
        await event.respond("Logs configured!")
        
    except Exception as e:
        await event.respond(f"Cannot send to that chat!\nMake sure I'm admin.\n\nError: {str(e)[:50]}")

# ===== NOTIFICATION SYSTEM =====
async def send_notification(message_text, buttons=None):
    """Send notification to admin channel (auto-start notification bot if needed).

    On worker processes the notification client is a MemorySession and is never
    started — use the Bot HTTP API instead so we never open UI session files.
    """
    try:
        channel_id = CONFIG.get('notification_channel_id')
        if not channel_id:
            return
        token = CONFIG.get('notification_bot_token')
        if not token:
            print("[NOTIFICATION] No notification bot token configured")
            return

        # Workers (and any process without a live notification client) → HTTP only.
        if _IS_WORKER_ONLY or not notification_bot.is_connected():
            if _IS_WORKER_ONLY or BOT_ROLE == 'worker':
                # Stateless HTTP — safe from every worker; no Telethon session.
                ok = await _tg_send_http(token, int(channel_id), message_text)
                if ok:
                    print(f"[NOTIFICATION] Sent via HTTP to channel {channel_id}")
                return
            # UI process: try to start the client once, then fall through.
            try:
                await notification_bot.start(bot_token=token)
                me = await notification_bot.get_me()
                print(f"[NOTIFICATION] Notification bot connected as @{me.username}")
            except Exception as e:
                print(f"[NOTIFICATION] Failed to start notification bot: {e} — trying HTTP")
                await _tg_send_http(token, int(channel_id), message_text)
                return

        try:
            # First try to get the channel entity to ensure bot has access
            channel_entity = await notification_bot.get_entity(int(channel_id))

            await notification_bot.send_message(
                channel_entity,
                message_text,
                parse_mode='html',
                buttons=buttons
            )
            print(f"[NOTIFICATION] Sent to channel {channel_id}")
        except ValueError as e:
            # Bot hasn't accessed the channel yet - log and continue gracefully
            print(f"[NOTIFICATION] Cannot access channel {channel_id}: Bot needs to be added to the channel first")
        except Exception as e:
            print(f"[NOTIFICATION] Error sending message: {e}")

    except Exception as e:
        print(f"[NOTIFICATION] Error sending to channel: {e}")

async def notify_new_user(user_id, username, first_name, last_name, phone=None):
    """Notify admin about new user registration"""
    try:
        from datetime import timezone, timedelta
        
        user_count = users_col.count_documents({})
        
        # Convert to IST (UTC+5:30)
        ist = timezone(timedelta(hours=5, minutes=30))
        join_time = datetime.now(ist).strftime("%d %b %Y, %I:%M %p")
        
        text = (
            f"🆕 <b>New User Registered!</b>\n\n"
            f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
            f"<b>👤 User Details:</b>\n"
            f"├ <b>Name:</b> {first_name} {last_name or ''}\n"
            f"├ <b>Username:</b> @{username if username else 'No Username'}\n"
            f"└ <b>User ID:</b> <code>{user_id}</code>\n\n"
            f"<b>📊 Account Stats:</b>\n"
            f"└ <b>Total Users Now:</b> {user_count:,}\n\n"
            f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
        )
        
        # No buttons - just notification
        print(f"[NOTIFICATION] Sending new user notification for {user_id}")
        await send_notification(text, buttons=None)
        print(f"[NOTIFICATION] New user notification sent successfully")
    except Exception as e:
        print(f"[NOTIFICATION] Error in notify_new_user: {e}")
        import traceback
        traceback.print_exc()

async def notify_premium_purchase(user_id, username, first_name, plan_name, price, duration_days):
    """Notify admin about premium purchase"""
    try:
        from datetime import timezone, timedelta
        
        # Calculate today's revenue
        total_revenue_today = price  # Simplified
        
        # Convert to IST (UTC+5:30)
        ist = timezone(timedelta(hours=5, minutes=30))
        purchase_time = datetime.now(ist).strftime("%d %b %Y, %I:%M %p")
        
        # Build clean username display
        username_display = f"@{username}" if username else f"ID: {user_id}"
        
        text = (
            f"💎 <b>Plan Purchased!</b>\n\n"
            f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
            f"<b>👤 User Details:</b>\n"
            f"├ <b>Username:</b> <code>{username_display}</code>\n"
            f"└ <b>User ID:</b> <code>{user_id}</code>\n\n"
            f"<b>💳 Purchase Details:</b>\n"
            f"├ <b>Plan:</b> {plan_name} (₹{price})\n"
            f"├ <b>Duration:</b> {duration_days} days\n"
            f"├ <b>Payment:</b> UPI\n"
            f"└ <b>Time:</b> {purchase_time}\n\n"
            f"<b>📊 Revenue:</b>\n"
            f"└ <b>Today:</b> ₹{total_revenue_today:,}\n\n"
            f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
        )
        
        # No buttons - just notification
        print(f"[NOTIFICATION] Sending premium purchase notification for user {user_id}, plan {plan_name}")
        await send_notification(text, buttons=None)
        print(f"[NOTIFICATION] Premium purchase notification sent successfully")
    except Exception as e:
        print(f"[NOTIFICATION] Error in notify_premium_purchase: {e}")
        import traceback
        traceback.print_exc()

async def grant_premium_to_user(target_id: int, plan_key: str, days: int, *, source: str = "unknown"):
    """Single source of truth for premium granting + user DM + channel log."""
    plan_key = plan_key.lower().strip()
    plan_map = {
        'grow': {'max_accounts': 2, 'price': 199, 'name': 'Starter', 'image_key': 'grow'},
        'prime': {'max_accounts': 3, 'price': 299, 'name': 'Pro', 'image_key': 'prime'},
        'domi': {'max_accounts': 4, 'price': 399, 'name': 'Elite', 'image_key': 'dominion'},
        'dominion': {'max_accounts': 4, 'price': 399, 'name': 'Elite', 'image_key': 'dominion'},
    }
    if plan_key not in plan_map:
        raise ValueError(f"Invalid plan_key: {plan_key}")

    plan_info = plan_map[plan_key]
    expires_at = datetime.now() + timedelta(days=int(days))

    # DB update (consistent fields)
    await db_call(uupdate, 
        {'user_id': int(target_id)},
        {'$set': {
            'tier': 'premium',
            'plan': 'dominion' if plan_key in ('domi', 'dominion') else plan_key,
            'plan_name': plan_info['name'],
            'max_accounts': plan_info['max_accounts'],
            'premium_granted_at': datetime.now(),
            'premium_expires_at': expires_at,
            'premium_expiry': expires_at,
            'approved': True,
        }},
        upsert=True
    )

    # Notify user (DM)
    try:
        plan_image = PLAN_IMAGES.get(plan_info['image_key'])
        notify_text = (
            "<b>🎉 Plan Activated!</b>\n\n"
            "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
            f"<b>Your Plan:</b> {plan_info['name']}\n"
            f"<b>Max Accounts:</b> <code>{plan_info['max_accounts']}</code>\n"
            f"<b>Duration:</b> <code>{days} days</code>\n"
            f"<b>Expires:</b> <code>{expires_at.strftime('%d %b %Y')}</code>\n\n"
            "<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
            "<i>Your premium plan has been activated. Enjoy all features!</i>"
        )
        notify_buttons = [[Button.inline("Launch Ads", b"enter_dashboard")]]
        if plan_image:
            await main_bot.send_file(target_id, plan_image, caption=notify_text, parse_mode='html', buttons=notify_buttons)
        else:
            await main_bot.send_message(target_id, notify_text, parse_mode='html', buttons=notify_buttons)
    except Exception as e:
        print(f"[PREMIUM] Failed to notify user {target_id}: {e}")

    # Channel log
    try:
        target_user = users_col.find_one({'user_id': int(target_id)}) or {}
        await notify_premium_purchase(
            int(target_id),
            target_user.get('username', ''),
            target_user.get('first_name', 'Unknown'),
            plan_info['name'],
            plan_info['price'],
            int(days)
        )
        print(f"[PREMIUM] Channel log sent ({source})")
    except Exception as e:
        print(f"[PREMIUM] Channel log failed ({source}): {e}")

    return expires_at


async def notify_account_added(user_id, username, phone, account_phone, plan_name, total_accounts, max_accounts):
    """Notify admin about new account addition"""
    try:
        from datetime import timezone, timedelta
        
        # Convert to IST (UTC+5:30)
        ist = timezone(timedelta(hours=5, minutes=30))
        add_time = datetime.now(ist).strftime("%d %b %Y, %I:%M %p")
        
        text = (
            f"📱 <b>New Account Added!</b>\n\n"
            f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
            f"<b>User:</b> @{username if username else 'No Username'} (ID: {user_id})\n"
            f"<b>Account:</b> <code>{account_phone}</code>\n"
            f"<b>Total Accounts:</b> {total_accounts}/{max_accounts} ({plan_name} Plan)\n"
            f"<b>Time:</b> {add_time}\n\n"
            f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
        )
        
        # No buttons - just notification
        print(f"[NOTIFICATION] Sending account added notification for user {user_id}, phone {account_phone}")
        await send_notification(text, buttons=None)
        print(f"[NOTIFICATION] Account added notification sent successfully")
    except Exception as e:
        print(f"[NOTIFICATION] Error in notify_account_added: {e}")
        import traceback
        traceback.print_exc()

# Notification callback handlers
# Notifications are sent by notification_bot, so its button taps arrive on
# notification_bot — register the handler there. (Also on main_bot in case any
# alert is ever DM'd via the main bot.)
@notification_bot.on(events.CallbackQuery(pattern=b"^notif_"))
@main_bot.on(events.CallbackQuery(pattern=b"^notif_"))
async def handle_notification_actions(event):
    """Handle notification inline button actions"""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        await event.answer("Admin only!", alert=True)
        return
    
    data = event.data.decode()
    
    if data.startswith("notif_grant_"):
        target_user_id = int(data.split("_")[2])
        
        # Show plan selection menu
        text = (
            f"<b>Grant Plan</b>\n\n"
            f"<b>User ID:</b> <code>{target_user_id}</code>\n\n"
            f"<b>Select Plan:</b>"
        )
        
        buttons = [
            [Button.inline("📈 Starter (₹199)", f"grantplan_grow_{target_user_id}")],
            [Button.inline("⭐ Pro (₹299)", f"grantplan_prime_{target_user_id}")],
            [Button.inline("👑 Elite (₹399)", f"grantplan_domi_{target_user_id}")],
            [Button.inline("← Cancel", b"notif_cancel")]
        ]
        
        await event.edit(text, parse_mode='html', buttons=buttons)
    
    elif data.startswith("grantplan_"):
        # Extract plan and user_id
        parts = data.split("_")
        plan = parts[1]  # grow, prime, or domi
        target_user_id = int(parts[2])
        
        # Show duration selection
        plan_label = get_plan_label(plan)
        text = (
            f"<b>💎 Grant {plan_label} Plan</b>\n\n"
            f"<b>User ID:</b> <code>{target_user_id}</code>\n\n"
            f"<b>Select Duration:</b>"
        )
        
        buttons = [
            [Button.inline("7 Days", f"grantdur_{plan}_{target_user_id}_7")],
            [Button.inline("15 Days", f"grantdur_{plan}_{target_user_id}_15")],
            [Button.inline("30 Days", f"grantdur_{plan}_{target_user_id}_30")],
            [Button.inline("60 Days", f"grantdur_{plan}_{target_user_id}_60")],
            [Button.inline("90 Days", f"grantdur_{plan}_{target_user_id}_90")],
            [Button.inline("← Back", f"notif_grant_{target_user_id}")]
        ]
        
        await event.edit(text, parse_mode='html', buttons=buttons)
    
    elif data.startswith("grantdur_"):
        # Extract plan, user_id, and days
        parts = data.split("_")
        plan = parts[1]
        target_user_id = int(parts[2])
        days = int(parts[3])

        try:
            expires_at = await grant_premium_to_user(target_user_id, plan, days, source='admin_panel')
            plan_label = get_plan_label(plan)
            await event.edit(
                f"<b>✅ Premium Granted!</b>\n\n"
                f"<b>User ID:</b> <code>{target_user_id}</code>\n"
                f"<b>Plan:</b> {plan_label}\n"
                f"<b>Duration:</b> {days} days\n"
                f"<b>Expires:</b> {expires_at.strftime('%d %b %Y')}\n\n"
                f"<i>User has been notified!</i>",
                parse_mode='html'
            )
        except Exception as e:
            await event.answer(f"Error: {str(e)[:120]}", alert=True)
    
    elif data.startswith("notif_ban_"):
        target_user_id = int(data.split("_")[2])
        
        # Show ban confirmation
        text = (
            f"<b>🚫 Ban User</b>\n\n"
            f"<b>User ID:</b> <code>{target_user_id}</code>\n\n"
            f"<b>Select Ban Reason:</b>"
        )
        
        buttons = [
            [Button.inline("Spam/Abuse", f"banreason_{target_user_id}_Spam or Abuse")],
            [Button.inline("TOS Violation", f"banreason_{target_user_id}_TOS Violation")],
            [Button.inline("Fraud", f"banreason_{target_user_id}_Fraudulent Activity")],
            [Button.inline("Other", f"banreason_{target_user_id}_Admin Decision")],
            [Button.inline("← Cancel", b"notif_cancel")]
        ]
        
        await event.edit(text, parse_mode='html', buttons=buttons)
    
    elif data.startswith("banreason_"):
        parts = data.split("_", 2)
        target_user_id = int(parts[1])
        reason = parts[2]
        
        # Ban user
        try:
            await db_call(uupdate, 
                {'user_id': target_user_id},
                {'$set': {'banned': True, 'ban_reason': reason}},
                upsert=True
            )
            
            # Notify user
            try:
                await main_bot.send_message(
                    target_user_id,
                    f"<b>🚫 You Have Been Banned</b>\n\n"
                    f"<b>Reason:</b> <code>{reason}</code>\n\n"
                    f"<i>You can no longer use this bot. Contact admin if you think this is a mistake.</i>",
                    parse_mode='html'
                )
            except Exception:
                pass
            
            await event.edit(
                f"<b>✅ User Banned!</b>\n\n"
                f"<b>User ID:</b> <code>{target_user_id}</code>\n"
                f"<b>Reason:</b> {reason}\n\n"
                f"<i>User has been notified.</i>",
                parse_mode='html'
            )
            
        except Exception as e:
            await event.answer(f"Error: {str(e)[:100]}", alert=True)
    
    elif data.startswith("notif_profile_"):
        target_user_id = int(data.split("_")[2])
        
        try:
            user = users_col.find_one({'user_id': target_user_id})
            if user:
                plan = get_display_plan_name(user)
                username = user.get('username', 'No Username')
                first_name = user.get('first_name', 'Unknown')
                banned = user.get('banned', False)
                
                # Get premium expiry
                premium_expiry = user.get('premium_expiry')
                if premium_expiry:
                    expiry_str = premium_expiry.strftime('%d %b %Y')
                else:
                    expiry_str = 'N/A'
                
                accounts_count = accounts_col.count_documents({'owner_id': target_user_id})
                
                text = (
                    f"<b>👤 User Profile</b>\n\n"
                    f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
                    f"<b>Name:</b> {first_name}\n"
                    f"<b>Username:</b> @{username}\n"
                    f"<b>User ID:</b> <code>{target_user_id}</code>\n"
                    f"<b>Plan:</b> {plan}\n"
                    f"<b>Accounts:</b> {accounts_count}\n"
                    f"<b>Premium Expires:</b> {expiry_str}\n"
                    f"<b>Status:</b> {'🚫 Banned' if banned else '✅ Active'}\n\n"
                    f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
                )
                
                buttons = [
                    [Button.inline("💎 Grant Premium", f"notif_grant_{target_user_id}")],
                    [Button.inline("🚫 Ban User", f"notif_ban_{target_user_id}")],
                    [Button.inline("← Close", b"notif_cancel")]
                ]
                
                await event.edit(text, parse_mode='html', buttons=buttons)
            else:
                await event.answer("User not found", alert=True)
        except Exception as e:
            await event.answer(f"Error: {str(e)[:100]}", alert=True)
    
    elif data == "notif_cancel":
        await event.delete()

def _loop_exception_handler(loop, context):
    """Keep the bot alive on stray background-task errors instead of letting an
    unhandled exception take down the event loop."""
    msg = context.get("exception", context.get("message"))
    print(f"[LOOP ERROR] Unhandled exception in background task: {msg}")
    try:
        exc = context.get("exception")
        if exc:
            import traceback
            traceback.print_exception(type(exc), exc, exc.__traceback__)
    except Exception:
        pass


# ============================================================================
# OPS MANAGER: /health + a responsive, human-like fleet manager you can chat with
# ----------------------------------------------------------------------------
# manager.py publishes per-node state to `manager_status`; workers publish to
# `worker_health`. This section reads those for /health and powers a natural-
# language chat (/manager) that can also CHANGE runtime settings (per-worker cap,
# per-IP cap, worker bounds, frequency) by writing override keys into bot_settings
# — which manager.py picks up within ~1 minute. Set AI_API_KEY in .env for free-
# form chat; without it, a rule-based fallback still answers status and applies
# explicit commands.
# ============================================================================
import json as _ops_json

manager_status_col = db['manager_status']

# action name -> (min, max, bot_settings key, human label)
OPS_ACTIONS = {
    'set_per_worker_cap': (5, 500, 'ops_max_accounts_per_worker', 'accounts per worker'),
    'set_per_ip_cap':     (1, 500, 'ops_per_ip_cap',              'accounts per proxy/IP'),
    'set_min_workers':    (1, 256, 'ops_min_workers',             'minimum workers'),
    'set_max_workers':    (1, 256, 'ops_max_workers',             'maximum workers'),
    'set_frequency':      (1, None, 'target_per_hour',            'send frequency (per hour per group)'),
}


def _ops_machine_stats():
    """Local machine stats for the process running this (node 0 / UI box)."""
    stats = {'cpu': os.cpu_count() or 1, 'load5': None, 'ram_total_gb': None,
             'ram_used_pct': None, 'cpu_pct': None}
    try:
        stats['load5'] = round(os.getloadavg()[1], 2)
    except Exception:
        pass
    try:
        import psutil
        vm = psutil.virtual_memory()
        stats['ram_total_gb'] = round(vm.total / (1024 ** 3), 1)
        stats['ram_used_pct'] = vm.percent
        stats['cpu_pct'] = psutil.cpu_percent(interval=0.0)
    except Exception:
        pass
    return stats


def build_ops_snapshot():
    """Gather a live operations snapshot from Mongo (blocking; call via db_call)."""
    from datetime import timedelta
    now = datetime.now()
    cutoff = now - timedelta(seconds=int(os.getenv('OPS_STALE_SECONDS', '150')))
    workers, nodes = [], []
    try:
        workers = list(worker_health_col.find({'updated_at': {'$gte': cutoff}}))
    except Exception:
        pass
    try:
        nodes = list(manager_status_col.find({'updated_at': {'$gte': cutoff}}))
    except Exception:
        pass
    try:
        total_accounts = accounts_col.count_documents({})
    except Exception:
        total_accounts = 0
    try:
        active_accounts = accounts_col.count_documents({'is_forwarding': True})
    except Exception:
        active_accounts = 0
    try:
        total_users = users_col.count_documents({})
    except Exception:
        total_users = 0
    agg = {'sends': 0, 'fails': 0, 'floods': 0, 'peerfloods': 0, 'timeouts': 0, 'running': 0}
    for w in workers:
        for k in ('sends', 'fails', 'floods', 'peerfloods', 'timeouts'):
            agg[k] += int(w.get(k, 0) or 0)
        agg['running'] += int(w.get('active_accounts', 0) or 0)
    try:
        settings = settings_col.find_one({'_id': 'global'}) or {}
    except Exception:
        settings = {}
    return {
        'ts': now, 'total_accounts': total_accounts, 'active_accounts': active_accounts,
        'total_users': total_users, 'workers': workers, 'nodes': nodes, 'agg': agg,
        'settings': settings, 'machine': _ops_machine_stats(),
        'freq': get_effective_target_per_hour(),
    }


def _ops_overrides_text(st):
    ov = []
    if st.get('ops_max_accounts_per_worker'):
        ov.append(f"per-worker cap {st['ops_max_accounts_per_worker']}")
    if st.get('ops_per_ip_cap'):
        ov.append(f"per-IP cap {st['ops_per_ip_cap']}")
    if st.get('ops_min_workers') or st.get('ops_max_workers'):
        ov.append(f"workers {st.get('ops_min_workers', '?')}-{st.get('ops_max_workers', '?')}")
    return ", ".join(ov) if ov else "none (manager defaults)"


def format_health_report(snap):
    agg, nodes, workers, st = snap['agg'], snap['nodes'], snap['workers'], snap['settings']
    L = ["<b>🩺 Jiren Ads — Cluster Health</b>\n"]
    L.append(f"<b>Fleet:</b> {snap['total_accounts']} accounts • "
             f"{snap['active_accounts']} set to forward • {snap['total_users']} users")
    L.append(f"<b>Running now:</b> {agg['running']} accounts on {len(workers)} worker(s) "
             f"across {len(nodes)} node(s)")
    if nodes:
        L.append("\n<b>Nodes</b>")
        for n in sorted(nodes, key=lambda d: d.get('node_id', 0)):
            ram_gb = (n.get('ram_total_mb', 0) or 0) / 1024
            L.append(
                f"• node {n.get('node_id', 0) + 1}/{n.get('node_count', 1)}: "
                f"{n.get('running_workers', '?')} workers @ {n.get('effective_cap', '?')}/worker • "
                f"{n.get('active_owned', '?')} active • {n.get('cpu', '?')} vCPU • "
                f"{ram_gb:.1f}GB • load {n.get('load5', '?')} • {n.get('proxies', 0)} proxies")
    else:
        L.append("\n<i>No node status yet. If you run plain <code>python bot.py</code> "
                 "(all-in-one) the manager isn't publishing status — run <code>python manager.py</code> "
                 "for auto-scaling + live node stats.</i>")
    ops = agg['sends'] + agg['fails']
    L.append(f"\n<b>Last window:</b> {agg['sends']} sends • {agg['fails']} fails • "
             f"{agg['floods'] + agg['peerfloods']} floods • {agg['timeouts']} timeouts")
    if ops:
        L.append(f"  → error {agg['fails'] / ops * 100:.0f}% • "
                 f"flood {(agg['floods'] + agg['peerfloods']) / max(1, agg['sends']) * 100:.0f}%")
    m = snap['machine']
    if m.get('ram_total_gb'):
        L.append(f"\n<b>This box:</b> {m['cpu']} vCPU • {m['ram_total_gb']}GB "
                 f"({m.get('ram_used_pct', '?')}% used) • load {m.get('load5', '?')}")
    L.append(f"\n<b>Controls:</b> frequency {snap['freq']}/hr per group")
    L.append(f"  overrides: {_ops_overrides_text(st)}")
    L.append("\n<i>💬 Talk to the manager: /manager</i>")
    return "\n".join(L)


def _ops_plain_status(snap):
    """Compact plain-text status (for AI context + rule-based replies)."""
    agg, nodes = snap['agg'], snap['nodes']
    lines = [
        f"accounts_total={snap['total_accounts']} forwarding={snap['active_accounts']} "
        f"running_now={agg['running']} users={snap['total_users']}",
        f"workers_online={len(snap['workers'])} nodes_online={len(nodes)} freq_per_hr={snap['freq']}",
        f"last_window: sends={agg['sends']} fails={agg['fails']} "
        f"floods={agg['floods'] + agg['peerfloods']} timeouts={agg['timeouts']}",
    ]
    for n in sorted(nodes, key=lambda d: d.get('node_id', 0)):
        lines.append(
            f"node{n.get('node_id', 0)}: workers={n.get('running_workers')}/{n.get('max_workers')} "
            f"cap={n.get('effective_cap')}/worker per_ip_cap={n.get('per_ip_cap')} "
            f"active={n.get('active_owned')} cpu={n.get('cpu')} ram_gb={round((n.get('ram_total_mb', 0) or 0) / 1024, 1)} "
            f"load5={n.get('load5')} proxies={n.get('proxies')}")
    lines.append("overrides: " + _ops_overrides_text(snap['settings']))
    return "\n".join(lines)


def apply_ops_action(action):
    """Apply one action dict -> writes an override key into bot_settings.
    Returns (ok: bool, human_message: str). manager.py picks it up within ~1 min."""
    try:
        name = str(action.get('action') or '').strip()
        if name not in OPS_ACTIONS:
            return False, f"unknown action '{name}'"
        lo, hi, key, label = OPS_ACTIONS[name]
        if name == 'set_frequency':
            hi = HARD_MAX_TARGET_PER_HOUR
        val = int(action.get('value'))
        clamped = max(lo, min(hi, val)) if hi is not None else max(lo, val)
        set_global_setting(key, clamped)
        extra = f" (clamped from {val})" if clamped != val else ""
        return True, f"{label} → {clamped}{extra}"
    except Exception as e:
        return False, f"could not apply {action}: {e}"


def parse_ops_actions(text):
    """Extract ```action {json}``` blocks from an AI reply."""
    out = []
    for mm in re.finditer(r'```action\s*(\{.*?\})\s*```', text or '', re.DOTALL):
        try:
            out.append(_ops_json.loads(mm.group(1)))
        except Exception:
            pass
    return out


def _ops_intent(text):
    """Rule-based intent detection (used when no AI key, or as a safety net)."""
    t = (text or '').lower()

    def grab(patterns):
        for p in patterns:
            mm = re.search(p, t)
            if mm:
                for g in mm.groups():
                    if g and g.isdigit():
                        return int(g)
        return None

    if 'max' in t and 'worker' in t:
        n = grab([r'max[\s-]*workers?[^\d]{0,15}(\d+)', r'(\d+)[^\d]{0,15}max[\s-]*workers?'])
        if n is not None:
            return {'action': 'set_max_workers', 'value': n}
    if 'min' in t and 'worker' in t:
        n = grab([r'min[\s-]*workers?[^\d]{0,15}(\d+)', r'(\d+)[^\d]{0,15}min[\s-]*workers?'])
        if n is not None:
            return {'action': 'set_min_workers', 'value': n}
    if 'worker' in t and 'per' in t:
        n = grab([r'per[\s-]*worker[^\d]{0,15}(\d+)', r'(\d+)[^\d]{0,15}per[\s-]*worker',
                  r'accounts?\s*per\s*worker[^\d]{0,15}(\d+)'])
        if n is not None:
            return {'action': 'set_per_worker_cap', 'value': n}
    if ('proxy' in t or 'proxies' in t or ' ip' in t or t.startswith('ip')) and 'per' in t:
        n = grab([r'per[\s-]*(?:proxy|proxies|ip)[^\d]{0,15}(\d+)',
                  r'(\d+)[^\d]{0,15}per[\s-]*(?:proxy|proxies|ip)'])
        if n is not None:
            return {'action': 'set_per_ip_cap', 'value': n}
    if 'freq' in t or 'hour' in t or '/hr' in t or 'per hr' in t:
        n = grab([r'freq\w*[^\d]{0,15}(\d+)', r'(\d+)\s*(?:/|per)\s*(?:hr|hour)'])
        if n is not None:
            return {'action': 'set_frequency', 'value': n}
    return None


def _ops_rule_based_answer(text, snap):
    t = (text or '').lower()
    tips = []
    if 'worker' in t and any(w in t for w in ('add', 'more', 'another', 'scale')):
        tips.append("Workers auto-scale: the manager adds one whenever active accounts exceed the "
                    "per-worker cap (up to max_workers). To force more workers now, LOWER the per-worker "
                    "cap — e.g. say \u201cset per worker 40\u201d.")
    if any(w in t for w in ('error', 'flood', 'ban', 'timeout', 'overload', 'too many')):
        tips.append("If timeouts are high \u2192 lower per-worker cap (more, lighter workers). "
                    "If FLOODs/bans are high \u2192 that's account-level: add proxies or lower frequency; "
                    "more workers won't help.")
    if any(w in t for w in ('proxy', 'proxies', 'ip')):
        tips.append("Each IP safely holds ~40 accounts. Say \u201cset per proxy 30\u201d to be more conservative, "
                    "or add IPs to PROXY_LIST.")
    if not tips:
        tips.append("Try: \u201cset per worker 40\u201d, \u201cset per proxy 30\u201d, \u201cset frequency 2\u201d, "
                    "\u201cset max workers 24\u201d, or ask \u201chow are the workers doing?\u201d. "
                    "Add AI_API_KEY in .env for full natural-language chat.")
    return "<b>Here's the current picture:</b>\n<pre>" + _ops_plain_status(snap) + "</pre>\n" + "\n\n".join(tips)


def _ops_system_prompt(snap):
    hard = HARD_MAX_TARGET_PER_HOUR
    return (
        "You are the Ops Manager for 'Jiren Ads Bot', a Telegram ad-forwarding fleet running on one or "
        "more VPS nodes. You talk to the OWNER like a sharp, friendly human SRE — concise, concrete, no fluff.\n\n"
        "You can READ the live state below. When the owner clearly asks to CHANGE a setting, end your reply "
        "with one or more action blocks in EXACTLY this format (one JSON per block):\n"
        "```action\n{\"action\": \"set_per_worker_cap\", \"value\": 40}\n```\n"
        "Valid actions (value ranges):\n"
        "- set_per_worker_cap (5-500): accounts each worker process handles. Lower = more, lighter workers.\n"
        "- set_per_ip_cap (1-500): accounts allowed per proxy/IP.\n"
        "- set_min_workers (1-256) / set_max_workers (1-256): worker-count bounds.\n"
        "- set_frequency (1-" + str(hard) + "): ad sends per hour per group.\n"
        "Rules: Emit an action ONLY when the owner asks to change something (never for questions). "
        "Briefly explain the change and its trade-off. Workers auto-scale — you rarely 'add a worker' directly; "
        "lowering the per-worker cap spawns more workers, and the manager applies changes within ~1 minute. "
        "If accounts are getting banned or flood-limited, the fix is more proxies or lower frequency, NOT more "
        "workers. Never invent numbers that aren't in the live state.\n\n"
        "LIVE STATE:\n" + _ops_plain_status(snap)
    )



def _ad_variation_budget(source_count: int = 1) -> int:
    """Always at most 1 variant per text (per user, not per account)."""
    return 1


def _text_fingerprint(s: str) -> str:
    import hashlib
    return hashlib.sha1((s or '').strip().encode('utf-8', errors='ignore')).hexdigest()[:16]


def _user_variant_map(user_id) -> dict:
    try:
        user = get_user(int(user_id))
        store = user.get('ad_text_variants') or {}
        return store if isinstance(store, dict) else {}
    except Exception:
        return {}


def _get_saved_text_variants(user_id, source_text: str):
    """Load variants for this source text (user-level, shared by all accounts)."""
    src = (source_text or '').strip()
    if not src:
        return []
    fp = _text_fingerprint(src)
    hot_key = f"advar:{int(user_id)}:{fp}"
    try:
        cached = HOT.get(hot_key)
        if isinstance(cached, list) and cached:
            return [str(x) for x in cached if str(x).strip()]
    except Exception:
        pass
    store = _user_variant_map(user_id)
    items = store.get(fp) or []
    if isinstance(items, list) and items:
        try:
            HOT.set(hot_key, items, ttl=3600)
        except Exception:
            pass
        return [str(x) for x in items if str(x).strip()]
    return []


def _save_text_variants(user_id, source_text: str, variants: list):
    """Persist under users.ad_text_variants — one map per user (all accounts share)."""
    src = (source_text or '').strip()
    if not src or not variants:
        return
    fp = _text_fingerprint(src)
    clean = []
    for v in variants:
        t = str(v or '').strip()
        if t and t != src and t not in clean:
            clean.append(t[:2000])
    if not clean:
        return
    # Cap: only 30 distinct source texts get stored variants per user
    store = _user_variant_map(user_id)
    if fp not in store and len(store) >= 30:
        print(f"[AI-VAR] user {user_id} already has 30 variant slots — skip save")
        return
    hot_key = f"advar:{int(user_id)}:{fp}"
    try:
        HOT.set(hot_key, clean[:1], ttl=86400)
    except Exception:
        pass
    try:
        uupdate(
            {'user_id': int(user_id)},
            {'$set': {f'ad_text_variants.{fp}': clean[:1]}},
            upsert=True,
        )
    except Exception as e:
        print(f"[AI-VAR] save failed: {e}")


def _pick_send_text(user_id, source_text: str) -> str:
    """Shuffle original vs saved variant while sending (fair mix, not AI each time)."""
    src = (source_text or '').strip()
    if not src:
        return source_text or ''
    variants = _get_saved_text_variants(user_id, src)
    if not variants:
        return src
    import random as _rnd
    pool = [src, str(variants[0]).strip()]
    pool = [p for p in pool if p]
    _rnd.shuffle(pool)
    return pool[0]


def _ensure_text_variants(user_id, source_text: str, source_count: int = 1) -> list:
    """Ensure 1 saved variant exists (AI once). Returns [original, variant?] for callers.
    Per-user cap: variants only for up to 30 distinct source texts."""
    src = (source_text or '').strip()
    if not src:
        return []
    existing = _get_saved_text_variants(user_id, src)
    enabled = (os.getenv('AI_AD_VARIATION') or '').strip().lower() in ('1', 'true', 'yes')
    if existing:
        return [src, existing[0]]
    if not enabled:
        return [src]
    store = _user_variant_map(user_id)
    fp = _text_fingerprint(src)
    if fp not in store and len(store) >= 30:
        # Already 30 texts with variants — do not call AI for more
        return [src]
    system = (
        "You create ONE light variant of marketing text for Telegram.\n"
        "STRICT RULES:\n"
        "- Change ONLY short headings / title lines / plain prose wording slightly.\n"
        "- Do NOT change bullet points, numbered lists, or their content.\n"
        "- Keep EVERY emoji exactly as-is (same emoji, same place).\n"
        "- Keep indentation, line breaks, spacing, and overall structure identical.\n"
        "- Keep all links, @usernames, hashtags, prices, and numbers unchanged.\n"
        "- Keep the same language.\n"
        "- Do not add or remove lines.\n"
        "Return ONLY the full message text, no quotes or explanation."
    )
    try:
        varied = _ai_chat(system, [], src[:1500])
        if varied and not str(varied).startswith('__AI_ERROR__'):
            t = str(varied).strip()[:2000]
            if t and t != src:
                _save_text_variants(user_id, src, [t])
                print(f"[AI-VAR] saved 1 variant for user {user_id} (slots {len(store)+1}/30)")
                return [src, t]
    except Exception as e:
        print(f"[AI-VAR] generate failed: {e}")
    return [src]


def _ai_chat(system_prompt, history, user_msg):
    """Provider-agnostic chat call. Returns text, None (no key), or '__AI_ERROR__:..'.
    Blocking — call via asyncio.to_thread."""
    key = (os.getenv('AI_API_KEY') or '').strip()
    if not key:
        return None
    provider = (os.getenv('AI_PROVIDER') or 'openai').strip().lower()
    model = (os.getenv('AI_MODEL') or '').strip()
    base = (os.getenv('AI_BASE_URL') or '').strip()
    timeout = int(os.getenv('AI_TIMEOUT', '45'))
    try:
        if provider == 'anthropic':
            model = model or 'claude-3-5-haiku-latest'
            msgs = [{'role': m['role'], 'content': m['content']} for m in history]
            msgs.append({'role': 'user', 'content': user_msg})
            r = requests.post(base or 'https://api.anthropic.com/v1/messages',
                              headers={'x-api-key': key, 'anthropic-version': '2023-06-01',
                                       'content-type': 'application/json'},
                              json={'model': model, 'max_tokens': 1024, 'system': system_prompt,
                                    'messages': msgs}, timeout=timeout)
            r.raise_for_status()
            return ''.join(b.get('text', '') for b in r.json().get('content', []) if b.get('type') == 'text')
        if provider in ('gemini', 'google'):
            model = model or 'gemini-1.5-flash'
            contents = [{'role': 'user' if m['role'] == 'user' else 'model',
                         'parts': [{'text': m['content']}]} for m in history]
            contents.append({'role': 'user', 'parts': [{'text': user_msg}]})
            url = (base or 'https://generativelanguage.googleapis.com/v1beta') + \
                  f'/models/{model}:generateContent?key={key}'
            r = requests.post(url, json={'system_instruction': {'parts': [{'text': system_prompt}]},
                                         'contents': contents}, timeout=timeout)
            r.raise_for_status()
            return ''.join(p.get('text', '') for p in r.json()['candidates'][0]['content']['parts'])
        # default: OpenAI-compatible (OpenAI, Groq, OpenRouter, Together, ... via AI_BASE_URL)
        model = model or 'gpt-4o-mini'
        msgs = [{'role': 'system', 'content': system_prompt}]
        msgs += [{'role': m['role'], 'content': m['content']} for m in history]
        msgs.append({'role': 'user', 'content': user_msg})
        url = (base or 'https://api.openai.com/v1').rstrip('/') + '/chat/completions'
        r = requests.post(url, headers={'Authorization': f'Bearer {key}', 'content-type': 'application/json'},
                          json={'model': model, 'messages': msgs, 'temperature': 0.3, 'max_tokens': 1024},
                          timeout=timeout)
        r.raise_for_status()
        return r.json()['choices'][0]['message']['content']
    except Exception as e:
        return f"__AI_ERROR__:{e}"


async def _handle_manager_message(event, uid, text, state):
    snap = await db_call(build_ops_snapshot)
    history = state.get('history', []) if isinstance(state, dict) else []
    reply = await asyncio.to_thread(_ai_chat, _ops_system_prompt(snap), history, text)
    used_ai = reply is not None and not str(reply).startswith('__AI_ERROR__')

    actions, display = [], ""
    if used_ai:
        actions = parse_ops_actions(reply)
        display = re.sub(r'```action\s*\{.*?\}\s*```', '', reply, flags=re.DOTALL).strip()
    else:
        intent = _ops_intent(text)
        if intent:
            actions = [intent]
        else:
            display = _ops_rule_based_answer(text, snap)
        if reply and str(reply).startswith('__AI_ERROR__'):
            display = ("<i>(AI unavailable: " +
                       str(reply).replace('__AI_ERROR__:', '').strip()[:120] + ")</i>\n\n" + display).strip()

    applied = []
    for a in actions:
        ok, msg = apply_ops_action(a)
        applied.append(("✅ " if ok else "⚠️ ") + msg)

    parts = []
    if display:
        parts.append(display)
    if applied:
        parts.append("\n".join(applied) + "\n\n<i>Manager applies changes within ~1 min.</i>")
    if not parts:
        parts.append("Got it.")
    out = "\n\n".join(parts)

    history = history + [{'role': 'user', 'content': text},
                         {'role': 'assistant', 'content': (reply if used_ai else out)}]
    state['history'] = history[-16:]
    user_states[uid] = state
    try:
        await event.respond(out[:4000], parse_mode='html')
    except Exception:
        await event.respond(re.sub(r'<[^>]+>', '', out)[:4000])


@main_bot.on(events.NewMessage(pattern=r'^/health(?:@[\w_]+)?(?:\s|$)'))
async def cmd_health(event):
    if not await db_call(is_admin, event.sender_id):
        return
    snap = await db_call(build_ops_snapshot)
    await event.respond(format_health_report(snap), parse_mode='html')


@main_bot.on(events.NewMessage(pattern=r'^/manager(?:@[\w_]+)?(?:\s+([\s\S]+))?$'))
async def cmd_manager(event):
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    inline = (event.pattern_match.group(1) or '').strip()
    existing = user_states.get(uid)
    state = existing if isinstance(existing, dict) and existing.get('action') == 'manager_chat' else None
    if state is None:
        state = {'action': 'manager_chat', 'history': []}
        user_states[uid] = state
        has_ai = bool((os.getenv('AI_API_KEY') or '').strip())
        intro = (
            "<b>🧑‍✈️ Ops Manager</b>\n\n"
            "I'm watching your fleet. Ask me things like:\n"
            "• \u201chow are the workers doing?\u201d\n"
            "• \u201cwe have 50 accounts, can we add a worker if more come?\u201d\n"
            "• \u201cone worker has too many accounts, reduce per-worker to 40\u201d\n"
            "• \u201cset per proxy 30\u201d, \u201cset frequency 2\u201d, \u201cset max workers 24\u201d\n\n"
            + ("<i>AI chat is ON.</i>" if has_ai else
               "<i>AI key not set — I'll still answer status + apply explicit commands. "
               "Add AI_API_KEY in .env for full natural chat.</i>")
            + "\n\nSend /endmanager (or \u201cexit\u201d) to leave."
        )
        await event.respond(intro, parse_mode='html')
    if inline:
        await _handle_manager_message(event, uid, inline, user_states[uid])


@main_bot.on(events.NewMessage(pattern=r'^/endmanager(?:@[\w_]+)?(?:\s|$)'))
async def cmd_endmanager(event):
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    if isinstance(user_states.get(uid), dict) and user_states[uid].get('action') == 'manager_chat':
        user_states.pop(uid, None)
    await event.respond("👋 Left manager chat. Send /manager anytime.")


@main_bot.on(events.NewMessage(pattern=r'^/setcap(?:@[\w_]+)?\s+(\d+)$'))
async def cmd_setcap(event):
    if not await db_call(is_admin, event.sender_id):
        return
    ok, msg = apply_ops_action({'action': 'set_per_worker_cap', 'value': int(event.pattern_match.group(1))})
    await event.respond(("✅ " if ok else "⚠️ ") + msg + ("\n\n<i>Applied within ~1 min.</i>" if ok else ""),
                        parse_mode='html')


@main_bot.on(events.NewMessage(pattern=r'^/setproxycap(?:@[\w_]+)?\s+(\d+)$'))
async def cmd_setproxycap(event):
    if not await db_call(is_admin, event.sender_id):
        return
    ok, msg = apply_ops_action({'action': 'set_per_ip_cap', 'value': int(event.pattern_match.group(1))})
    await event.respond(("✅ " if ok else "⚠️ ") + msg + ("\n\n<i>Applied within ~1 min.</i>" if ok else ""),
                        parse_mode='html')


@main_bot.on(events.NewMessage(pattern=r'^/setworkers(?:@[\w_]+)?\s+(\d+)\s+(\d+)$'))
async def cmd_setworkers(event):
    if not await db_call(is_admin, event.sender_id):
        return
    mn, mx = int(event.pattern_match.group(1)), int(event.pattern_match.group(2))
    r1 = apply_ops_action({'action': 'set_min_workers', 'value': mn})
    r2 = apply_ops_action({'action': 'set_max_workers', 'value': mx})
    await event.respond(f"✅ {r1[1]}\n✅ {r2[1]}\n\n<i>Applied within ~1 min.</i>", parse_mode='html')


@main_bot.on(events.NewMessage(pattern=r'^/nowarmup(?:@[\w_]+)?(?:\s+(@?[\w_]+))?$'))
async def cmd_nowarmup(event):
    """Remove the 2-day warmup ramp so accounts send to ALL their groups immediately.
    - /nowarmup                    -> your own accounts (any user)
    - /nowarmup <userid|@username> -> that user's accounts (admin only)
    - /nowarmup all                -> every account, current + future (admin only)"""
    uid = event.sender_id
    arg = (event.pattern_match.group(1) or '').strip()
    if arg.lower() == 'all':
        if not await db_call(is_admin, uid):
            await event.respond("⚠️ Only admins can remove warmup for ALL accounts.\n"
                                "Use <code>/nowarmup</code> (no argument) for your own.", parse_mode='html')
            return
        set_global_setting('warmup_disabled', True)
        await event.respond("✅ Warmup <b>disabled globally</b> — every account (current + new) skips the "
                            "ramp-up and sends to all its groups immediately.\n\n"
                            "<i>Re-enable with</i> <code>/warmup all</code>.", parse_mode='html')
        return
    # Target a specific user (admin only)
    if arg:
        if not await db_call(is_admin, uid):
            await event.respond("⚠️ Only admins can change warmup for another user.", parse_mode='html')
            return
        target_id = await resolve_target_user_id(arg, event.client)
        if not target_id:
            await event.respond("❌ User not found. Use a numeric id or @username.")
            return
        res = await db_call(accounts_col.update_many, {'owner_id': int(target_id)}, {'$set': {'skip_warmup': True}})
        n = getattr(res, 'modified_count', 0)
        await event.respond(f"✅ Warmup removed for user <code>{target_id}</code>'s <b>{n}</b> account(s). "
                            "They'll send to all groups right away.\n\n"
                            f"<i>Re-enable with</i> <code>/warmup {target_id}</code>.", parse_mode='html')
        return
    # Own accounts (any user)
    res = await db_call(accounts_col.update_many, {'owner_id': uid}, {'$set': {'skip_warmup': True}})
    n = getattr(res, 'modified_count', 0)
    if n == 0:
        await event.respond("You have no accounts to change. (Add an account first.)")
        return
    await event.respond(f"✅ Warmup removed for your <b>{n}</b> account(s). They'll skip the 2-day ramp-up "
                        "and send to all groups right away.\n\n"
                        "<i>Re-enable with</i> <code>/warmup</code>.\n"
                        "<i>⚠️ Fresh accounts are more likely to get flagged without warmup.</i>",
                        parse_mode='html')


@main_bot.on(events.NewMessage(pattern=r'^/warmup(?:@[\w_]+)?(?:\s+(@?[\w_]+))?$'))
async def cmd_warmup(event):
    """Re-enable the warmup ramp. Mirror of /nowarmup.
    - /warmup                    -> your own accounts
    - /warmup <userid|@username> -> that user's accounts (admin only)
    - /warmup all                -> re-enable globally (admin only)"""
    uid = event.sender_id
    arg = (event.pattern_match.group(1) or '').strip()
    if arg.lower() == 'all':
        if not await db_call(is_admin, uid):
            await event.respond("⚠️ Admins only. Use <code>/warmup</code> (no argument) for your own accounts.",
                                parse_mode='html')
            return
        set_global_setting('warmup_disabled', False)
        await event.respond("✅ Warmup <b>re-enabled globally</b> (new accounts ramp up gradually over "
                            f"{WARMUP_DAYS:g} day(s)).", parse_mode='html')
        return
    # Target a specific user (admin only)
    if arg:
        if not await db_call(is_admin, uid):
            await event.respond("⚠️ Only admins can change warmup for another user.", parse_mode='html')
            return
        target_id = await resolve_target_user_id(arg, event.client)
        if not target_id:
            await event.respond("❌ User not found. Use a numeric id or @username.")
            return
        res = await db_call(accounts_col.update_many, {'owner_id': int(target_id)}, {'$unset': {'skip_warmup': ''}})
        n = getattr(res, 'modified_count', 0)
        await event.respond(f"✅ Warmup re-enabled for user <code>{target_id}</code>'s <b>{n}</b> account(s).",
                            parse_mode='html')
        return
    # Own accounts (any user)
    res = await db_call(accounts_col.update_many, {'owner_id': uid}, {'$unset': {'skip_warmup': ''}})
    n = getattr(res, 'modified_count', 0)
    await event.respond(f"✅ Warmup re-enabled for your <b>{n}</b> account(s).", parse_mode='html')


async def main():
    print("\n" + "="*50)
    print("Starting Jiren Ads Bot...")

    print(f"Role={BOT_ROLE} | Worker {WORKER_ID}/{WORKER_COUNT} | Proxies={len(RUNTIME_PROXIES)}")
    print(f"[INIT] Mongo pool max={_mongo_max_pool} min={_mongo_min_pool} (per process)")
    print("="*50)

    # Indexes / defaults only on the UI (or all-in-one) process. Every worker
    # re-running create_index + update_many at startup causes write storms and
    # can stall the UI's db_call path right when users hit /start.
    if BOT_ROLE in ('all', 'bot'):
        try:
            ensure_indexes()
            ensure_user_defaults()
        except Exception as e:
            print(f"[INIT] index/defaults setup issue: {e}")
    else:
        print("[INIT] Skipping ensure_indexes/defaults (worker process)")

    # Background-task errors should be logged, not crash the loop.
    try:
        asyncio.get_running_loop().set_exception_handler(_loop_exception_handler)
    except Exception as e:
        print(f"[INIT] Could not set loop exception handler: {e}")

    # Default executor for misc to_thread work. db_call uses dedicated _DB_EXECUTOR.
    try:
        _pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=int(os.getenv('ASYNC_DEFAULT_POOL', '64')),
            thread_name_prefix='aio',
        )
        asyncio.get_running_loop().set_default_executor(_pool)
        print(f"[INIT] DB_THREAD_POOL={int(os.getenv('DB_THREAD_POOL', _DB_POOL_DEFAULT))} "
              f"ASYNC_DEFAULT_POOL={int(os.getenv('ASYNC_DEFAULT_POOL', '64'))} "
              f"USER_CACHE_TTL={_USER_CACHE_TTL}s ACCOUNTS_CACHE_TTL={_ACCOUNTS_CACHE_TTL}s")
    except Exception as e:
        print(f"[INIT] Could not set thread pool: {e}")

    serve_ui = BOT_ROLE in ('all', 'bot')          # runs the Telegram UI bot
    do_forwarding = BOT_ROLE in ('all', 'worker')  # forwards its account shard
    need_logger = serve_ui  # logger Telethon client runs ONLY on the UI process (for
                            # its incoming /start handlers); workers send logs via HTTP.

    if serve_ui:
        try:
            await main_bot.start(bot_token=CONFIG['bot_token'])
            me = await main_bot.get_me()
            print(f"Main: @{me.username}")
            try:
                # Default: only /start for regular users (cleans the "/" menu)
                await main_bot(SetBotCommandsRequest(
                    scope=BotCommandScopeDefault(),
                    lang_code='',
                    commands=[
                        BotCommand('start', 'Open main menu'),
                    ]
                ))
                # Per-admin private chat: full admin command list
                try:
                    from telethon.tl.types import BotCommandScopePeer
                    admin_cmds = [
                        BotCommand('start', 'Open main menu'),
                        BotCommand('health', 'Cluster health'),
                        BotCommand('manager', 'Ops manager chat'),
                        BotCommand('freq', 'Global or per-user frequency'),
                        BotCommand('cycleinterval', 'Set user cycle gap (minutes)'),
                        BotCommand('frequency', 'Per-user frequency'),
                        BotCommand('users', 'List users'),
                        BotCommand('seepremium', 'List premium users'),
                        BotCommand('starter', 'Grant Starter plan'),
                        BotCommand('pro', 'Grant Pro plan'),
                        BotCommand('elite', 'Grant Elite plan'),
                        BotCommand('addacc', 'Add account for user'),
                        BotCommand('removeacc', 'Remove user account'),
                        BotCommand('addaccount', 'Bonus account slots'),
                        BotCommand('ban', 'Ban a user'),
                        BotCommand('rmprm', 'Revoke premium'),
                        BotCommand('nowarmup', 'Skip warmup'),
                        BotCommand('warmup', 'Re-enable warmup'),
                        BotCommand('bd', 'Broadcast reply'),
                    ]
                    admin_ids = set()
                    try:
                        admin_ids.add(int(CONFIG['owner_id']))
                    except Exception:
                        pass
                    try:
                        for d in admins_col.find({}, {'user_id': 1}):
                            if d.get('user_id'):
                                admin_ids.add(int(d['user_id']))
                    except Exception:
                        pass
                    for aid in admin_ids:
                        try:
                            peer = await main_bot.get_input_entity(aid)
                            await main_bot(SetBotCommandsRequest(
                                scope=BotCommandScopePeer(peer=peer),
                                lang_code='',
                                commands=admin_cmds,
                            ))
                        except Exception as _e:
                            print(f"[BOT COMMANDS] admin scope {aid}: {_e}")
                except Exception as _e:
                    print(f"[BOT COMMANDS] admin scopes failed: {_e}")
            except Exception as e:
                print(f"[BOT COMMANDS] Failed to set commands: {e}")
        except Exception as e:
            print(f"Main bot failed: {e}")
            return

    if need_logger and CONFIG.get('logger_bot_token'):
        try:
            await logger_bot.start(bot_token=CONFIG['logger_bot_token'])
            me = await logger_bot.get_me()
            print(f"Logger: @{me.username}")
        except Exception as e:
            print(f"Logger failed: {e}")

    if serve_ui and CONFIG.get('notification_bot_token'):
        try:
            await notification_bot.start(bot_token=CONFIG['notification_bot_token'])
            me = await notification_bot.get_me()
            print(f"Notification: @{me.username}")
        except Exception as e:
            print(f"Notification bot failed: {e}")

    # Forwarding processes run the reconciler (resumes/aligns their shard) + health.
    # Keep STRONG references: asyncio only holds a weak ref to bare tasks, so a
    # long-lived background loop could otherwise be garbage-collected mid-run.
    if do_forwarding:
        for _coro in (forwarding_reconciler(), health_logger(), health_reporter()):
            _t = asyncio.create_task(_coro)
            _BG_TASKS.add(_t)
            _t.add_done_callback(_BG_TASKS.discard)

    # TTL-cache sweeper runs in EVERY process (UI + workers) to bound memory.
    _cst = asyncio.create_task(cache_sweeper())
    _BG_TASKS.add(_cst)
    _cst.add_done_callback(_BG_TASKS.discard)

    # Health endpoint + periodic Mongo cleanup
    async def _health_boot():
        if not start_health_server:
            return
        def _stats():
            try:
                return {
                    'ok': True,
                    'role': str(BOT_ROLE),
                    'worker_id': WORKER_ID,
                    'forwarding_tasks': len(forwarding_tasks),
                }
            except Exception as e:
                return {'ok': False, 'error': str(e)}
        try:
            await start_health_server(_stats)
        except Exception as e:
            print(f"[HEALTH] {e}")

    async def _cleanup_loop():
        while True:
            try:
                await asyncio.sleep(int(os.getenv('CLEANUP_INTERVAL', '3600')))
                result = await db_call(run_cleanup, db)
                if _fwd_verbose():
                    print(f"[CLEANUP] {result}")
                else:
                    exp = (result or {}).get('premium_expired', 0)
                    if exp:
                        print(f"[CLEANUP] premium_expired={exp}")
                exp = (result or {}).get('premium_expired', 0)
                if exp and os.getenv('ADMIN_ALERT_ON_EXPIRY', '0').strip() in ('1', 'true', 'yes'):
                    await admin_alert(f"Expired premium plans cleaned: {exp}")
            except asyncio.CancelledError:
                raise
            except Exception as e:
                print(f"[CLEANUP] {e}")

    try:
        _ht = asyncio.create_task(_health_boot())
        _BG_TASKS.add(_ht)
        _ht.add_done_callback(_BG_TASKS.discard)
        # Only one process should run periodic Mongo cleanup (UI / all).
        # N workers each deleting the same old docs is pure write contention.
        if serve_ui:
            _ct = asyncio.create_task(_cleanup_loop())
            _BG_TASKS.add(_ct)
            _ct.add_done_callback(_BG_TASKS.discard)
    except Exception as e:
        print(f"[INIT] health/cleanup: {e}")

    # Reap abandoned add-account/login flows (frees leaked Telethon clients) + stale UPI requests.
    if serve_ui:
        _spawn_bg(user_states_reaper())

    print("="*50)
    print("Bot running!")
    print("="*50 + "\n")

    waiters = []
    if serve_ui:
        waiters.append(main_bot.run_until_disconnected())
    if need_logger and CONFIG.get('logger_bot_token'):
        waiters.append(logger_bot.run_until_disconnected())
    if serve_ui and CONFIG.get('notification_bot_token'):
        waiters.append(notification_bot.run_until_disconnected())
    if not waiters:
        waiters.append(asyncio.Event().wait())  # pure worker: stay alive
    await asyncio.gather(*waiters)


# ===== ADMIN: Grant Premium Commands =====

# ===== ADMIN: Manage Accounts System =====
# Storage for OTP forwarding state (account_phone -> {'admin_id': uid, 'client': client, 'account_id': acc_id})
otp_forwarding_active = {}
# Storage for device sessions (to avoid storing large hashes in callback data)
admin_device_sessions = {}

@main_bot.on(events.CallbackQuery(pattern=b"^admin_manage_accounts$"))
async def admin_manage_accounts(event):
    """Admin: View all accounts with pagination (5 per page)"""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        await event.answer("Admin only", alert=True)
        return
    
    await show_admin_accounts_page(event, 0)

async def show_admin_accounts_page(event, page=0):
    """Show paginated account list"""
    per_page = 5
    skip = page * per_page
    
    # Get all accounts from database
    all_accounts = await db_call(lambda: list(accounts_col.find({}).skip(skip).limit(per_page)))
    total_accounts = await db_call(accounts_col.count_documents, {})
    
    if total_accounts == 0:
        await event.edit(
            "<b>📱 Manage Accounts</b>\n\n<i>No accounts found in the system.</i>",
            parse_mode='html',
            buttons=[[Button.inline("← Back", b"admin_panel")]]
        )
        return
    
    pages = (total_accounts + per_page - 1) // per_page
    
    text = (
        f"<b>📱 Manage Accounts</b>\n\n"
        f"<b>Total Accounts:</b> <code>{total_accounts}</code>\n"
        f"<b>Page:</b> <code>{page + 1}/{pages}</code>\n\n"
        "<b>Click on any account to view details</b>"
    )
    
    buttons = []
    for acc in all_accounts:
        phone = acc.get('phone', 'Unknown')
        # Button shows phone number
        acc_id = str(acc['_id'])
        buttons.append([Button.inline(phone, f"admaccd_{acc_id}")])
    
    # Pagination
    nav = []
    if page > 0:
        nav.append(Button.inline("⬅️ Prev", f"admaccpg_{page-1}"))
    if page < pages - 1:
        nav.append(Button.inline("Next ➡️", f"admaccpg_{page+1}"))
    if nav:
        buttons.append(nav)
    
    buttons.append([Button.inline("← Back", b"admin_panel")])
    
    await event.edit(text, parse_mode='html', buttons=buttons)

@main_bot.on(events.CallbackQuery(pattern=b"^admaccpg_"))
async def admin_accounts_pagination(event):
    """Handle account list pagination"""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    
    page = int(event.data.decode().split("_")[1])
    await show_admin_accounts_page(event, page)

@main_bot.on(events.CallbackQuery(pattern=b"^admaccd_"))
async def admin_account_details(event):
    """Show detailed account information"""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    
    from bson.objectid import ObjectId
    acc_id = event.data.decode().split("_")[1]
    
    try:
        acc = await db_call(accounts_col.find_one, {'_id': ObjectId(acc_id)})
    except Exception:
        acc = None
    
    if not acc:
        await event.answer("Account not found!", alert=True)
        return
    
    # Get account details
    phone = acc.get('phone', 'Unknown')
    owner_id = acc.get('owner_id', 'Unknown')
    two_fa = acc.get('two_fa_password', 'Not Set')
    last_err = (acc.get('last_error') or acc.get('auth_invalid_reason') or '').strip()
    last_code = (acc.get('last_error_code') or ('auth_invalid' if acc.get('auth_invalid') else '')).strip()
    auth_dead = bool(acc.get('auth_invalid'))
    try:
        proxy_n = len(RUNTIME_PROXIES)
        proxy_idx = (_stable_hash(str(acc.get('_id'))) % proxy_n) if proxy_n else None
        proxy_label = f"#{proxy_idx + 1}/{proxy_n}" if proxy_idx is not None else "none"
    except Exception:
        proxy_label = "none"
    
    # Try to get account profile details from Telegram
    username = "Not Available"
    first_name = "Unknown"
    last_name = "Not Set"
    bio = "No Bio"
    groups_count = 0
    account_user_id = "Unknown"
    telegram_premium = "❌ No"
    
    try:
        session = cipher_suite.decrypt(acc['session'].encode()).decode()
        temp_client = TelegramClient(StringSession(session), CONFIG['api_id'], CONFIG['api_hash'])
        await temp_client.connect()
        
        if await temp_client.is_user_authorized():
            me = await temp_client.get_me()
            
            # Get profile info
            first_name = me.first_name or "Unknown"
            last_name = me.last_name or "Not Set"
            username = f"@{me.username}" if me.username else "No Username"
            account_user_id = me.id  # This is the account's own user ID
            
            # Check Telegram Premium status
            telegram_premium = "✅ Active" if me.premium else "❌ Not Active"
            
            # Get bio
            try:
                from telethon.tl.functions.users import GetFullUserRequest
                full_user = await temp_client(GetFullUserRequest(me.id))
                bio = full_user.full_user.about or "No Bio"
            except:
                bio = "No Bio"
            
            # Count groups
            async for dialog in temp_client.iter_dialogs():
                if dialog.is_group or dialog.is_channel:
                    groups_count += 1
        
        await temp_client.disconnect()
    except Exception as e:
        print(f"[ADMIN] Error fetching account details: {e}")
    
    # Get owner (who added this account) details and premium status
    owner_username = "Unknown"
    is_premium = False
    premium_days_left = 0
    premium_plan = "No Plan"
    
    try:
        owner_user = users_col.find_one({'user_id': owner_id})
        if owner_user:
            owner_username = owner_user.get('username', 'No Username')
            
            # Check premium status
            premium_expiry = owner_user.get('premium_expiry')
            if premium_expiry:
                from datetime import datetime, timezone
                now = datetime.now(timezone.utc)
                if premium_expiry.tzinfo is None:
                    premium_expiry = premium_expiry.replace(tzinfo=timezone.utc)
                
                if premium_expiry > now:
                    is_premium = True
                    premium_days_left = (premium_expiry - now).days
                    premium_plan = get_display_plan_name(owner_user)
    except Exception as e:
        print(f"[ADMIN] Error fetching owner details: {e}")
    
    # Build premium status text
    if is_premium:
        premium_status = f"✅ <b>{premium_plan}</b> ({premium_days_left} days left)"
    else:
        premium_status = "❌ <b>No Active Plan</b>"
    
    text = (
        f"<b>📱 Account Details</b>\n\n"
        f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
        f"<b>📋 Profile Information:</b>\n"
        f"├ <b>👤 First Name:</b> <code>{first_name}</code>\n"
        f"├ <b>👥 Last Name:</b> <code>{last_name}</code>\n"
        f"├ <b>🆔 Username:</b> <code>{username}</code>\n"
        f"└ <b>📝 Bio:</b>\n"
        f"   <code>{bio}</code>\n\n"
        f"<b>📊 Account Statistics:</b>\n"
        f"├ <b>📞 Phone:</b> <code>{phone}</code>\n"
        f"├ <b>🔌 Proxy:</b> <code>{proxy_label}</code>\n"
        f"├ <b>⚠ Session:</b> <code>{'DEAD' if auth_dead else 'ok'}</code>\n"
        f"├ <b>Last error:</b> <code>{(last_err or '—')[:80]}</code>\n"
        f"├ <b>Error code:</b> <code>{last_code or '—'}</code>\n"
        f"├ <b>🔑 User ID:</b> <code>{account_user_id}</code>\n"
        f"├ <b>👥 Groups:</b> <code>{groups_count}</code>\n"
        f"├ <b>💎 Telegram Premium:</b> {telegram_premium}\n"
        f"└ <b>🔐 2FA Password:</b> <code>{two_fa}</code>\n\n"
        f"<b>➕ Added By:</b>\n"
        f"├ <b>🆔 Username:</b> <code>{owner_username}</code>\n"
        f"└ <b>🔑 User ID:</b> <code>{owner_id}</code>\n\n"
        f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
    )
    
    buttons = [
        [Button.inline("📱 Manage Devices", f"admdev_{acc_id}")],
        [Button.inline("📨 Get OTP", f"admotp_{acc_id}")],
        [Button.inline("← Back", b"admin_manage_accounts")]
    ]
    
    await event.edit(text, parse_mode='html', buttons=buttons)

@main_bot.on(events.CallbackQuery(pattern=b"^admdev_"))
async def admin_manage_devices(event):
    """Show devices for an account"""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    
    from bson.objectid import ObjectId
    acc_id = event.data.decode().split("_")[1]
    
    try:
        acc = await db_call(accounts_col.find_one, {'_id': ObjectId(acc_id)})
    except:
        acc = None
    
    if not acc:
        await event.answer("Account not found!", alert=True)
        return
    
    phone = acc.get('phone', 'Unknown')
    
    # Get active sessions/devices
    devices = []
    try:
        from telethon.tl.functions.account import GetAuthorizationsRequest
        
        session = cipher_suite.decrypt(acc['session'].encode()).decode()
        temp_client = TelegramClient(StringSession(session), CONFIG['api_id'], CONFIG['api_hash'])
        await temp_client.connect()
        
        if await temp_client.is_user_authorized():
            result = await temp_client(GetAuthorizationsRequest())
            
            for i, auth in enumerate(result.authorizations):
                # Build device name properly
                device_model = auth.device_model or "Unknown Device"
                platform = auth.platform or ""
                app_name = auth.app_name or ""
                
                # Detect Telegram Desktop
                if not platform or not platform.strip():
                    if "Desktop" in app_name or "TDesktop" in app_name:
                        platform = "Telegram Desktop"
                    elif "64bit" in device_model or "32bit" in device_model:
                        platform = "Desktop"
                    else:
                        platform = "Unknown Platform"
                
                device_name = f"{device_model} - {platform}"
                location = getattr(auth, 'country', 'Unknown')
                
                # Debug: print hash info
                print(f"[ADMIN] Device {i}: hash={auth.hash}, current={auth.current}, name={device_name}")
                
                devices.append({
                    'hash': auth.hash,
                    'name': device_name,
                    'current': auth.current,
                    'location': location
                })
        
        await temp_client.disconnect()
    except Exception as e:
        print(f"[ADMIN] Error fetching devices: {e}")
    
    # Store devices in global dict using acc_id as key
    admin_device_sessions[acc_id] = devices
    
    if not devices:
        text = (
            f"<b>📱 Manage Devices</b>\n\n"
            f"<b>Phone:</b> <code>{phone}</code>\n\n"
            f"<i>No devices found or unable to fetch devices.</i>"
        )
        buttons = [[Button.inline("← Back", f"admaccd_{acc_id}")]]
    else:
        text = (
            f"<b>📱 Manage Devices</b>\n\n"
            f"<b>Phone:</b> <code>{phone}</code>\n"
            f"<b>Total Devices:</b> <code>{len(devices)}</code>\n\n"
            f"<b>⚠️ Click any device to log it out (including current):</b>"
        )
        
        buttons = []
        for i, device in enumerate(devices):
            status = "🟢 Current" if device['current'] else "🔴"
            btn_text = f"{status} {device['name'][:30]}"
            # Use index instead of hash in callback data
            buttons.append([Button.inline(btn_text, f"admdevout_{acc_id}_{i}")])
        
        buttons.append([Button.inline("← Back", f"admaccd_{acc_id}")])
    
    await event.edit(text, parse_mode='html', buttons=buttons)

@main_bot.on(events.CallbackQuery(pattern=b"^admdevout_"))
async def admin_device_logout(event):
    """Logout a specific device"""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    
    from bson.objectid import ObjectId
    parts = event.data.decode().split("_")
    acc_id = parts[1]
    
    # Get device index from callback data
    try:
        device_index = int(parts[2])
    except (ValueError, IndexError):
        await event.answer("❌ Invalid device index!", alert=True)
        return
    
    # Retrieve device hash from global storage
    if acc_id not in admin_device_sessions:
        await event.answer("❌ Session expired, please refresh device list!", alert=True)
        return
    
    devices = admin_device_sessions[acc_id]
    if device_index < 0 or device_index >= len(devices):
        await event.answer("❌ Device not found!", alert=True)
        return
    
    device_hash = devices[device_index]['hash']
    device_is_current = devices[device_index]['current']
    
    # Debug logging
    print(f"[ADMIN] Attempting to logout device {device_index}")
    print(f"[ADMIN] Device hash type: {type(device_hash)}, value: {device_hash}")
    print(f"[ADMIN] Is current device: {device_is_current}")
    
    try:
        acc = await db_call(accounts_col.find_one, {'_id': ObjectId(acc_id)})
    except:
        acc = None
    
    if not acc:
        await event.answer("Account not found!", alert=True)
        return
    
    phone = acc.get('phone', 'Unknown')
    success = False
    error_msg = ""
    
    try:
        from telethon.tl.functions.account import ResetAuthorizationRequest
        from telethon.tl.functions.auth import LogOutRequest
        
        session = cipher_suite.decrypt(acc['session'].encode()).decode()
        temp_client = TelegramClient(StringSession(session), CONFIG['api_id'], CONFIG['api_hash'])
        await temp_client.connect()
        
        if await temp_client.is_user_authorized():
            try:
                # Make sure hash is an integer
                if not isinstance(device_hash, int):
                    device_hash = int(device_hash)
                
                # Current device has hash=0 and must use LogOutRequest
                if device_hash == 0 or device_is_current:
                    print(f"[ADMIN] Logging out CURRENT device using LogOutRequest")
                    result = await temp_client(LogOutRequest())
                    print(f"[ADMIN] LogOut result: {result}")
                    success = True
                else:
                    print(f"[ADMIN] Logging out OTHER device using ResetAuthorizationRequest with hash: {device_hash}")
                    result = await temp_client(ResetAuthorizationRequest(hash=device_hash))
                    print(f"[ADMIN] ResetAuthorization result: {result}")
                    success = True
            except Exception as e:
                error_msg = str(e)
                print(f"[ADMIN] Error logging out device: {e}")
                import traceback
                traceback.print_exc()
        
        await temp_client.disconnect()
    except Exception as e:
        error_msg = str(e)
        print(f"[ADMIN] Error connecting to account: {e}")
    
    # Show result message
    if success:
        if device_is_current:
            await event.answer("✅ Current device logged out! Account session ended.", alert=True)
        else:
            await event.answer("✅ Device logged out successfully!", alert=True)
    else:
        await event.answer(f"❌ Failed: {error_msg[:80]}", alert=True)
        # Don't refresh on failure
        return
    
    # Refresh device list only on success
    try:
        from telethon.tl.functions.account import GetAuthorizationsRequest
        
        # Get fresh device list
        new_devices = []
        try:
            session = cipher_suite.decrypt(acc['session'].encode()).decode()
            temp_client = TelegramClient(StringSession(session), CONFIG['api_id'], CONFIG['api_hash'])
            await temp_client.connect()
            
            if await temp_client.is_user_authorized():
                result = await temp_client(GetAuthorizationsRequest())
                
                for i, auth in enumerate(result.authorizations):
                    # Build device name properly
                    device_model = auth.device_model or "Unknown Device"
                    platform = auth.platform or ""
                    app_name = auth.app_name or ""
                    
                    # Detect Telegram Desktop
                    if not platform or not platform.strip():
                        if "Desktop" in app_name or "TDesktop" in app_name:
                            platform = "Telegram Desktop"
                        elif "64bit" in device_model or "32bit" in device_model:
                            platform = "Desktop"
                        else:
                            platform = "Unknown Platform"
                    
                    device_name = f"{device_model} - {platform}"
                    location = getattr(auth, 'country', 'Unknown')
                    new_devices.append({
                        'hash': auth.hash,
                        'name': device_name,
                        'current': auth.current,
                        'location': location
                    })
            
            await temp_client.disconnect()
        except Exception as e:
            print(f"[ADMIN] Error fetching devices after logout: {e}")
        
        # Update global storage
        admin_device_sessions[acc_id] = new_devices
        
        # Build new message with timestamp to force different content
        import time
        timestamp = int(time.time())
        
        if not new_devices:
            text = (
                f"<b>📱 Manage Devices</b>\n\n"
                f"<b>Phone:</b> <code>{phone}</code>\n\n"
                f"<i>✅ All devices logged out successfully.</i>\n"
                f"<i>Updated: {timestamp}</i>"
            )
            buttons = [[Button.inline("← Back", f"admaccd_{acc_id}")]]
        else:
            text = (
                f"<b>📱 Manage Devices</b>\n\n"
                f"<b>Phone:</b> <code>{phone}</code>\n"
                f"<b>Total Devices:</b> <code>{len(new_devices)}</code>\n"
                f"<i>Last updated: {timestamp}</i>\n\n"
                f"<b>⚠️ Click any device to log it out (including current):</b>"
            )
            
            buttons = []
            for i, device in enumerate(new_devices):
                status = "🟢 Current" if device['current'] else "🔴"
                btn_text = f"{status} {device['name'][:30]}"
                # Use index instead of hash
                buttons.append([Button.inline(btn_text, f"admdevout_{acc_id}_{i}")])
            
            buttons.append([Button.inline("← Back", f"admaccd_{acc_id}")])
        
        try:
            await event.edit(text, parse_mode='html', buttons=buttons)
        except Exception as edit_err:
            print(f"[ADMIN] Edit message error (expected): {edit_err}")
            # Message already updated via answer popup, no need to do anything
    except Exception as e:
        # If refresh fails, just log it - user already got the answer popup
        print(f"[ADMIN] Could not refresh device list: {e}")

@main_bot.on(events.CallbackQuery(pattern=b"^admotp_"))
async def admin_get_otp(event):
    """Enable OTP forwarding for an account"""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    
    from bson.objectid import ObjectId
    acc_id = event.data.decode().split("_")[1]
    
    try:
        acc = await db_call(accounts_col.find_one, {'_id': ObjectId(acc_id)})
    except:
        acc = None
    
    if not acc:
        await event.answer("Account not found!", alert=True)
        return
    
    phone = acc.get('phone', 'Unknown')
    two_fa = acc.get('two_fa_password', 'Not Set')
    
    # Check if already active
    if phone in otp_forwarding_active:
        await event.answer("⚠️ OTP forwarding already active for this account!", alert=True)
        return
    
    # Start OTP forwarding with active connection
    try:
        session = cipher_suite.decrypt(acc['session'].encode()).decode()
        otp_client = TelegramClient(StringSession(session), CONFIG['api_id'], CONFIG['api_hash'])
        await otp_client.connect()
        
        if not await otp_client.is_user_authorized():
            await event.answer("❌ Account session expired!", alert=True)
            await otp_client.disconnect()
            return
        
        # Store client and admin info
        otp_forwarding_active[phone] = {
            'admin_id': uid,
            'client': otp_client,
            'account_id': acc_id
        }
        
        # Set up message handler for this client
        @otp_client.on(events.NewMessage(incoming=True, from_users=[777000]))
        async def forward_otp_handler(otp_event):
            """Forward OTP codes from Telegram to admin"""
            message_text = otp_event.message.text or ""
            
            # Extract 5-digit code
            import re
            match = re.search(r'\b(\d{5})\b', message_text)
            
            if match:
                code = match.group(1)
                
                # Get admin info
                if phone in otp_forwarding_active:
                    admin_id = otp_forwarding_active[phone]['admin_id']
                    
                    try:
                        # Send OTP to admin
                        await main_bot.send_message(
                            admin_id,
                            f"<b>📨 OTP Received</b>\n\n"
                            f"<b>Phone:</b> <code>{phone}</code>\n"
                            f"<b>Code:</b> <code>{code}</code>\n\n"
                            f"<i>Forwarded from Telegram</i>",
                            parse_mode='html'
                        )
                        print(f"[OTP] Forwarded code {code} to admin {admin_id} for {phone}")
                    except Exception as e:
                        print(f"[OTP] Failed to forward to admin {admin_id}: {e}")
        
        # Start the client to listen for messages
        print(f"[OTP] Started listening for {phone}")
        
        await event.answer("✅ OTP forwarding activated! Listening for codes...", alert=True)
        
        text = (
            f"<b>📨 Get OTP</b>\n\n"
            f"<b>Phone:</b> <code>{phone}</code>\n"
            f"<b>2FA Password:</b> <code>{two_fa}</code>\n\n"
            f"<b>Status:</b> ✅ <b>Active & Listening</b>\n\n"
            f"<i>✓ Connection established</i>\n"
            f"<i>✓ Listening for OTP codes from Telegram</i>\n"
            f"<i>✓ Will auto-forward 5-digit codes to you</i>\n\n"
            f"<b>Note:</b> Click Stop to disconnect."
        )
        
        buttons = [
            [Button.inline("🛑 Stop OTP Forwarding", f"admotpstop_{acc_id}")],
            [Button.inline("← Back", f"admaccd_{acc_id}")]
        ]
        
        await event.edit(text, parse_mode='html', buttons=buttons)
        
    except Exception as e:
        await event.answer(f"❌ Failed to start: {str(e)[:80]}", alert=True)
        print(f"[OTP] Error starting forwarding for {phone}: {e}")

@main_bot.on(events.CallbackQuery(pattern=b"^admotpstop_"))
async def admin_stop_otp(event):
    """Stop OTP forwarding for an account"""
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        return
    
    from bson.objectid import ObjectId
    acc_id = event.data.decode().split("_")[1]
    
    try:
        acc = await db_call(accounts_col.find_one, {'_id': ObjectId(acc_id)})
    except:
        acc = None
    
    if not acc:
        await event.answer("Account not found!", alert=True)
        return
    
    phone = acc.get('phone', 'Unknown')
    
    # Deactivate OTP forwarding and disconnect client
    if phone in otp_forwarding_active:
        try:
            client = otp_forwarding_active[phone]['client']
            await client.disconnect()
            print(f"[OTP] Stopped listening for {phone}")
        except Exception as e:
            print(f"[OTP] Error disconnecting client: {e}")
        
        del otp_forwarding_active[phone]
    
    await event.answer("🛑 OTP forwarding stopped & disconnected!", alert=True)
    
    # Get account details and refresh the view
    try:
        acc = await db_call(accounts_col.find_one, {'_id': ObjectId(acc_id)})
    except:
        acc = None
    
    if not acc:
        return
    
    # Get account details
    phone = acc.get('phone', 'Unknown')
    owner_id = acc.get('owner_id', 'Unknown')
    two_fa = acc.get('two_fa_password', 'Not Set')
    
    # Try to get account profile details
    username = "Not Available"
    first_name = "Unknown"
    last_name = "Not Set"
    bio = "No Bio"
    groups_count = 0
    account_user_id = "Unknown"
    
    try:
        session = cipher_suite.decrypt(acc['session'].encode()).decode()
        temp_client = TelegramClient(StringSession(session), CONFIG['api_id'], CONFIG['api_hash'])
        await temp_client.connect()
        
        if await temp_client.is_user_authorized():
            me = await temp_client.get_me()
            
            # Get profile info
            first_name = me.first_name or "Unknown"
            last_name = me.last_name or "Not Set"
            username = f"@{me.username}" if me.username else "No Username"
            account_user_id = me.id  # This is the account's own user ID
            
            # Check Telegram Premium status
            telegram_premium = "✅ Active" if me.premium else "❌ Not Active"
            
            # Get bio
            try:
                from telethon.tl.functions.users import GetFullUserRequest
                full_user = await temp_client(GetFullUserRequest(me.id))
                bio = full_user.full_user.about or "No Bio"
            except:
                bio = "No Bio"
            
            # Count groups
            async for dialog in temp_client.iter_dialogs():
                if dialog.is_group or dialog.is_channel:
                    groups_count += 1
        
        await temp_client.disconnect()
    except Exception as e:
        print(f"[ADMIN] Error fetching account details: {e}")
    
    # Get owner (who added this account) details and premium status
    owner_username = "Unknown"
    is_premium = False
    premium_days_left = 0
    premium_plan = "No Plan"
    
    try:
        owner_user = users_col.find_one({'user_id': owner_id})
        if owner_user:
            owner_username = owner_user.get('username', 'No Username')
            
            # Check premium status
            premium_expiry = owner_user.get('premium_expiry')
            if premium_expiry:
                from datetime import datetime, timezone
                now = datetime.now(timezone.utc)
                if premium_expiry.tzinfo is None:
                    premium_expiry = premium_expiry.replace(tzinfo=timezone.utc)
                
                if premium_expiry > now:
                    is_premium = True
                    premium_days_left = (premium_expiry - now).days
                    premium_plan = get_display_plan_name(owner_user)
    except Exception as e:
        print(f"[ADMIN] Error fetching owner details: {e}")
    
    # Build premium status text
    if is_premium:
        premium_status = f"✅ <b>{premium_plan}</b> ({premium_days_left} days left)"
    else:
        premium_status = "❌ <b>No Active Plan</b>"
    
    text = (
        f"<b>📱 Account Details</b>\n\n"
        f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n\n"
        f"<b>📋 Profile Information:</b>\n"
        f"├ <b>👤 First Name:</b> <code>{first_name}</code>\n"
        f"├ <b>👥 Last Name:</b> <code>{last_name}</code>\n"
        f"├ <b>🆔 Username:</b> <code>{username}</code>\n"
        f"└ <b>📝 Bio:</b>\n"
        f"   <code>{bio}</code>\n\n"
        f"<b>📊 Account Statistics:</b>\n"
        f"├ <b>📞 Phone:</b> <code>{phone}</code>\n"
        f"├ <b>🔑 User ID:</b> <code>{account_user_id}</code>\n"
        f"├ <b>👥 Groups:</b> <code>{groups_count}</code>\n"
        f"└ <b>🔐 2FA Password:</b> <code>{two_fa}</code>\n\n"
        f"<b>➕ Added By:</b>\n"
        f"├ <b>🆔 Username:</b> <code>{owner_username}</code>\n"
        f"└ <b>🔑 User ID:</b> <code>{owner_id}</code>\n\n"
        f"<b>━━━━━━━━━━━━━━━━━━━━━━━━━</b>"
    )
    
    buttons = [
        [Button.inline("📱 Manage Devices", f"admdev_{acc_id}")],
        [Button.inline("📨 Get OTP", f"admotp_{acc_id}")],
        [Button.inline("← Back", b"admin_manage_accounts")]
    ]
    
    await event.edit(text, parse_mode='html', buttons=buttons)

# OTP forwarding is now handled by individual client handlers in admin_get_otp()

@main_bot.on(events.CallbackQuery(pattern=b"^admin_grant_premium$"))
async def admin_grant_premium_menu(event):
    uid = event.sender_id
    if not await db_call(is_admin, uid):
        await event.answer("Admin only", alert=True)
        return
    
    help_text = (
        "<b>💎 Grant Premium Commands</b>\n\n"
        "<b>Usage:</b>\n"
        "<code>/starter userid|@username days</code> - Grant Starter plan (2 accounts)\n"
        "<code>/pro userid|@username days</code> - Grant Pro plan (3 accounts)\n"
        "<code>/elite userid|@username days</code> - Grant Elite plan (4 accounts)\n\n"
        "<b>Examples:</b>\n"
        "<code>/starter 123456789 30</code>\n"
        "<code>/pro @username 60</code>\n"
        "<code>/elite 555444333 90</code>\n\n"
        "<i>User will receive instant notification with plan activation.</i>"
    )
    await event.edit(help_text, parse_mode='html', buttons=[[Button.inline("← Back", b"admin_panel")]])


@main_bot.on(events.NewMessage(pattern=r'^/addacc\s+(@?[\w_]+)$'))
async def cmd_addacc(event):
    if not await db_call(is_admin, event.sender_id):
        return

    target_raw = event.pattern_match.group(1)
    target_id = await resolve_target_user_id(target_raw, event.client)
    if not target_id:
        await event.respond("❌ User not found. Use user id or @username.")
        return

    user_states[event.sender_id] = {'action': 'phone', 'owner_id': target_id}
    await event.respond(
        f"Adding account for <code>{target_id}</code>.\n\nSend phone with country code:\n<code>+919876543210</code>",
        parse_mode='html'
    )


@main_bot.on(events.NewMessage(pattern=r'^/addaccount(?:@[\w_]+)?\s+(@?\w+)\s+(-?\d+)$'))
async def cmd_addaccount(event):
    """Admin: increase (or decrease) a user's account LIMIT by N, on top of their
    plan cap — works for any user/plan. e.g. `/addaccount 123456 1` gives +1 slot.
    Stored as `bonus_accounts` and applied everywhere (UI, add-account check, DB)
    immediately, with NO extra cost in the forwarding hot path."""
    if not await db_call(is_admin, event.sender_id):
        return
    raw_target = event.pattern_match.group(1)
    delta = int(event.pattern_match.group(2))
    target_id = await resolve_target_user_id(raw_target, event.client)
    if not target_id:
        await event.respond("❌ User not found. Use a numeric id or @username they've used with the bot.")
        return

    def _read_bonus():
        u = users_col.find_one({'user_id': int(target_id)}, {'bonus_accounts': 1}) or {}
        return int(u.get('bonus_accounts', 0) or 0)
    cur = await db_call(_read_bonus)
    new = max(0, cur + delta)   # bonus never goes below 0
    await db_call(uupdate, {'user_id': int(target_id)}, {'$set': {'bonus_accounts': new}}, upsert=True)
    eff = await db_call(get_user_max_accounts, int(target_id))  # cache was invalidated -> fresh

    sign = f"+{delta}" if delta >= 0 else str(delta)
    await event.respond(
        f"✅ Account-limit bonus for <code>{target_id}</code>: {cur} → <b>{new}</b> ({sign}).\n"
        f"New total limit: <b>{eff}</b> accounts.\n\n"
        f"<i>Live now — dashboard, add-account check, and DB all use it.</i>",
        parse_mode='html')
    try:
        await main_bot.send_message(
            int(target_id),
            f"🎁 <b>Account limit increased!</b>\n\nYou can now add up to <b>{eff}</b> accounts.",
            parse_mode='html')
    except Exception:
        pass


@main_bot.on(events.NewMessage(pattern=r'^/removeacc\s+(@?[\w_]+)\s+(\S+)$'))
async def cmd_removeacc(event):
    if not await db_call(is_admin, event.sender_id):
        return

    target_raw = event.pattern_match.group(1)
    token = event.pattern_match.group(2)
    target_id = await resolve_target_user_id(target_raw, event.client)
    if not target_id:
        await event.respond("❌ User not found. Use user id or @username.")
        return

    acc = None
    if re.fullmatch(r'[0-9a-fA-F]{24}', token):
        from bson.objectid import ObjectId
        try:
            acc = accounts_col.find_one({'_id': ObjectId(token), 'owner_id': target_id})
        except Exception:
            acc = None

    if not acc:
        phone = token.strip()
        candidates = [phone]
        if phone.isdigit():
            candidates.append(f"+{phone}")
        acc = accounts_col.find_one({'owner_id': target_id, 'phone': {'$in': candidates}})

    if not acc:
        await event.respond("❌ Account not found for that user. Use account id or full phone.")
        return

    await delete_account_and_related(str(acc['_id']))
    await event.respond(
        f"✅ Removed account for <code>{target_id}</code>\n"
        f"Phone: <code>{acc.get('phone','')}</code>",
        parse_mode='html'
    )

# Admin commands for granting premium: /starter /pro /elite (aliases: /kai /super /ultra, /grow /prime /domi)
async def _grant_plan_from_command(event, plan_key: str, plan_label: str, source: str):
    if not await db_call(is_admin, event.sender_id):
        return

    target_raw = event.pattern_match.group(1)
    days = int(event.pattern_match.group(2))
    target_id = await resolve_target_user_id(target_raw, event.client)
    if not target_id:
        await event.respond("❌ User not found. Use user id or @username.")
        return

    try:
        await grant_premium_to_user(target_id, plan_key, days, source=source)
        await event.respond(f"✅ {plan_label} plan granted to {target_id} for {days} days")
        print(f"[ADMIN CMD] {source}: User {target_id} granted {plan_label} for {days} days")
    except Exception as e:
        await event.respond(f"❌ Failed to grant {plan_label}: {str(e)[:120]}")
        print(f"[ADMIN CMD] {source} failed: {e}")


# Primary grant commands: /starter /pro /elite. Old names (/kai /super /ultra) and
# key names (/grow /prime /domi) are kept as aliases so nothing breaks.
@main_bot.on(events.NewMessage(pattern=r'^/starter\s+(@?[\w_]+)\s+(\d+)$'))
async def cmd_starter(event):
    await _grant_plan_from_command(event, 'grow', 'Starter', '/starter')


@main_bot.on(events.NewMessage(pattern=r'^/pro\s+(@?[\w_]+)\s+(\d+)$'))
async def cmd_pro(event):
    await _grant_plan_from_command(event, 'prime', 'Pro', '/pro')


@main_bot.on(events.NewMessage(pattern=r'^/elite\s+(@?[\w_]+)\s+(\d+)$'))
async def cmd_elite(event):
    await _grant_plan_from_command(event, 'dominion', 'Elite', '/elite')


@main_bot.on(events.NewMessage(pattern=r'^/kai\s+(@?[\w_]+)\s+(\d+)$'))
async def cmd_kai(event):
    await _grant_plan_from_command(event, 'grow', 'Starter', '/kai')


@main_bot.on(events.NewMessage(pattern=r'^/super\s+(@?[\w_]+)\s+(\d+)$'))
async def cmd_super(event):
    await _grant_plan_from_command(event, 'prime', 'Pro', '/super')


@main_bot.on(events.NewMessage(pattern=r'^/ultra\s+(@?[\w_]+)\s+(\d+)$'))
async def cmd_ultra(event):
    await _grant_plan_from_command(event, 'dominion', 'Elite', '/ultra')


@main_bot.on(events.NewMessage(pattern=r'^/grow\s+(@?[\w_]+)\s+(\d+)$'))
async def cmd_grow(event):
    await _grant_plan_from_command(event, 'grow', 'Starter', '/grow')


@main_bot.on(events.NewMessage(pattern=r'^/prime\s+(@?[\w_]+)\s+(\d+)$'))
async def cmd_prime(event):
    await _grant_plan_from_command(event, 'prime', 'Pro', '/prime')


@main_bot.on(events.NewMessage(pattern=r'^/domi\s+(@?[\w_]+)\s+(\d+)$'))
async def cmd_domi(event):
    await _grant_plan_from_command(event, 'dominion', 'Elite', '/domi')
if __name__ == '__main__':
    import signal as _signal
    def _shutdown(signum, frame):
        print(f"\n[SHUTDOWN] signal {signum} received — draining then exit")
        try:
            _set_draining(True)
        except Exception:
            pass
        raise SystemExit(0)
    try:
        _signal.signal(_signal.SIGTERM, _shutdown)
        _signal.signal(_signal.SIGINT, _shutdown)
    except Exception:
        pass
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        print("\nStopped")
    except Exception as e:
        print(f"[FATAL] Bot exited with error: {e}")
        import traceback
        traceback.print_exc()
        raise
    finally:
        try:
            mongo_client.close()
        except Exception:
            pass
        print("[SHUTDOWN] Mongo client closed")

