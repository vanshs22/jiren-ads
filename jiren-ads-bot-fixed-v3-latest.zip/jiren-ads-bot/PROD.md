# Production readiness (code-side)

This build targets **10/10 on software quality** within what the app can control.
**Hardware (RAM/CPU) and proxies** remain operator responsibilities.

## Required .env
- `BOT_TOKEN`, `TELEGRAM_API_ID`, `TELEGRAM_API_HASH`, `OWNER_ID`
- `MONGO_URI`, `MONGO_DB_NAME`
- `ENCRYPTION_KEY` (stable Fernet key — never rotate casually)
- Optional: `REDIS_URL`, `PROXY_LIST`, `LIVE_SEND_LOGS=0`

## Recommended
- `HEALTH_INTERVAL=1800`
- `PER_ACCOUNT_MB=10`
- `RAM_SAFETY=1.2`
- `REFRESH_BATCH_MAX=5`
- `REFRESH_COOLDOWN_SEC=900`
- Live send logs **OFF** in production

## What the code guarantees
- UI / worker process split via `manager.py`
- Session encrypt at rest, auth-dead accounts stop (no restart spin)
- Caches + projected account lists for faster UI
- Plan-gated Auto Reply (Starter none / Pro 2 keywords / Elite + Group AR)
- VPS-safe group refresh (batch + cooldown)
- Mongo indexes for reconciler and user lists
- FloodWait / PeerFlood handling on send path

## What you must provide
- Enough RAM for concurrent connected accounts
- Clean proxies before scaling accounts per IP
- systemd restart + monitoring

## After deploy
```bash
grep -n "def can_use_private_autoreply\|def _load_account_session\|auth_invalid" bot.py | head
sudo systemctl restart jiren-ads
journalctl -u jiren-ads -n 40 --no-pager
```

## A–H ops notes
- Session-dead accounts show ⚠️ and a fix panel (delete + re-add).
- Worker heartbeat every ~30s; stale ~180s → reconciler restarts local task.
- SIGTERM sets drain so loops exit cleanly.
- Impersonation writes to `audit_col` (disable with AUDIT_IMPERSONATION=0).
- Smoke: `python tests/test_button_wiring.py`
