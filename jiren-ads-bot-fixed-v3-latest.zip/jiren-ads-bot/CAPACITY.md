# Jiren Ads Bot — Capacity Planning

## Quick numbers (from `load_test.py` + manager defaults)

| Users | Accounts/user | Active (70% forwarding) | Workers @100/worker | RAM (≈10 MB/acc) | Clean IPs @40/IP |
|------:|--------------:|------------------------:|--------------------:|-----------------:|-----------------:|
| 200   | 3             | ~420                    | 5                   | ~7 GB            | ~11              |
| 300   | 3             | ~630                    | 7                   | ~10 GB           | ~16              |
| 500   | 3             | ~1050                   | 11                  | ~16 GB           | ~27              |
| 500   | 4 (all Elite) | ~1400                   | 14                  | ~22 GB           | ~35              |

Defaults: `MAX_ACCOUNTS_PER_WORKER=100`, `PER_IP_CAP=40`, `PER_ACCOUNT_MB=10`, `RAM_RESERVE_MB=1024`.

## How to run the load simulation

```bash
# In-memory (no Mongo needed)
python load_test.py --users 300 --accounts-per-user 3

# Against your real Mongo
MONGO_URI='mongodb://...' MONGO_DB_NAME=gokuads_db python load_test.py --users 500 --real-mongo

# Cleanup synthetic docs
python load_test.py --cleanup --real-mongo
```

What it measures:
- Index-backed user/account/reconciler reads
- Health-doc write throughput
- Click-tracker find+set race behaviour
- Node/worker shard balance
- Manager desired-worker math + RAM/IP estimates

What it does **not** measure (needs a real pilot):
- Telegram FloodWait / PeerFlood rates
- Proxy quality and ban rates
- End-to-end send latency under MTProto

## Recommended pilot path

1. **20–50 accounts**, 1–2 workers, watch `/health` + floods for 48 h.
2. Scale to **100–150 active** accounts, enable proxies, set `DISABLE_TEXT_STYLE=1`.
3. Only then push toward 300–500 users.

## Multi-node

```bash
# Node 0 (UI + workers)
NODE_ID=0 NODE_COUNT=2 RUN_UI=1 python manager.py

# Node 1 (workers only)
NODE_ID=1 NODE_COUNT=2 RUN_UI=0 python manager.py
```

Accounts are sharded by `md5(account_id) % NODE_COUNT`. No cross-node coordination required.

## Env knobs that matter at scale

| Var | Default | Notes |
|-----|---------|-------|
| `MAX_ACCOUNTS_PER_WORKER` | 100 | Lower on small boxes (`AUTO_WORKER_CAP=1` does this) |
| `MAX_WORKERS` | 16 | Raise with more CPU |
| `PER_IP_CAP` | 40 | Conservative; tune per proxy provider |
| `DISABLE_TEXT_STYLE` | 0 | Set `1` to save CPU on high send volume |
| `LIVE_SEND_LOGS` | 0 | Keep off at scale |
| `MONGO_MAX_POOL` | 100 | Per process; total ≈ (workers+2) × pool |
| `DB_THREAD_POOL` | 128 | Thread pool for sync pymongo calls |
| `ENCRYPTION_KEY` | — | **Required**, stable across restarts |

## Telegram risk (not solvable by code)

Mass multi-account advertising triggers FloodWait, PeerFlood, and permanent bans.
Proxies reduce correlation; they do not make the activity ToS-compliant or ban-proof.
Always assume accounts are disposable and budget for replacement.
