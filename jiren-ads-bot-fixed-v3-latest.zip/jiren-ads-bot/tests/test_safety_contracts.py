"""
Lightweight contract tests — no Telegram, no Mongo required.
Run:  python -m pytest tests/ -q
Or:   python tests/test_safety_contracts.py
"""
from __future__ import annotations

import asyncio
import unittest


# ---- Pure mirrors of bot safety contracts (must stay aligned with bot.py) ----

def cycle_interval_sec(user, default=600):
    """Mirror get_cycle_interval_sec: cycle_interval_sec > custom round > 600."""
    try:
        v = (user or {}).get("cycle_interval_sec")
        if v is not None and int(v) >= 60:
            return int(v)
    except Exception:
        pass
    try:
        if (user or {}).get("custom_interval"):
            rd = int((user.get("custom_interval") or {}).get("round_delay") or 0)
            if rd >= 60:
                return rd
    except Exception:
        pass
    return default


def msg_delay_sec(user, presets, min_delay=5):
    if user.get("msg_delay_sec"):
        d = int(user["msg_delay_sec"])
    elif user.get("interval_preset") == "custom" and user.get("custom_interval"):
        d = int((user.get("custom_interval") or {}).get("msg_delay") or 30)
    else:
        preset = user.get("interval_preset", "medium")
        d = int((presets.get(preset) or presets.get("medium") or {}).get("msg_delay") or 30)
    return max(min_delay, d)


def freq_stretches_only(cycle_gap, extra_for_freq):
    """Freq may only increase wait, never shorten below cycle_gap."""
    return max(cycle_gap, cycle_gap + max(0, extra_for_freq))


def acting_uid(real_uid, impersonate_map):
    return int(impersonate_map.get(int(real_uid), real_uid))


PRESETS = {
    "slow": {"msg_delay": 60, "round_delay": 900},
    "medium": {"msg_delay": 30, "round_delay": 600},
    "fast": {"msg_delay": 10, "round_delay": 300},
}


class TestIntervals(unittest.TestCase):
    def test_cycle_from_buttons_not_preset(self):
        u = {"interval_preset": "fast", "cycle_interval_sec": 1200}
        self.assertEqual(cycle_interval_sec(u), 1200)

    def test_cycle_default_10_min(self):
        self.assertEqual(cycle_interval_sec({"interval_preset": "fast"}), 600)

    def test_msg_preset_only(self):
        u = {"interval_preset": "fast", "cycle_interval_sec": 1200}
        self.assertEqual(msg_delay_sec(u, PRESETS), 10)

    def test_msg_custom_sec(self):
        u = {"msg_delay_sec": 15, "interval_preset": "custom"}
        self.assertEqual(msg_delay_sec(u, PRESETS), 15)

    def test_min_msg_floor(self):
        u = {"msg_delay_sec": 1}
        self.assertEqual(msg_delay_sec(u, PRESETS, min_delay=5), 5)

    def test_freq_never_shortens(self):
        self.assertEqual(freq_stretches_only(900, 0), 900)
        self.assertEqual(freq_stretches_only(900, 100), 1000)
        self.assertEqual(freq_stretches_only(900, -50), 900)


class TestImpersonate(unittest.TestCase):
    def test_acting_uid(self):
        m = {1: 99}
        self.assertEqual(acting_uid(1, m), 99)
        self.assertEqual(acting_uid(2, m), 2)


class TestSupervisorFinallyRace(unittest.TestCase):
    def test_only_drop_self(self):
        """Cancelled task must not delete a newer task under the same key."""
        registry = {}

        async def old_task(key):
            try:
                await asyncio.sleep(10)
            except asyncio.CancelledError:
                pass
            finally:
                cur = asyncio.current_task()
                if registry.get(key) is cur:
                    registry.pop(key, None)

        async def run():
            t1 = asyncio.create_task(old_task("acc"))
            registry["acc"] = t1
            await asyncio.sleep(0.01)
            t1.cancel()
            t2 = asyncio.create_task(old_task("acc"))
            registry["acc"] = t2
            await asyncio.sleep(0.05)
            # t1 finally should NOT have removed t2
            self.assertIs(registry.get("acc"), t2)
            t2.cancel()
            try:
                await t2
            except asyncio.CancelledError:
                pass

        asyncio.run(run())


class TestQuietHoursDefault(unittest.TestCase):
    def test_default_window_ist(self):
        DEFAULT = {
            "enabled": True,
            "start": "01:00",
            "end": "07:00",
        }
        self.assertTrue(DEFAULT["enabled"])
        self.assertEqual(DEFAULT["start"], "01:00")
        self.assertEqual(DEFAULT["end"], "07:00")


class TestWarmupDefault(unittest.TestCase):
    def test_warmup_env_default_on(self):
        # Contract: env default string is '1'
        default = "1"
        enabled = default.strip().lower() in ("1", "true", "yes", "on")
        self.assertTrue(enabled)



class TestPremiumExpiryContract(unittest.TestCase):
    def test_expired_means_not_premium(self):
        from datetime import datetime, timedelta
        expires = datetime.now() - timedelta(days=1)
        # contract: expired timestamp => treated as free after check
        self.assertTrue(expires < datetime.now())

    def test_future_means_premium_candidate(self):
        from datetime import datetime, timedelta
        expires = datetime.now() + timedelta(days=7)
        self.assertTrue(expires > datetime.now())


if __name__ == "__main__":
    unittest.main()
