"""
Static smoke: every Button.inline callback_data should have a handler branch.
Run: python -m pytest tests/test_button_wiring.py -q
     or: python tests/test_button_wiring.py
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOT = ROOT / "bot.py"


def _collect_callbacks(src: str) -> set:
    cbs = set()
    # b"foo" or b'foo'
    for m in re.finditer(r'Button\.inline\([^)]*?,\s*b["\']([^"\']+)["\']', src, re.S):
        cbs.add(m.group(1))
    # f"admin_...{id}" → prefix admin_
    for m in re.finditer(r'Button\.inline\([^)]*?,\s*f["\']([^"\'{]+)', src, re.S):
        cbs.add(m.group(1))
    return cbs


def _handler_prefixes(src: str) -> set:
    exact = set(re.findall(r'if data\s*==\s*["\']([^"\']+)["\']', src))
    starts = set(re.findall(r'data\.startswith\(["\']([^"\']+)["\']\)', src))
    ins = set()
    for m in re.finditer(r'if data in \{([^}]+)\}', src):
        ins |= set(re.findall(r'["\']([^"\']+)["\']', m.group(1)))
    return exact | starts | ins


def test_static_callbacks_have_handlers():
    src = BOT.read_text(encoding="utf-8", errors="replace")
    cbs = _collect_callbacks(src)
    handlers = _handler_prefixes(src)
    orphans = []
    for c in sorted(cbs):
        if "{" in c:
            continue
        if c in handlers:
            continue
        if any(c.startswith(h) for h in handlers if h.endswith("_") or len(h) > 3):
            continue
        # dynamic prefixes
        if any(c.startswith(p) for p in (
            "acc_", "admin_", "accpage_", "otp_", "pay", "confirm_", "add_",
            "page_", "del_", "topic_", "set_", "grp_", "kw_", "plan_", "view_",
            "imp_", "gpreply", "relogin_", "fix_dead_", "delete_", "final_del_",
            "admaccd_", "admaccpg_", "admdev_", "admdevout_", "admotp_", "admotpstop_",
            "stats_", "fwd_", "refresh_",
        )):
            continue
        orphans.append(c)
    # known locked / informational
    allowed = {
        "locked_auto_group_join", "locked_autoreply", "locked_smart_rotation",
        "locked_topics", "locked_fwd_mode",
    }
    orphans = [o for o in orphans if o not in allowed]
    assert not orphans, f"Callbacks without handlers: {orphans[:30]}"


if __name__ == "__main__":
    try:
        test_static_callbacks_have_handlers()
        print("OK: button wiring smoke passed")
    except AssertionError as e:
        print("FAIL:", e)
        sys.exit(1)
