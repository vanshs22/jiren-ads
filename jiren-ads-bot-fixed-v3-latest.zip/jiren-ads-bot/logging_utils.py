"""
Lightweight structured logging for Jiren Ads Bot.

Usage:
  from logging_utils import get_logger, log_event
  log = get_logger('forward')
  log.info('send_ok', account_id=str(acc_id), group=group_id, ms=12.4)
  log_event('flood', account_id=..., wait=30)

Set LOG_JSON=1 for machine-readable one-line JSON (good for shipping to
Loki/ELK). Default is human-readable key=value.
"""
from __future__ import annotations

import json
import logging
import os
import sys
import time
from typing import Any

_JSON = os.getenv('LOG_JSON', '0').strip().lower() in ('1', 'true', 'yes', 'on')
_LEVEL = getattr(logging, os.getenv('LOG_LEVEL', 'INFO').upper(), logging.INFO)


class _KVFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        base = {
            'ts': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(record.created)),
            'level': record.levelname,
            'logger': record.name,
            'msg': record.getMessage(),
        }
        extra = getattr(record, 'kv', None) or {}
        if _JSON:
            base.update(extra)
            return json.dumps(base, default=str, ensure_ascii=False)
        parts = [f"{base['ts']} {base['level']:<5} [{base['logger']}] {base['msg']}"]
        for k, v in extra.items():
            parts.append(f"{k}={v}")
        return ' '.join(parts)


_configured = False


def _configure():
    global _configured
    if _configured:
        return
    root = logging.getLogger('jiren')
    root.setLevel(_LEVEL)
    if not root.handlers:
        h = logging.StreamHandler(sys.stdout)
        h.setFormatter(_KVFormatter())
        root.addHandler(h)
    _configured = True


def get_logger(name: str = 'app') -> logging.LoggerAdapter:
    _configure()
    base = logging.getLogger(f'jiren.{name}')

    class _Adapter(logging.LoggerAdapter):
        def process(self, msg, kwargs):
            kv = kwargs.pop('extra', {}) if False else {}
            # allow log.info('msg', account_id=1) style
            extra_kv = {k: kwargs.pop(k) for k in list(kwargs.keys())
                        if k not in ('exc_info', 'stack_info', 'stacklevel', 'extra')}
            kwargs['extra'] = {'kv': extra_kv}
            return msg, kwargs

    return _Adapter(base, {})


def log_event(event: str, **fields: Any):
    """One-shot structured event on the root jiren logger."""
    get_logger('event').info(event, **fields)
