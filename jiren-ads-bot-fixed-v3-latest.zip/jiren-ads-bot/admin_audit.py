"""
Lightweight admin / impersonation audit log.
Writes to Mongo when available; never raises into the hot path.
"""
from __future__ import annotations

import os
from datetime import datetime
from typing import Any, Optional


def write_impersonation_audit(
    col,
    *,
    admin_id: int,
    target_id: int,
    action: str,
    detail: str = "",
) -> None:
    """Best-effort insert. col = pymongo collection or None."""
    if col is None:
        return
    if os.getenv("AUDIT_IMPERSONATION", "1").strip() in ("0", "false", "no"):
        return
    try:
        col.insert_one(
            {
                "type": "impersonation",
                "admin_id": int(admin_id),
                "target_id": int(target_id),
                "action": str(action)[:80],
                "detail": str(detail)[:300],
                "at": datetime.utcnow(),
            }
        )
    except Exception as e:
        print(f"[AUDIT] write failed: {e}")
