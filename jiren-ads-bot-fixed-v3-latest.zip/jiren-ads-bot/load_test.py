#!/usr/bin/env python3
"""
Load / capacity simulation for Jiren Ads Bot (200–500 users).

This does NOT talk to Telegram (that would require real accounts, proxies, and
would violate Telegram ToS / risk bans). It stress-tests the parts that matter
for scale:

  1. Mongo write/read path for users + accounts + discovered_groups + click_links
  2. Index creation & query plans (COLLSCAN vs IXSCAN)
  3. Account ownership hashing (node + worker sharding fairness)
  4. Manager desired-worker math under 200 / 350 / 500 users
  5. Health-doc write throughput
  6. Click-tracker style increment races (find + set vs ideal $inc)

Usage:
  # In-memory (no Mongo required):
  python load_test.py --users 500 --accounts-per-user 3

  # Against a real Mongo (docker-compose mongo or Atlas):
  MONGO_URI=mongodb://... python load_test.py --users 300 --real-mongo

Exit code 0 = all checks passed.
"""
from __future__ import annotations

import argparse
import hashlib
import math
import os
import random
import string
import sys
import time
from collections import Counter
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

# ---------------------------------------------------------------------------
# Optional real Mongo vs mongomock
# ---------------------------------------------------------------------------
def _get_db(use_real: bool):
    uri = os.getenv('MONGO_URI', '').strip()
    db_name = os.getenv('MONGO_DB_NAME', 'gokuads_loadtest')
    if use_real and uri:
        from pymongo import MongoClient
        import certifi
        kwargs = dict(serverSelectionTimeoutMS=8000, maxPoolSize=50)
        if uri.startswith('mongodb+srv://') or 'tls=true' in uri.lower():
            kwargs['tlsCAFile'] = certifi.where()
        client = MongoClient(uri, **kwargs)
        client.admin.command('ping')
        print(f"[DB] Connected to real Mongo ({db_name})")
        return client[db_name], client
    try:
        import mongomock
        client = mongomock.MongoClient()
        print(f"[DB] Using mongomock in-memory ({db_name})")
        return client[db_name], client
    except ImportError:
        print("[DB] mongomock not installed and no MONGO_URI — cannot run.")
        sys.exit(2)


def _stable_hash(value) -> int:
    return int(hashlib.md5(str(value).encode()).hexdigest(), 16)


def _rand_phone():
    return '+91' + ''.join(random.choices(string.digits, k=10))


def _rand_code(n=8):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=n))


# ---------------------------------------------------------------------------
# Index setup (mirrors bot.ensure_indexes)
# ---------------------------------------------------------------------------
def ensure_indexes(db):
    users = db['users']
    accounts = db['accounts']
    click_links = db['click_links']
    discovered = db['discovered_groups']
    toxic = db['toxic_groups']
    health = db['worker_health']

    users.create_index('user_id', unique=True)
    users.create_index('username')
    users.create_index('created_at')
    accounts.create_index('owner_id')
    accounts.create_index([('owner_id', 1), ('added_at', 1)])
    accounts.create_index([('owner_id', 1), ('is_forwarding', 1)])
    accounts.create_index([('is_forwarding', 1), ('owner_id', 1)])
    click_links.create_index('code', unique=True)
    click_links.create_index('user_id')
    discovered.create_index('username')
    discovered.create_index('niche')
    discovered.create_index([('niche', 1), ('username', 1)])
    toxic.create_index([('account_id', 1), ('group_key', 1)], unique=True)
    health.create_index('updated_at')
    print("[DB] Indexes ensured")


# ---------------------------------------------------------------------------
# Seed data
# ---------------------------------------------------------------------------
def seed(db, n_users: int, accounts_per_user: int, forwarding_ratio: float):
    users = db['users']
    accounts = db['accounts']
    click_links = db['click_links']
    discovered = db['discovered_groups']

    # Wipe previous load-test data (safe: only docs tagged by us)
    users.delete_many({'load_test': True})
    accounts.delete_many({'load_test': True})
    click_links.delete_many({'load_test': True})
    discovered.delete_many({'load_test': True})

    now = datetime.now(timezone.utc)
    user_docs = []
    acc_docs = []
    click_docs = []
    disc_docs = []

    plans = ['grow', 'prime', 'dominion']
    niches = ['crypto', 'forex', 'instagram', 'tiktok', 'youtube', 'exchange']

    for i in range(n_users):
        uid = 10_000_000 + i
        plan = plans[i % len(plans)]
        user_docs.append({
            'user_id': uid,
            'username': f'user{i}',
            'plan': plan,
            'premium_expiry': now + timedelta(days=30),
            'created_at': now,
            'load_test': True,
            'quiet_hours': {'enabled': True, 'start': '01:00', 'end': '07:00'},
        })
        n_acc = accounts_per_user
        for a in range(n_acc):
            forwarding = random.random() < forwarding_ratio
            acc_docs.append({
                'owner_id': uid,
                'phone': _rand_phone(),
                'session': 'fake_encrypted_session_' + _rand_code(16),
                'is_forwarding': forwarding,
                'added_at': now,
                'load_test': True,
            })
        # One tracked link per user
        click_docs.append({
            'code': _rand_code(10),
            'user_id': uid,
            'target_url': 'https://t.me/example',
            'clicks': 0,
            'load_test': True,
        })

    for niche in niches:
        for j in range(50):
            disc_docs.append({
                'username': f'grp_{niche}_{j}_{_rand_code(4)}',
                'niche': niche,
                'user_id': 0,
                'source': 'web',
                'discovered_at': now.isoformat(),
                'load_test': True,
            })

    t0 = time.perf_counter()
    if user_docs:
        users.insert_many(user_docs, ordered=False)
    if acc_docs:
        accounts.insert_many(acc_docs, ordered=False)
    if click_docs:
        click_links.insert_many(click_docs, ordered=False)
    if disc_docs:
        discovered.insert_many(disc_docs, ordered=False)
    dt = time.perf_counter() - t0
    active = accounts.count_documents({'is_forwarding': True, 'load_test': True})
    print(f"[SEED] {n_users} users, {len(acc_docs)} accounts ({active} forwarding), "
          f"{len(click_docs)} links, {len(disc_docs)} groups in {dt:.2f}s")
    return active, len(acc_docs)


# ---------------------------------------------------------------------------
# Manager scaling math (mirrors manager.py)
# ---------------------------------------------------------------------------
def desired_workers(active: int, cap: int, min_w: int, max_w: int) -> int:
    raw = math.ceil(active / max(1, cap)) if active > 0 else min_w
    return max(min_w, min(max_w, raw))


def shard_fairness(account_ids, node_count: int, worker_count: int):
    """Return (node_counts, worker_counts) distributions."""
    nodes = Counter()
    workers = Counter()
    for aid in account_ids:
        node = _stable_hash(aid) % node_count
        worker = _stable_hash('w:' + str(aid)) % worker_count
        nodes[node] += 1
        workers[(node, worker)] += 1
    return nodes, workers


# ---------------------------------------------------------------------------
# Workloads
# ---------------------------------------------------------------------------
def bench_reads(db, n_users: int, rounds: int = 3):
    users = db['users']
    accounts = db['accounts']
    times = []
    for _ in range(rounds):
        t0 = time.perf_counter()
        # Simulate dashboard: load user + their accounts
        sample = list(users.find({'load_test': True}).limit(min(100, n_users)))
        for u in sample:
            list(accounts.find({'owner_id': u['user_id'], 'load_test': True}))
        # Simulate reconciler: all forwarding accounts
        list(accounts.find({'is_forwarding': True, 'load_test': True}, {'_id': 1, 'owner_id': 1}))
        times.append(time.perf_counter() - t0)
    avg = sum(times) / len(times)
    print(f"[READ] dashboard+reconciler avg {avg*1000:.1f} ms over {rounds} rounds "
          f"(sample {len(sample)} users)")
    return avg


def bench_click_inc(db, n_clicks: int, parallel: int = 20):
    """Simulate the n8n find→set path under concurrent clicks (race-prone)."""
    links = list(db['click_links'].find({'load_test': True}).limit(50))
    if not links:
        print("[CLICK] no links to test")
        return
    codes = [d['code'] for d in links]

    def one_click(code):
        col = db['click_links']
        doc = col.find_one({'code': code})
        if not doc:
            return
        col.update_one({'code': code}, {'$set': {'clicks': int(doc.get('clicks', 0)) + 1,
                                                  'last_click': datetime.now(timezone.utc)}})

    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=parallel) as ex:
        futs = [ex.submit(one_click, random.choice(codes)) for _ in range(n_clicks)]
        for f in as_completed(futs):
            f.result()
    dt = time.perf_counter() - t0
    total = sum(d.get('clicks', 0) for d in db['click_links'].find({'load_test': True}))
    print(f"[CLICK] {n_clicks} concurrent find+set increments in {dt:.2f}s "
          f"({n_clicks/max(dt,0.001):.0f}/s) — stored total clicks={total} "
          f"(may be < {n_clicks} due to races; use $inc in production)")


def bench_health_writes(db, workers: int, rounds: int = 30):
    col = db['worker_health']
    t0 = time.perf_counter()
    for r in range(rounds):
        for w in range(workers):
            col.update_one(
                {'_id': f'loadtest:w{w}'},
                {'$set': {
                    'sends': random.randint(10, 200),
                    'fails': random.randint(0, 20),
                    'floods': random.randint(0, 5),
                    'peerfloods': random.randint(0, 3),
                    'timeouts': random.randint(0, 5),
                    'updated_at': datetime.now(timezone.utc),
                    'load_test': True,
                }},
                upsert=True,
            )
    dt = time.perf_counter() - t0
    print(f"[HEALTH] {workers * rounds} health upserts in {dt:.2f}s "
          f"({workers*rounds/max(dt,0.001):.0f}/s)")


def capacity_report(active: int, total_acc: int, n_users: int):
    print("\n" + "=" * 60)
    print("CAPACITY REPORT (manager math)")
    print("=" * 60)
    caps = [20, 50, 80, 100]
    for cap in caps:
        for max_w in [8, 16, 32]:
            dw = desired_workers(active, cap, 1, max_w)
            print(f"  active={active:4d}  cap/worker={cap:3d}  MAX_WORKERS={max_w:2d}  "
                  f"→ desired workers = {dw}")
    # RAM estimate
    per_mb = float(os.getenv('PER_ACCOUNT_MB', '15'))
    reserve = float(os.getenv('RAM_RESERVE_MB', '1024'))
    need_mb = active * per_mb + reserve
    print(f"\n  Estimated RAM for {active} active accounts: "
          f"~{need_mb/1024:.1f} GB (incl. {reserve/1024:.1f} GB reserve)")
    # Proxies
    per_ip = int(os.getenv('PER_IP_CAP', '40'))
    need_ips = math.ceil(active / per_ip) if active else 0
    print(f"  Estimated clean IPs needed (@ {per_ip}/IP): ~{need_ips}")
    print(f"  Users={n_users}  total accounts={total_acc}  forwarding={active}")
    print("=" * 60)


def fairness_report(db, node_count: int, worker_count: int):
    ids = [d['_id'] for d in db['accounts'].find({'is_forwarding': True, 'load_test': True}, {'_id': 1})]
    if not ids:
        print("[SHARD] no forwarding accounts")
        return
    nodes, workers = shard_fairness(ids, node_count, worker_count)
    print(f"\n[SHARD] {len(ids)} active accounts → NODE_COUNT={node_count} WORKER_COUNT={worker_count}")
    print(f"  Per-node: {dict(sorted(nodes.items()))}")
    node_vals = list(nodes.values()) or [0]
    print(f"  Node balance: min={min(node_vals)} max={max(node_vals)} "
          f"spread={max(node_vals)-min(node_vals)}")
    w_vals = list(workers.values()) or [0]
    print(f"  Per-(node,worker) min={min(w_vals)} max={max(w_vals)}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description='Jiren Ads load / capacity simulation')
    ap.add_argument('--users', type=int, default=300, help='Number of synthetic users (200–500)')
    ap.add_argument('--accounts-per-user', type=int, default=3)
    ap.add_argument('--forwarding-ratio', type=float, default=0.7,
                    help='Fraction of accounts that are is_forwarding=True')
    ap.add_argument('--real-mongo', action='store_true', help='Use MONGO_URI instead of mongomock')
    ap.add_argument('--node-count', type=int, default=1)
    ap.add_argument('--clicks', type=int, default=500)
    ap.add_argument('--cleanup', action='store_true', help='Drop load_test docs and exit')
    args = ap.parse_args()

    if args.users < 1 or args.users > 5000:
        print('--users must be 1..5000')
        sys.exit(2)

    db, client = _get_db(args.real_mongo)

    if args.cleanup:
        for c in ('users', 'accounts', 'click_links', 'discovered_groups', 'worker_health'):
            n = db[c].delete_many({'load_test': True}).deleted_count
            print(f"cleaned {c}: {n}")
        return

    ensure_indexes(db)
    active, total_acc = seed(db, args.users, args.accounts_per_user, args.forwarding_ratio)

    # Scaling report
    capacity_report(active, total_acc, args.users)

    # Sharding fairness
    for nodes in ({1, 2, 3} if args.node_count == 1 else {args.node_count}):
        workers = max(1, desired_workers(active // max(1, nodes), 100, 1, 16))
        fairness_report(db, nodes, workers)

    # Read path
    bench_reads(db, args.users)

    # Health writes (simulate manager interval)
    w = desired_workers(active, 100, 1, 16)
    bench_health_writes(db, w)

    # Click races
    bench_click_inc(db, args.clicks)

    # Niche discovery lookup (bot Find Groups)
    t0 = time.perf_counter()
    for niche in ('crypto', 'forex', 'instagram'):
        n = db['discovered_groups'].count_documents({'niche': niche, 'load_test': True})
    print(f"[DISCOVER] 3 niche count queries in {(time.perf_counter()-t0)*1000:.1f} ms")

    print("\n✅ Load simulation finished.")
    print("NOTE: This does not exercise Telegram MTProto, floods, or proxy quality.")
    print("      Run a small real pilot (20–50 accounts) before full production.")
    try:
        client.close()
    except Exception:
        pass


if __name__ == '__main__':
    main()
