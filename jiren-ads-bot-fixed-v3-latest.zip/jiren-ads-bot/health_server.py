"""Tiny async HTTP /health for liveness + basic stats (no extra deps)."""
from __future__ import annotations
import asyncio
import json
import os

async def start_health_server(get_stats_callable, host: str = '0.0.0.0', port: int = 8080):
    """get_stats_callable: sync or async () -> dict"""
    port = int(os.getenv('HEALTH_PORT', str(port)))
    if os.getenv('HEALTH_SERVER', '1') not in ('1', 'true', 'True', 'yes'):
        print('[HEALTH] disabled (HEALTH_SERVER=0)')
        return None

    async def handle(reader, writer):
        try:
            data = await asyncio.wait_for(reader.read(1024), timeout=2)
            req = data.decode('utf-8', errors='ignore')
            path = '/'
            if req.startswith('GET '):
                path = req.split(' ', 2)[1].split('?')[0]
            if path not in ('/health', '/metrics', '/'):
                body = b'{"ok":false,"error":"not found"}'
                status = b'404 Not Found'
            else:
                try:
                    stats = get_stats_callable()
                    if asyncio.iscoroutine(stats):
                        stats = await stats
                except Exception as e:
                    stats = {'ok': False, 'error': str(e)}
                body = json.dumps(stats, default=str).encode()
                status = b'200 OK'
            headers = (
                b'HTTP/1.1 ' + status + b'\r\n'
                b'Content-Type: application/json\r\n'
                b'Content-Length: ' + str(len(body)).encode() + b'\r\n'
                b'Connection: close\r\n\r\n'
            )
            writer.write(headers + body)
            await writer.drain()
        except Exception:
            pass
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass

    try:
        server = await asyncio.start_server(handle, host, port)
        print(f'[HEALTH] listening on {host}:{port}  (/health)')
        return server
    except Exception as e:
        print(f'[HEALTH] failed to bind {port}: {e}')
        return None
