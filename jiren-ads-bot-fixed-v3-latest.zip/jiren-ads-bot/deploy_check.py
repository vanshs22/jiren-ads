#!/usr/bin/env python3
"""Quick deploy check — no Mongo/Telegram required for syntax + wiring."""
import ast
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQUIRED_ENV = [
    "TELEGRAM_API_ID", "TELEGRAM_API_HASH", "BOT_TOKEN",
    "OWNER_ID", "MONGO_URI", "ENCRYPTION_KEY",
]


def main():
    errs = []
    for name in ("bot.py", "manager.py", "config.py", "forwarding_svc.py", "admin_audit.py"):
        p = ROOT / name
        if not p.exists():
            errs.append(f"missing {name}")
            continue
        try:
            ast.parse(p.read_text(encoding="utf-8"))
        except SyntaxError as e:
            errs.append(f"syntax {name}: {e}")

    # button smoke if present
    smoke = ROOT / "tests" / "test_button_wiring.py"
    if smoke.exists():
        try:
            import subprocess
            r = subprocess.run(
                [sys.executable, str(smoke)],
                cwd=str(ROOT),
                capture_output=True,
                text=True,
                timeout=60,
            )
            if r.returncode != 0:
                errs.append(f"button wiring: {(r.stdout or r.stderr or '')[:200]}")
        except Exception as e:
            errs.append(f"button smoke: {e}")

    missing = [k for k in REQUIRED_ENV if not os.getenv(k, "").strip()]
    if missing:
        print("WARN: env not set in this shell (ok if using systemd EnvironmentFile):", ", ".join(missing))

    if errs:
        print("FAIL:")
        for e in errs:
            print(" -", e)
        sys.exit(1)
    print("OK: syntax + modules + button wiring")
    return 0


if __name__ == "__main__":
    sys.exit(main() or 0)
