"""
Forwarding helpers — zero extra Mongo writes for scale (100s of users).

Stuck detection is process-local (in-memory). The reconciler already restarts
accounts that are is_forwarding but have no live local task. That is enough
for multi-worker without O(accounts) heartbeat updates.
"""
from __future__ import annotations

import os
import time
from typing import Any, Dict, Optional

DRAINING: bool = False

# account_id -> monotonic last progress time
_last_activity: Dict[str, float] = {}

ACTIVITY_STALE_SEC = float(os.getenv("ACTIVITY_STALE_SEC", "600"))


def set_draining(value: bool = True) -> None:
    global DRAINING
    DRAINING = bool(value)


def is_draining() -> bool:
    return DRAINING


def touch_activity(account_id) -> None:
    try:
        _last_activity[str(account_id)] = time.monotonic()
    except Exception:
        pass


def clear_activity(account_id) -> None:
    _last_activity.pop(str(account_id), None)


def is_activity_stale(account_id, now: Optional[float] = None) -> bool:
    key = str(account_id)
    ts = _last_activity.get(key)
    if ts is None:
        return False
    now = time.monotonic() if now is None else now
    return (now - ts) > ACTIVITY_STALE_SEC


def status_label_for_account(acc: Optional[dict]) -> tuple:
    if not acc:
        return ("❌", "Unknown")
    if acc.get("auth_invalid"):
        return ("⚠️", "Session dead")
    if acc.get("is_forwarding"):
        return ("✅", "Active")
    return ("❌", "Inactive")
