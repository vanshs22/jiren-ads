# Jiren Ads Bot — Security Checklist

## Before any production traffic

- [ ] **Rotate every secret** that ever appeared in source, chat, or old `config.py`
  (bot tokens, `api_id`/`api_hash`, Mongo password, UPI details if exposed).
- [ ] All secrets live only in `.env` or a secret manager — **never** in git.
- [ ] `ENCRYPTION_KEY` generated once and backed up offline. Losing it = all sessions unreadable.
- [ ] Mongo is **not** published to the public internet (`docker-compose` has no `ports:` for mongo).
- [ ] n8n webhooks protected with `N8N_WEBHOOK_SECRET` (see workflows).
- [ ] Admin Telegram IDs restricted; audit `/addacc`, OTP forward, device logout.

## Runtime

- [ ] `FORCE_JOIN` channel is one you control.
- [ ] Proxies are residential/mobile where possible; run `python proxy_health.py` on a schedule.
- [ ] `LIVE_SEND_LOGS=0` at scale (logger bot FloodWaits).
- [ ] Regular Mongo backups + `session/` volume backups.
- [ ] Manager alerts (`OWNER_ID`) monitored.

## n8n webhook auth

Both discovery and click-tracker workflows expect an optional shared secret:

```
X-Webhook-Secret: <N8N_WEBHOOK_SECRET>
```

or query `?secret=<N8N_WEBHOOK_SECRET>`.

Reject requests that do not match when the env var is set.

## Admin surface

Powerful admin tools (OTP forwarding, remote device logout, grant premium) increase
blast radius if an admin account is compromised. Keep the owner account 2FA-protected
and minimize the admin list.
