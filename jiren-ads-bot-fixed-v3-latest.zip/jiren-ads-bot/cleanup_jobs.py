"""Periodic Mongo cleanup + SaaS maintenance (low frequency, UI process only)."""
from __future__ import annotations
from datetime import datetime, timedelta


def run_cleanup(db, days_stats: int = 14, days_flood: int = 2):
    removed = {}
    now = datetime.utcnow()
    try:
        r = db['account_flood_waits'].delete_many({'wait_until': {'$lt': now - timedelta(hours=1)}})
        removed['flood_waits'] = r.deleted_count
    except Exception as e:
        removed['flood_waits_err'] = str(e)
    try:
        r = db['account_stats'].delete_many({'date': {'$lt': (now - timedelta(days=days_stats)).strftime('%Y-%m-%d')}})
        removed['old_stats'] = r.deleted_count
    except Exception as e:
        removed['old_stats_err'] = str(e)
    try:
        r = db['admin_audit'].delete_many({'at': {'$lt': now - timedelta(days=90)}})
        removed['old_audit'] = r.deleted_count
    except Exception as e:
        removed['old_audit_err'] = str(e)
    # Expire premium plans (batch). is_premium() also checks on access.
    try:
        q = {
            'tier': 'premium',
            '$or': [
                {'premium_expires_at': {'$lt': datetime.now()}},
                {'premium_expiry': {'$lt': datetime.now()}},
                {'plan_expiry': {'$lt': datetime.now()}},
            ],
        }
        r = db['users'].update_many(
            q,
            {'$set': {
                'tier': 'free',
                'plan': 'scout',
                'plan_name': 'No Plan',
                'max_accounts': 1,
                'premium_expires_at': None,
                'premium_expiry': None,
                'plan_expiry': None,
            }},
        )
        removed['premium_expired'] = r.modified_count
    except Exception as e:
        removed['premium_expired_err'] = str(e)
    return removed
