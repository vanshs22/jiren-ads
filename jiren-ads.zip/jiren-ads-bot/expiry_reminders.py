"""Plan-expiry reminders over Telegram DM.

Anti-spam: each user gets at most one DM per stage per plan period.
- "5d": 5 days or less left, "1d": 1 day or less left. State is stored on the user as
  expiry_reminder_for (the expiry date it refers to) + expiry_reminder_stage, so a renewal
  (new expiry date) starts a fresh cycle and a late sweep never re-sends an earlier stage.
- "expired": sent once, driven by the expired_notice_pending flag that every downgrade path
  sets (the downgrade clears the expiry date, so the date alone can't be used afterwards).
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta

STAGE_RANK = {"5d": 1, "1d": 2}


def due_stage(expires_at, now, last_for=None, last_stage=None):
    """Return "5d" / "1d" if a reminder is due now, else None."""
    if not isinstance(expires_at, datetime):
        return None
    left = expires_at - now
    if left <= timedelta(0) or left > timedelta(days=5):
        return None
    stage = "1d" if left <= timedelta(days=1) else "5d"
    if last_for == expires_at and STAGE_RANK.get(last_stage, 0) >= STAGE_RANK[stage]:
        return None
    return stage


def message(stage, expires_at=None):
    if stage == "expired":
        return ("⏰ <b>Your plan has expired</b>\n\nYour account is back on the free plan. "
                "Renew from Plans &amp; Pricing to restore your limits.")
    left = "less than 1 day" if stage == "1d" else f"{max((expires_at - datetime.now()).days, 1)} days"
    return (f"⏳ <b>Your plan ends in {left}</b>\n\n"
            "Renew from Plans &amp; Pricing before it ends to avoid interruption.")


async def run_reminders(users_col, send, now=None, pause=0.05):
    """send(user_id, text) is awaited per DM. Failures never cause a re-send."""
    now = now or datetime.now()
    sent = 0

    async def deliver(uid, text):
        nonlocal sent
        try:
            await send(uid, text)
            sent += 1
        except Exception:
            pass  # blocked bot / deleted account: marker is still written below
        await asyncio.sleep(pause)

    soon = {"tier": "premium", "premium_expires_at": {"$gt": now, "$lte": now + timedelta(days=5)}}
    for u in await asyncio.to_thread(lambda: list(users_col.find(soon))):
        exp = u.get("premium_expires_at")
        stage = due_stage(exp, now, u.get("expiry_reminder_for"), u.get("expiry_reminder_stage"))
        if not stage:
            continue
        await asyncio.to_thread(users_col.update_one, {"user_id": u["user_id"]}, {"$set": {"expiry_reminder_for": exp, "expiry_reminder_stage": stage}})
        await deliver(u["user_id"], message(stage, exp))

    # Skip users who renewed before the sweep ran.
    lapsed = {"expired_notice_pending": True, "tier": {"$ne": "premium"}}
    for u in await asyncio.to_thread(lambda: list(users_col.find(lapsed))):
        await asyncio.to_thread(users_col.update_one, {"user_id": u["user_id"]}, {"$set": {"expired_notice_pending": False}})
        await deliver(u["user_id"], message("expired"))
    await asyncio.to_thread(users_col.update_many, {"expired_notice_pending": True, "tier": "premium"}, {"$set": {"expired_notice_pending": False}})
    return sent
