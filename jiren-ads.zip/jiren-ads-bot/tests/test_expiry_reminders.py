import asyncio
import os
import sys
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from expiry_reminders import due_stage, run_reminders

NOW = datetime(2026, 11, 18, 12, 0)


def test_due_stage():
    assert due_stage(NOW + timedelta(days=6), NOW) is None
    assert due_stage(NOW + timedelta(days=4), NOW) == "5d"
    assert due_stage(NOW + timedelta(hours=5), NOW) == "1d"
    assert due_stage(NOW - timedelta(hours=1), NOW) is None
    exp = NOW + timedelta(days=4)
    assert due_stage(exp, NOW, exp, "5d") is None                      # already sent
    assert due_stage(NOW + timedelta(hours=5), NOW, exp, "5d") == "1d"  # next stage still goes out
    assert due_stage(exp + timedelta(days=30), NOW, exp, "1d") is None  # renewed: out of window


class FakeCol:
    def __init__(self, users): self.users = users
    def find(self, q):
        out = []
        for u in self.users:
            if "premium_expires_at" in q:
                r = q["premium_expires_at"]
                if u["tier"] == "premium" and r["$gt"] < u.get("premium_expires_at", datetime.min) <= r["$lte"]:
                    out.append(u)
            elif u.get("expired_notice_pending") and u["tier"] != "premium":
                out.append(u)
        return out
    def update_one(self, f, upd):
        for u in self.users:
            if u["user_id"] == f["user_id"]: u.update(upd["$set"])
    def update_many(self, f, upd):
        for u in self.users:
            if u.get("expired_notice_pending") and u["tier"] == "premium": u.update(upd["$set"])


def test_no_spam_and_expired_once():
    users = [{"user_id": 1, "tier": "premium", "premium_expires_at": NOW + timedelta(days=4)},
             {"user_id": 2, "tier": "free", "expired_notice_pending": True},
             {"user_id": 3, "tier": "premium", "premium_expires_at": NOW + timedelta(days=20)}]
    got = []
    async def send(uid, text): got.append(uid)
    col = FakeCol(users)
    run = lambda t: asyncio.run(run_reminders(col, send, now=t, pause=0))
    assert run(NOW) == 2
    assert run(NOW + timedelta(hours=1)) == 0            # nothing repeats
    assert run(NOW + timedelta(days=3, hours=1)) == 1    # 1d stage
    assert sorted(got) == [1, 1, 2]
